# 随包依赖

`vendor/` 内包含 MIDI 导入所需的纯 Python 依赖，无需联网安装。

| 名称 | 版本 | 许可 | 随包许可文件 |
| --- | --- | --- | --- |
| Mido | 1.3.3 | MIT | `vendor/mido-1.3.3.dist-info/LICENSE` |
| packaging | 26.3 | Apache-2.0 或 BSD-2-Clause | `vendor/packaging-26.3.dist-info/licenses/LICENSE`、`LICENSE.APACHE`、`LICENSE.BSD` |

完整许可与版权声明保留在上述文件中。Mido 用于读取 MIDI；packaging 是其版本处理依赖。本程序的 MIDI 读取不使用 MIDI 设备后端。

用户提供的 NTE-GUITAR EXE、程序集、分析中间文件与三份歌曲 MIDI 不包含在发布包内。`examples/小星星_导入演示.mid` 是根据本程序已有的短示范旋律自行生成的演示文件。

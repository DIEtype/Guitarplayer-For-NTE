"""Build and verify the source release with its offline MIDI dependencies."""
from pathlib import Path
import zipfile
import hashlib

from guitar_player import __version__


TOP_FILES={'main.py','start.cmd','启动吉他编曲器.cmd','check_startup.cmd',
           'README.md','THIRD_PARTY.md','验证结果.txt','build_release.py','.gitignore','.gitattributes'}
SOURCE_DIRS={'guitar_player','tests','vendor','examples','docs','.github'}
EXCLUDED={'__pycache__','.preview','logs','library','settings','.git','.venv','bin'}


def release_files(root):
    """An allowlist prevents new personal folders leaking into releases."""
    files=[root/name for name in TOP_FILES if (root/name).is_file()]
    def fail(error):raise error
    for name in sorted(SOURCE_DIRS):
        folder=root/name
        if not folder.is_dir():continue
        for directory,dirs,filenames in folder.walk(on_error=fail):
            dirs[:]=[name for name in dirs if name not in EXCLUDED]
            for name in filenames:
                path=directory/name
                if path.is_symlink():raise ValueError(f'发布文件不能是符号链接：{path}')
                if path.suffix.lower() in {'.pyc','.pyo','.tmp','.log','.partial','.key','.pem'}:continue
                files.append(path)
    return sorted(files)


def build():
    root=Path(__file__).resolve().parent
    output=root.parent/f'nte-guitar-player-v{__version__}.zip'
    temporary=output.with_suffix('.zip.tmp')
    files=release_files(root)
    with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for path in sorted(files):archive.write(path,Path('nte-guitar-player')/path.relative_to(root))
    with zipfile.ZipFile(temporary) as archive:
        assert archive.testzip() is None
        names=set(archive.namelist())
        for required in ('guitar_player/tablature.py','guitar_player/visual_editor.py',
                         'guitar_player/chord_score.py','guitar_player/chord_editor.py',
                         'guitar_player/calibration.py','guitar_player/settings.py','guitar_player/log_learning.py',
                         'docs/自动校准与日志调优.md',
                         'examples/和弦试弹_第一页.gscore','examples/四页和弦_拨弦与扫弦.gscore','examples/和弦伴奏_谱面预览.png',
                         'guitar_player/arrangement.py','guitar_player/library.py','guitar_player/library_ui.py','guitar_player/widgets.py',
                         'guitar_player/measures.py','examples/变拍变速_音色与Capo示例.gscore','examples/变拍变速_音色与Capo示例.png',
                         'vendor/mido/__init__.py','vendor/packaging/__init__.py',
                         'vendor/mido-1.3.3.dist-info/LICENSE','vendor/packaging-26.3.dist-info/licenses/LICENSE.APACHE',
                         'examples/多小节_节奏符号示例.gscore','examples/六线谱符号示例.png'):
            assert 'nte-guitar-player/'+required in names,required
        assert __version__ in archive.read('nte-guitar-player/guitar_player/__init__.py').decode('utf-8')
        for name in ('start.cmd','启动吉他编曲器.cmd'):
            data=archive.read('nte-guitar-player/'+name);data.decode('ascii')
            assert b'\n' not in data.replace(b'\r\n',b'')
        assert not any(any(part in EXCLUDED or part=='cover_build' for part in Path(name).parts[1:]) for name in names)
    temporary.replace(output)
    digest=hashlib.sha256(output.read_bytes()).hexdigest()
    output.with_suffix('.zip.sha256').write_text(digest+'  '+output.name+'\n',encoding='ascii')
    print(f'Release ZIP OK: {len(files)} files, {output.stat().st_size} bytes')
    print(f'SHA256: {digest}')


if __name__=='__main__':build()

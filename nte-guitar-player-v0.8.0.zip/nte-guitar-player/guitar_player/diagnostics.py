"""Separate the game input connection from notation and playback scheduling."""
from datetime import datetime, timezone
import json
from pathlib import Path
import threading
import uuid
import queue
import time

from .native import WindowsBackend
from .profile import Binding
from .timing import SAFE
from .game_profile import ROMAN


class InputTrace:
    def __init__(self, directory, purpose,buffered=False):
        directory=Path(directory)
        directory.mkdir(parents=True,exist_ok=True)
        self.path=directory/f"input-{uuid.uuid4().hex[:12]}.jsonl"
        self.lock=threading.Lock()
        self.buffered=buffered;self.closed=False;self.error=None
        if buffered:
            self.path.touch();self.pending=queue.SimpleQueue()
            self.worker=threading.Thread(target=self._write_pending,daemon=True);self.worker.start()
        self.record("session",purpose=purpose)

    def record(self,event,**fields):
        row={"utc":datetime.now(timezone.utc).isoformat(),"perf_ns":time.perf_counter_ns(),"event":event,**fields}
        with self.lock:
            if self.closed:return
            if self.buffered:
                if not self.error:self.pending.put(row)
                return
            with self.path.open("a",encoding="utf-8") as stream:
                stream.write(json.dumps(row,ensure_ascii=False)+"\n")

    def _write_pending(self):
        try:
            with self.path.open('a',encoding='utf-8') as stream:
                while True:
                    row=self.pending.get()
                    if row is None:break
                    if isinstance(row,tuple):stream.flush();row[1].set()
                    else:stream.write(json.dumps(row,ensure_ascii=False)+'\n')
        except Exception as error:self.error=str(error)

    def flush(self):
        if not self.buffered or self.closed:return True
        done=threading.Event();self.pending.put(('flush',done));return done.wait(1)

    def close(self):
        with self.lock:
            if self.closed:return
            self.closed=True
            if self.buffered:self.pending.put(None)
        if self.buffered:self.worker.join(1)


class InputProbe:
    def __init__(self,emit):
        self.emit=emit
        self.cancel=threading.Event()
        self.thread=None

    @property
    def running(self):
        return self.thread is not None and self.thread.is_alive()

    def stop(self):
        self.cancel.set()

    def start(self,hwnd,profile,kind,trace,backend_factory=WindowsBackend,countdown=3,timing=None):
        if self.running:
            raise ValueError("输入测试正在运行")
        if kind not in ("key","pointer","select","page"):
            raise ValueError("未知的输入测试")
        if kind=='page' and profile.mode!='fret':raise ValueError('翻页测试目前用于品格模式')
        self.cancel.clear()
        self.thread=threading.Thread(target=self._run,args=(hwnd,profile,kind,trace,backend_factory,countdown,timing or SAFE),daemon=True)
        self.thread.start()

    def _wait(self,seconds,backend=None):
        import time
        end=time.perf_counter()+seconds
        while time.perf_counter()<end:
            if self.cancel.wait(min(.01,max(0,end-time.perf_counter()))):
                raise InterruptedError("输入测试已取消")
            if backend:
                backend.check_target()

    def _run(self,hwnd,profile,kind,trace,factory,countdown,timing):
        backend=None
        message="测试完成：请根据游戏里的实际响应判断是否连通；Windows 接收事件不代表游戏已处理"
        try:
            for second in range(countdown,0,-1):
                self.emit("probe_state",f"{second} 秒后输入测试，请切换到所选游戏窗口")
                self._wait(1)
            if self.cancel.is_set():
                raise InterruptedError("输入测试已取消")
            backend=factory(hwnd,profile,trace=trace,check_aspect=False)
            target=backend.acquire_target()
            trace.record("probe_begin",kind=kind,target=target,input_speed=timing.key)
            if kind=="key":
                self.emit("probe_state","正在发送数字键 6 三次：对应吉他 1 弦，不依赖圆盘坐标")
                for _ in range(3):
                    backend.press((Binding(1,"key","6"),))
                    self._wait(.12,backend)
                    backend.release_all()
                    self._wait(.35,backend)
            else:
                selector=next(name for name in profile.chords if profile.pages[name]==profile.initial_page)
                if kind=='page':
                    page=(profile.initial_page+1)%profile.page_count
                    selector=next(name for name in profile.chords if profile.pages[name]==page)
                    self.emit('probe_state',f'按 {timing.label}档翻到第 {page+1} 页，选择 {selector} 并拨弦；完成后请重新对齐游戏起始页')
                    backend.press((Binding(0,'key','T'),));self._wait(timing.page_hold,backend);backend.release_all()
                    self._wait(timing.page_wait-timing.page_hold,backend)
                backend.chord_move(selector)
                self._wait(timing.mouse_settle if kind!='pointer' else .10,backend)
                if kind=="pointer":
                    self.emit("probe_state",f"已移动到 {selector} 区域；本项不点击、不拨弦")
                    self._wait(.6,backend)
                else:
                    backend.chord_down(selector)
                    self._wait(timing.mouse_hold,backend)
                    backend.chord_up()
                    self._wait(timing.after_select,backend)
                    backend.press((Binding(1,"key","6"),))
                    self._wait(timing.tap_ms/1000,backend)
                    backend.release_all()
            trace.record("probe_finished",kind=kind)
        except Exception as error:
            message=str(error)
            trace.record("probe_error",kind=kind,error=message)
        finally:
            if backend:
                try:
                    backend.release_all()
                except Exception as error:
                    message=f"释放输入失败：{error}"
                    trace.record("release_error",error=str(error))
            trace.close()
            self.emit("probe_done",(message,str(trace.path)))

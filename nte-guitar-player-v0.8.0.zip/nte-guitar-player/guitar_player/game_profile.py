from dataclasses import dataclass, field
import json
import math

from .guitar import UP, DOWN
from .profile import Binding

FIRST_PAGE_POINTS = {
    "G": (648 / 1023, 92 / 575), "Am": (765 / 1023, 161 / 575),
    "Bm": (765 / 1023, 288 / 575), "C": (648 / 1023, 359 / 575),
    "D": (526 / 1023, 288 / 575), "Em": (526 / 1023, 161 / 575),
}
CHORD_PAGES = (
    ('G', 'Am', 'Bm', 'C', 'D', 'Em'),
    ('Cmaj7', 'C7', 'Cm7', 'G7', 'C9', 'Cm9'),
    ('C5', 'D5', 'G5', 'A5', 'Cmaj9', 'Cadd9'),
    ('G/B', 'Am7/G', 'D/F#', 'F/A', 'A', 'Dm'),
)
CHORD_NAMES = tuple(name for page in CHORD_PAGES for name in page)
DEFAULT_CHORDS = {name: tuple(FIRST_PAGE_POINTS.values())[slot]
                  for page in CHORD_PAGES for slot, name in enumerate(page)}
CHORD_PAGE_INDEX = {name: page for page, names in enumerate(CHORD_PAGES) for name in names}
ROMAN = ("I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII",
         "XIII", "XIV", "XV", "XVI", "XVII", "XVIII", "XIX", "XX", "XXI", "XXII", "XXIII", "XXIV")


def valid_point(point):
    if not isinstance(point, (list, tuple)) or len(point) != 2:
        raise ValueError("位置需要两个 0～1 之间的数")
    if any(type(n) not in (int, float) or not math.isfinite(n) or not 0 <= n <= 1 for n in point):
        raise ValueError("相对位置必须在 0～1 之间")
    return tuple(map(float, point))


@dataclass
class GameProfile:
    name: str = "异环吉他 · 四页和弦"
    chords: dict = field(default_factory=lambda: dict(DEFAULT_CHORDS))
    strum_point: tuple = (0.86, 0.67)
    calibrated: bool = False
    reference_size: tuple = (1023, 575)
    mode: str = "chord"
    pages: dict = field(default_factory=lambda: dict(CHORD_PAGE_INDEX))
    initial_page: int = 0
    page_count: int = 4
    initial_timbre: str = 'clean'
    initial_mode: str | None = None

    @classmethod
    def frets(cls):
        slots = [(871 / 1247, 168 / 687), (990 / 1247, 237 / 687),
                 (990 / 1247, 368 / 687), (871 / 1247, 437 / 687),
                 (749 / 1247, 368 / 687), (749 / 1247, 237 / 687)]
        return cls("异环吉他 · 品格 0～24", {**{name: slots[i % 6] for i, name in enumerate(ROMAN)}, "Zero": slots[0]},
                   (0.91, 0.67), False, (1247, 687), "fret",
                   {**{name: i // 6 for i, name in enumerate(ROMAN)}, "Zero": 4}, 0, 5)

    @property
    def bindings(self):
        return {**{s: Binding(s, "key", str(7 - s)) for s in range(1, 7)},
                UP: Binding(UP, "mouse", button="left"),
                DOWN: Binding(DOWN, "mouse", button="right")}

    def to_dict(self):
        return {"version": 1, "name": self.name, "chords": self.chords,
                "strum_point": self.strum_point, "calibrated": self.calibrated,
                "reference_size": self.reference_size,
                "mode": self.mode, "pages": self.pages, "initial_page": self.initial_page,
                "page_count": self.page_count,"initial_timbre":self.initial_timbre,"initial_mode":self.initial_mode}

    @classmethod
    def from_dict(cls, data):
        if not isinstance(data, dict) or data.get("version") != 1:
            raise ValueError("不支持的布局文件版本")
        chords = data.get("chords")
        if not isinstance(chords, dict) or not chords or len(chords) > 48:
            raise ValueError("布局文件需要 1～48 个和弦")
        size = data.get("reference_size", [1023, 575])
        if not isinstance(size, (tuple, list)) or len(size) != 2 or any(type(n) is not int or n <= 0 for n in size):
            raise ValueError("参考窗口尺寸应为两个正整数")
        mode = data.get("mode", "chord")
        pages = data.get("pages", {name: 0 for name in chords})
        initial = data.get("initial_page", 0)
        count = data.get("page_count", 5 if mode == "fret" else 4)
        tone=data.get('initial_timbre','clean')
        initial_mode=data.get('initial_mode')
        if initial_mode not in (None,'chord','fret'):raise ValueError('游戏初始模式无效')
        if tone not in ('clean','distorted'):raise ValueError('游戏初始音色无效')
        if type(count) is not int or not 1 <= count <= 12:
            raise ValueError("总页数应在 1～12 之间")
        if mode not in ("chord", "fret") or type(initial) is not int or not 0 <= initial < count:
            raise ValueError("模式或起始页无效")
        if not isinstance(pages, dict) or set(pages) != set(chords) or any(type(p) is not int or not 0 <= p < count for p in pages.values()):
            raise ValueError("选择项页码超出总页数")
        if mode=='chord' and count==4 and set(chords)==set(CHORD_PAGES[0]) and all(p==0 for p in pages.values()):
            slots=[chords[name] for name in CHORD_PAGES[0]]
            chords={name:slots[i] for names in CHORD_PAGES for i,name in enumerate(names)}
            pages=dict(CHORD_PAGE_INDEX)
        return cls(str(data.get("name", "自定义吉他布局")),
                   {str(name): valid_point(point) for name, point in chords.items()},
                   valid_point(data.get("strum_point", [0.86, 0.67])),
                   data.get("calibrated") is True, tuple(size), mode, pages, initial, count,tone,initial_mode)


def load_profile(path):
    with open(path, encoding="utf-8-sig") as stream:
        return GameProfile.from_dict(json.load(stream))

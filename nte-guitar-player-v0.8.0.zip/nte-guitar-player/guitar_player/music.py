"""Reference tuning only; the game's samples still require measurement."""
from .score import pitch_name

# Indexed by actual guitar string number, 1 = thinnest/highest.
STANDARD_TUNING = {1: 64, 2: 59, 3: 55, 4: 50, 5: 45, 6: 40}


def fret_pitch(string, fret, tuning=None):
    if string not in STANDARD_TUNING or not 0 <= fret <= 24:
        raise ValueError("弦号为 1～6，品位为 0～24")
    return (tuning or STANDARD_TUNING)[string] + fret


def fret_name(string, fret):
    return pitch_name(fret_pitch(string, fret))


def positions_for_pitch(pitch, allowed_frets=range(25), tuning=None):
    tuning = tuning or STANDARD_TUNING
    return [(string, fret) for string in range(1, 7) for fret in allowed_frets
            if tuning[string] + fret == pitch]

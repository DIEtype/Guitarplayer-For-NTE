"""Explicit, unmeasured game-input timing presets; musical timing stays intact."""
from dataclasses import dataclass


@dataclass(frozen=True)
class InputTiming:
    key:str
    label:str
    page_wait:float
    mouse_settle:float
    mouse_hold:float
    after_select:float
    page_hold:float
    tap_ms:int
    key_gap:float=.010
    jitter_margin:float=0

    @property
    def minimum_select(self):return self.mouse_settle+self.mouse_hold

    @property
    def lead(self):return self.minimum_select+self.after_select+self.jitter_margin

    def change_budget(self,pages):return pages*self.page_wait+self.lead


SAFE=InputTiming('safe','兼容',.180,.075,.020,.025,.035,45)
FAST=InputTiming('fast','快速',.080,.030,.015,.015,.025,30)
TURBO=InputTiming('turbo','极速（试验）',.050,.010,.010,.010,.015,20)
ADAPTIVE=InputTiming('adaptive','稳拍自适应（推荐）',.100,.020,.040,.040,.040,40,.020,.012)
PRESETS={item.key:item for item in (ADAPTIVE,SAFE,FAST,TURBO)}
LABELS={item.label:item for item in PRESETS.values()}

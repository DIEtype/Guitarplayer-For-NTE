"""Measured single-voice tablature, independent of the drawing and game input."""
from dataclasses import dataclass,replace
from fractions import Fraction as F
from math import ceil
from bisect import bisect_right

from .game_profile import ROMAN
from .guitar import GuitarEvent,GuitarScore
from .measures import MeasureChange,measure_layout,score_layout,apply_changes,parse_changes,valid_meter


VALUES=(1,2,4,8,16,32,64)


def note_duration(denominator,dotted=False,triplet=False):
    return F(4,denominator)*(F(3,2) if dotted else 1)*(F(2,3) if triplet else 1)


def identify_duration(beats):
    for dotted,triplet in ((False,False),(True,False),(False,True),(True,True)):
        for denominator in VALUES:
            if note_duration(denominator,dotted,triplet)==beats:
                return denominator,dotted,triplet
    return None


def rhythm_parts(beats):
    choices=sorted({note_duration(value,dot,triplet) for value in VALUES
                    for dot,triplet in ((False,False),(True,False),(False,True))},reverse=True)
    remaining=F(beats);result=[]
    while remaining:
        length=next((value for value in choices if value<=remaining),remaining)
        result.append(length);remaining-=length
    return result


@dataclass(frozen=True)
class TabCell:
    start:F
    beats:F
    string:int=1
    fret:int|None=None

    @property
    def end(self):return self.start+self.beats


class TabDocument:
    def __init__(self,cells=(),bpm=100,meter=(4,4),bars=4,tempo_map=(),bar_changes=(),default_timbre='clean',capo=0):
        self.cells=list(cells)
        self.bpm=float(bpm);self.source_bpm=float(bpm)
        self.meter=tuple(meter);self.bars=max(1,int(bars));self.tempo_map=tuple(tempo_map)
        self.bar_changes={c.bar:c for c in bar_changes};self.default_timbre=default_timbre
        self.capo=capo
        self._layout_key=None;self._layout=()
        self.ensure_bars()

    @classmethod
    def from_score(cls,score):
        if any(len(e.notes)>1 or any(n not in range(1,7) for n in e.notes) for e in score.events):
            raise ValueError("图形编辑目前使用单音旋律；多弦齐奏与扫弦请使用高级文本")
        cells=[TabCell(e.start,e.beats,e.notes[0],(0 if e.chord=='Zero' else ROMAN.index(e.chord)+1)-score.capo)
               for e in score.events if e.notes]
        meter=score.time_signature
        bars=max(score.measures or 4,len(score_layout(score)))
        base=score.base_tempo_map if score.base_tempo_map is not None else score.tempo_map
        return cls(cells,score.bpm,meter,bars,base,score.bar_changes,score.default_timbre,score.capo)

    @property
    def bar_beats(self):return F(self.meter[0]*4,self.meter[1])

    @property
    def layout(self):
        key=(self.meter,self.bars,tuple(sorted(self.bar_changes.values(),key=lambda c:c.bar)))
        if key!=self._layout_key:
            self._layout=measure_layout(self.meter,self.bars,key[2]);self._starts=tuple(b.start for b in self._layout);self._layout_key=key
        return self._layout

    def bar_index(self,at):
        self.layout
        return max(0,min(self.bars-1,bisect_right(self._starts,F(at))-1))

    def bar(self,index):return self.layout[index]

    def ensure_bars(self):
        self.cells.sort(key=lambda c:c.start)
        self.bars=max(self.bars,max(self.bar_changes,default=-1)+1,1)
        end=max((c.end for c in self.cells),default=F(0))
        while self.layout[-1].end<end:
            self.bars+=max(1,ceil((end-self.layout[-1].end)/self.layout[-1].beats))
        if self.bars>25000:raise ValueError('小节过多，请分段编曲')

    def at(self,at):return next((c for c in self.cells if c.start==at),None)

    def rest_spans(self,index):
        measure=self.bar(index);start=measure.start;end=measure.end;cursor=start;gaps=[]
        for cell in self.cells:
            if cell.start>=end:break
            if cell.end<=start:continue
            if cell.start>cursor:gaps.append((cursor,min(cell.start,end)-cursor))
            cursor=max(cursor,min(cell.end,end))
        if cursor<end:gaps.append((cursor,end-cursor))
        return gaps

    def snapshot(self):
        return (tuple(self.cells),self.bpm,self.meter,self.bars,self.tempo_map,self.source_bpm,
                tuple(sorted(self.bar_changes.values(),key=lambda c:c.bar)),self.default_timbre,self.capo)

    def restore(self,state):
        cells,self.bpm,self.meter,self.bars,self.tempo_map,self.source_bpm,changes,self.default_timbre,self.capo=state
        self.cells=list(cells);self.bar_changes={c.bar:c for c in changes}

    def move_annotations(self,move):
        """Hook for timed annotations owned by another editor document."""

    def make_cell(self,at,beats,string,fret):return TabCell(at,beats,string,fret)

    def write(self,at,string,fret,beats):
        at,beats=F(at),F(beats)
        if at<0 or not F(1,960)<=beats<=128:raise ValueError("音符时值超出范围")
        if not 1<=string<=6 or fret is not None and not 0<=fret<=24-self.capo:raise ValueError(f"弦号 1～6；Capo {self.capo} 下相对品位应为 0～{24-self.capo}")
        current=self.at(at)
        if current:
            delta=beats-current.beats
            self.cells=[replace(c,start=c.start+delta) if c.start>=current.end else c
                        for c in self.cells if c is not current]
            self.move_annotations(lambda t:t+delta if t>=current.end else t)
        else:
            if any(c.start<at<c.end for c in self.cells):
                raise ValueError("此处仍在前一个音符内；先选它修改时值，或移动到下一个空位")
            next_start=min((c.start for c in self.cells if c.start>at),default=at+beats)
            shift=max(F(0),at+beats-next_start)
            if shift:
                self.cells=[replace(c,start=c.start+shift) if c.start>at else c for c in self.cells]
                self.move_annotations(lambda t:t+shift if t>at else t)
        self.cells.append(self.make_cell(at,beats,string,fret));self.ensure_bars()

    def resize(self,at,beats):
        current=self.at(at)
        if current:self.write(at,current.string,current.fret,beats)

    def delete(self,at):self.cells=[c for c in self.cells if c.start!=at]

    def set_meter(self,numerator,denominator):
        if not valid_meter((numerator,denominator)):raise ValueError("拍号分子 1～16，分母 1、2、4、8 或 16")
        self.meter=(numerator,denominator);self.ensure_bars()

    def set_capo(self,capo):
        if type(capo) is not int or not 0<=capo<=24:raise ValueError('Capo 应为 0～24 品')
        if any(c.fret is not None and c.fret+capo>24 for c in self.cells):
            from .arrangement import PitchNote,find_fingerings
            from .music import fret_pitch
            from .timing import ADAPTIVE
            notes=[PitchNote(fret_pitch(c.string,c.fret)+capo,c.start,c.end) for c in self.cells if c.fret is not None]
            route=iter(find_fingerings(notes,self.score(),0,ADAPTIVE,.04,capo))
            cells=[]
            for cell in self.cells:
                if cell.fret is None:cells.append(cell);continue
                string,physical=next(route);cells.append(replace(cell,string=string,fret=physical-capo))
            self.cells=cells
        self.capo=capo

    def set_bar_change(self,index,bpm=None,meter=None,timbre=None):
        if not 0<=index<self.bars:raise ValueError('小节位置无效')
        change=parse_changes([{'bar':index,'bpm':bpm,'meter':meter,'timbre':timbre}])[0]
        old=self.layout;old_starts=[b.start for b in old]
        if all(value is None for value in (bpm,meter,timbre)):self.bar_changes.pop(index,None)
        else:self.bar_changes[index]=change
        new=self.layout
        if old!=new:
            def move(at):
                i=max(0,min(len(old)-1,bisect_right(old_starts,at)-1))
                return new[i].start+at-old[i].start
            cells=[];previous=F(0);relocations={}
            for cell in self.cells:
                at=max(move(cell.start),previous);relocations[cell.start]=at
                cells.append(replace(cell,start=at));previous=at+cell.beats
            self.cells=cells
            self.tempo_map=tuple(sorted({move(at):tempo for at,tempo in self.tempo_map}.items()))
            self.move_annotations(lambda t:relocations.get(t,move(t)))
        self.ensure_bars()

    def insert_bar(self,index):
        if not 0<=index<=self.bars:raise ValueError('插入小节位置无效')
        boundary=self.bar(index).start if index<self.bars else self.layout[-1].end
        self.bar_changes={i+(i>=index):replace(c,bar=i+(i>=index)) for i,c in self.bar_changes.items()}
        self.bars+=1;length=self.bar(index).beats
        self.cells=[replace(c,start=c.start+length) if c.start>=boundary else
                    replace(c,beats=c.beats+length) if c.end>boundary else c for c in self.cells]
        self.move_annotations(lambda t:t+length if t>=boundary else t)
        if self.tempo_map:
            values={at+length if at>=boundary else at:tempo for at,tempo in self.tempo_map}
            values.setdefault(F(0),self.tempo_map[0][1]);self.tempo_map=tuple(sorted(values.items()))
        self.ensure_bars()

    def copy_bar(self,index):
        measure=self.bar(index);start=measure.start;end=measure.end
        if any(c.start<start<c.end or c.start<end<c.end for c in self.cells):
            raise ValueError("本小节有跨小节延音，请先调整该音符时值再复制")
        copied=[replace(c,start=c.start+measure.beats) for c in self.cells if start<=c.start<end]
        change=self.bar_changes.get(index)
        tempo_copy={};active=None
        for at,tempo in self.tempo_map:
            if at<=start:active=tempo
            if start<at<end:tempo_copy[at+measure.beats]=tempo
        if active is not None:tempo_copy[end]=active
        self.insert_bar(index+1);self.cells+=copied
        if tempo_copy:self.tempo_map=tuple(sorted({**dict(self.tempo_map),**tempo_copy}.items()))
        if change:self.bar_changes[index+1]=replace(change,bar=index+1)
        self.ensure_bars()

    def remove_empty_bar(self,index):
        measure=self.bar(index);start=measure.start;end=measure.end
        if self.bars<=1:raise ValueError("至少保留一个小节")
        if any(c.start<end and c.end>start for c in self.cells):raise ValueError("请先清除本小节的音符，再删除空小节")
        self.cells=[replace(c,start=c.start-measure.beats) if c.start>=end else c for c in self.cells]
        removed=self.bar_changes.get(index);following=self.bar_changes.get(index+1,MeasureChange(index+1))
        self.bar_changes={i-(i>index):replace(c,bar=i-(i>index)) for i,c in self.bar_changes.items() if i!=index}
        if removed and index<self.bars-1:
            self.bar_changes[index]=MeasureChange(index,following.bpm if following.bpm is not None else removed.bpm,
                following.meter if following.meter is not None else removed.meter,
                following.timbre if following.timbre is not None else removed.timbre)
        if self.tempo_map:
            active=self.tempo_map[0][1]
            for at,tempo in self.tempo_map:
                if at>end:break
                active=tempo
            values={at-measure.beats if at>=end else at:tempo for at,tempo in self.tempo_map if not start<=at<end}
            values[start]=active;values.setdefault(F(0),active);self.tempo_map=tuple(sorted(values.items()))
        self.bars-=1

    def score(self):
        events=[];cursor=F(0)
        def rest(end):
            nonlocal cursor
            while cursor<end:
                length=min(F(128),end-cursor)
                events.append(GuitarEvent((),cursor,length,'Zero','休止',1));cursor+=length
        for cell in self.cells:
            rest(cell.start)
            events.append(GuitarEvent(() if cell.fret is None else (cell.string,),cell.start,cell.beats,
                                     'Zero' if cell.fret is None or cell.fret+self.capo==0 else ROMAN[cell.fret+self.capo-1],
                                     '休止' if cell.fret is None else str(cell.fret),1))
            cursor=cell.end
        rest(max(self.layout[-1].end,cursor))
        tempos=tuple((at,tempo*self.source_bpm/self.bpm) for at,tempo in self.tempo_map)
        score=GuitarScore(tuple(events),cursor,self.bpm,tempos,self.meter,self.bars,
                          tuple(sorted(self.bar_changes.values(),key=lambda c:c.bar)),self.default_timbre,tempos,self.capo)
        return apply_changes(score)

"""Cancellable monotonic scheduler; the preview backend never emits input."""
import math
import threading
import time


class PreviewBackend:
    def acquire_target(self):
        return "静默预演 · 不发送键盘或鼠标输入"

    def check_target(self):
        pass

    def press(self, actions):
        pass

    def release_all(self):
        pass

    def chord_down(self, chord):
        pass

    def chord_move(self,chord):
        pass

    def chord_up(self):
        pass


class Cancelled(Exception):
    pass


class Player:
    def __init__(self, emit):
        self.emit = emit
        self.lock = threading.Lock()
        self.cancel = threading.Event()
        self.thread = None
        self.paused = False
        self.pause_started = 0.0
        self.pause_total = 0.0
        self.origin = 0.0
        self._last_progress = 0.0
        self._next_target_check=0

    @property
    def running(self):
        return self.thread is not None and self.thread.is_alive()

    def start(self, score, profile, backend, countdown=0, gate=0.82):
        if self.running:
            raise ValueError("已有演奏正在进行")
        if not 0 <= countdown <= 15 or not 0.1 <= gate <= 0.98:
            raise ValueError("倒计时或按住时长比例无效")
        self.cancel.clear()
        self.paused = False
        self.pause_total = 0
        self.origin = 0
        self._last_progress = 0
        self._next_target_check=0
        self.thread = threading.Thread(target=self._run, args=(score, profile, backend, countdown, gate), daemon=True)
        self.thread.start()

    def stop(self):
        self.cancel.set()

    def toggle_pause(self):
        with self.lock:
            if not self.running or not self.origin:
                return
            if self.paused:
                self.pause_total += time.perf_counter() - self.pause_started
                self.paused = False
            else:
                self.pause_started = time.perf_counter()
                self.paused = True
            paused = self.paused
        self.emit("state", "已暂停 · F8 继续，F9 停止" if paused else "正在演奏")

    def _wait_until(self, deadline, backend, active=()):
        released = False
        while True:
            if self.cancel.is_set():
                raise Cancelled()
            with self.lock:
                paused = self.paused
                elapsed = (self.pause_started if paused else time.perf_counter()) - self.origin - self.pause_total
            sync = getattr(backend, "sync_playback", None)
            if sync:
                sync(elapsed, paused)
            if paused:
                if not released:
                    backend.release_all()
                    released = True
                self.cancel.wait(0.008)
                continue
            now=time.perf_counter()
            if now>=self._next_target_check or elapsed>=deadline:
                backend.check_target();self._next_target_check=now+.010
            if released and active:
                backend.press(active)
                released = False
            now = time.perf_counter()
            with self.lock:elapsed=now-self.origin-self.pause_total
            if now - self._last_progress >= 0.04:
                self.emit("progress", max(0, elapsed))
                self._last_progress = now
            if elapsed >= deadline:
                return
            remaining=deadline-elapsed
            if remaining>.003:time.sleep(min(.003,remaining-.0015))
            else:time.sleep(0)

    def elapsed(self):
        with self.lock:
            return (self.pause_started if self.paused else time.perf_counter())-self.origin-self.pause_total

    def _run(self, score, profile, backend, countdown, gate):
        outcome, detail = "done", "演奏完成"
        try:
            end = time.perf_counter() + countdown
            last = None
            while time.perf_counter() < end:
                remaining = math.ceil(end - time.perf_counter())
                if remaining != last:
                    self.emit("state", f"{remaining} 秒后开始，请切换到游戏的吉他界面")
                    last = remaining
                if self.cancel.wait(min(0.02, max(0, end - time.perf_counter()))):
                    raise Cancelled()
            if self.cancel.is_set():
                raise Cancelled()
            self.emit("target", backend.acquire_target())
            self.origin = time.perf_counter()
            self.emit("state", "正在演奏")
            seconds_per_beat = 60 / score.bpm
            for index, event in enumerate(score.events):
                start = float(event.start) * seconds_per_beat
                duration = float(event.beats) * seconds_per_beat
                self._wait_until(start, backend)
                actions = tuple(profile.bindings[n] for n in event.notes if n in profile.bindings)
                if self.cancel.is_set():
                    raise Cancelled()
                backend.check_target()
                backend.press(actions)
                self.emit("note", (index, event.notes))
                self._wait_until(start + duration * gate, backend, actions)
                backend.release_all()
                self._wait_until(start + duration, backend)
            self.emit("progress", score.seconds)
        except Cancelled:
            detail = "已停止 · 已释放按键"
        except Exception as error:
            outcome, detail = "error", str(error)
        finally:
            try:
                backend.release_all()
                close = getattr(backend, "close", None)
                if close:
                    close()
            except Exception as error:
                outcome, detail = "error", f"释放输入失败：{error}"
            self.origin = 0
            self.emit("note", (-1, ()))
            self.emit(outcome, detail)


class GuitarPlayer(Player):
    def start(self, score, profile, backend, countdown=0, gate=0.72, tap=0.045,timing=None):
        from .guitar import make_plan
        from .timing import SAFE
        self.timing=timing or SAFE;self.live=not isinstance(backend,PreviewBackend)
        self.transaction=False;self.pause_requested=False
        if not 0.015 <= tap <= 0.2:
            raise ValueError("按键时长应在 15～200 毫秒之间")
        if isinstance(backend,PreviewBackend):
            from .guitar import Step
            steps=[]
            for index,event in enumerate(score.events):
                start=score.seconds_at(event.start)
                duration=score.seconds_at(event.start+event.beats)-start
                steps.extend((Step(start,"preview_select",event.chord),Step(start,"note",(index,event.notes)),
                              Step(start+min(duration*gate,tap),"release")))
            steps.append(Step(score.seconds,"end"))
            from .measures import timbre_points
            steps.extend(Step(score.seconds_at(at),'preview_timbre',tone) for at,tone in timbre_points(score) if at<score.beats)
            self.plan=tuple(sorted(steps,key=lambda step:step.at))
        else:
            self.plan = make_plan(score, profile, gate, tap=tap,timing=timing)
        super().start(score, profile, backend, countdown, gate)

    def toggle_pause(self):
        if getattr(self,'live',False) and self.running and self.transaction and not self.paused:
            self.pause_requested=not self.pause_requested
            self.emit('state','将在当前拨弦释放后暂停' if self.pause_requested else '已取消待暂停请求')
            return
        super().toggle_pause()

    def _run(self, score, profile, backend, countdown, gate):
        outcome, detail = "done", "输入发送完成" if self.live else "演奏完成"
        ready={'page':-1e9,'chord_move':-1e9,'chord_down':-1e9,'chord_up':-1e9,'note':-1e9,'release':-1e9}
        hold=0;active_kind=None;note_times=[s.at for s in self.plan if s.kind=='note' and s.data[1]]
        note_holds={};pending=None
        for item in self.plan:
            if item.kind=='note' and item.data[1]:pending=(item.data[0],item.at)
            elif item.kind=='release' and pending:
                note_holds[pending[0]]=item.at-pending[1];pending=None
        max_late=0;note_count=0
        trace=getattr(backend,'trace',None)
        try:
            end, last = time.perf_counter() + countdown, None
            while time.perf_counter() < end:
                remaining = math.ceil(end - time.perf_counter())
                if remaining != last:
                    self.emit("state", f"{remaining} 秒后开始，请切换到游戏的吉他界面")
                    last = remaining
                if self.cancel.wait(min(0.02, max(0, end - time.perf_counter()))):
                    raise Cancelled()
            if self.cancel.is_set():
                raise Cancelled()
            self.emit("target", backend.acquire_target())
            self.origin = time.perf_counter() - min(0, self.plan[0].at)
            self.emit("state", "正在演奏")
            active = ()
            for step in self.plan:
                needs_guard=self.live and not (step.kind=='note' and not step.data[1])
                target=max(step.at,ready.get(step.kind,-1e9)) if needs_guard else step.at
                self._wait_until(target, backend, active)
                if self.cancel.is_set():
                    raise Cancelled()
                actual=self.elapsed()
                if self.live and step.kind=='note' and step.data[1]:
                    position=note_count
                    gap=note_times[position+1]-step.at if position+1<len(note_times) else .2
                    tolerance=min(.030,max(.008,gap*.15));late=max(0,actual-step.at)
                    if late>tolerance:
                        if trace:trace.record('timing_overrun',index=step.data[0],planned=step.at,actual=actual,lateness_ms=late*1000)
                        raise RuntimeError(f'第 {step.data[0]+1} 个事件的切换／调度迟到 {late*1000:.0f} 毫秒，已停止以免挤拍；请用自适应指法减少翻页或降低 BPM，重新开始前对齐游戏页')
                    max_late=max(max_late,late);note_count+=1
                if self.live and trace:trace.record('schedule',action=step.kind,planned=step.at,actual=actual,guard_until=target,lateness_ms=max(0,actual-step.at)*1000)
                operation_started=time.perf_counter()
                if step.kind=="preview_select":
                    self.emit("chord",step.data)
                    self.emit("page",profile.pages.get(step.data,0))
                elif step.kind=='preview_timbre':self.emit('timbre',step.data)
                elif step.kind=='mode_down':
                    self.transaction=True;backend.key_down('Z')
                    ready['mode_up']=self.elapsed()+.050
                elif step.kind=='mode_up':
                    backend.key_up('Z');settled=self.elapsed()+.130
                    for kind in ('page','chord_move','chord_down','note','timbre_down'):
                        ready[kind]=max(ready.get(kind,-1e9),settled)
                    self.emit('mode',step.data)
                elif step.kind=='timbre_down':
                    self.transaction=True;backend.key_down('V')
                    ready['timbre_up']=self.elapsed()+.040;self.emit('timbre',step.data)
                elif step.kind=='timbre_up':
                    backend.key_up('V');ready['note']=max(ready['note'],self.elapsed()+.050)
                elif step.kind == "chord_move":
                    self.transaction=True
                    backend.chord_move(step.data)
                    ready['chord_down']=self.elapsed()+self.timing.mouse_settle
                elif step.kind == "chord_down":
                    backend.chord_down(step.data)
                    ready['chord_up']=self.elapsed()+self.timing.mouse_hold
                    self.emit("chord", step.data)
                elif step.kind == "page":
                    from .profile import Binding
                    key, page = step.data
                    active = (Binding(0, "key", key),)
                    self.transaction=True;active_kind='page';hold=self.timing.page_hold
                    backend.press(active)
                    sent=self.elapsed();ready['release']=sent+hold
                    ready['page']=ready['chord_move']=sent+self.timing.page_wait
                    self.emit("page", page)
                elif step.kind == "chord_up":
                    backend.chord_up()
                    ready['note']=max(ready['note'],self.elapsed()+self.timing.after_select)
                elif step.kind == "note":
                    index, notes = step.data
                    active = tuple(profile.bindings[n] for n in notes)
                    if active:
                        self.transaction=True;active_kind='note';hold=note_holds[index]
                        backend.press(active)
                        ready['release']=self.elapsed()+hold
                    self.emit("note", (index, notes))
                elif step.kind == "release":
                    release=getattr(backend,'release_actions',None)
                    if release:release(active)
                    else:backend.release_all()
                    ready['note']=max(ready['note'],self.elapsed()+self.timing.key_gap)
                    active = ()
                    if active_kind=='note':
                        self.transaction=False
                        if self.pause_requested:
                            self.pause_requested=False;super().toggle_pause()
                    active_kind=None
                if self.live and trace and step.kind in ('chord_move','chord_down','chord_up','page','release','note','timbre_down','timbre_up'):
                    if step.kind!='note' or step.data[1]:
                        trace.record('operation',action=step.kind,duration_ms=(time.perf_counter()-operation_started)*1000)
            if self.live:
                detail=f'输入发送完成 · {note_count} 次拨弦，最大调度迟到 {max_late*1000:.1f} ms；游戏响应需另行核对'
            self.emit("progress", score.seconds)
        except Cancelled:
            detail = "已停止 · 已释放按键"
        except Exception as error:
            outcome, detail = "error", str(error)
        finally:
            try:
                backend.release_all()
                close = getattr(backend, "close", None)
                if close:
                    close()
            except Exception as error:
                outcome, detail = "error", f"释放输入失败：{error}"
            self.origin = 0
            self.transaction=False;self.pause_requested=False
            self.emit("note", (-1, ()))
            self.emit(outcome, detail)

import copy
import json
import math
from pathlib import Path
import queue
import re
import threading
from dataclasses import replace
from fractions import Fraction
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from . import __version__
from .game_profile import GameProfile, ROMAN, CHORD_NAMES, load_profile, valid_point
from .guitar import DEFAULT_TEXT, DOWN, UP, make_plan, parse_guitar,apply_capo
from .music import fret_name
from .native import Hotkeys, WindowsBackend, pick_relative_point, windows, capture_client
from .player import GuitarPlayer, PreviewBackend
from .tab import DEFAULT_TAB, parse_tab
from .demo import DEMO_BPM, DEMO_TAB
from .diagnostics import InputProbe, InputTrace
from .timing import PRESETS,LABELS,ADAPTIVE
from .measures import TONE_NAMES,parse_changes,apply_changes

BG, PAPER, INK, MUTED, LINE, ACCENT = "#edf2f6", "#ffffff", "#20394e", "#62798d", "#d8e2eb", "#b93270"
FRET_EXAMPLE = """// 品格模式：请先用 Z 切到品格模式，起始页选择第 1 页
// 数字仍是吉他弦号。I～XII 对应第 1、2 页；Zero 是第 5 页空弦
{I} 6 5 4 3 | {II} 6 5 4 3
{VII} 6 5 4 3 | {VIII} [3 2 1]:2 0:2
{Zero} 6 5 4 3 2 1 | 0:2
"""


def atomic_json(path, data):
    path = Path(path)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(path)


class App(tk.Tk):
    def __init__(self, enable_native=True, settings_dir=None):
        super().__init__()
        self.title(f"异环 · 吉他编曲器 v{__version__}")
        width = min(1240, max(800, self.winfo_screenwidth()-60))
        height = min(820, max(500, self.winfo_screenheight()-100))
        self.geometry(f"{width}x{height}")
        self.minsize(min(940,width), min(560,height))
        self.configure(bg=BG)
        self.option_add("*Font", ("Microsoft YaHei UI", 10))
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("TFrame", background=BG)
        style.configure("TLabel", background=BG, foreground=INK)
        style.configure("TButton", padding=(12, 8), foreground=INK)
        style.configure("Accent.TButton", background=ACCENT, foreground="white")
        style.map("Accent.TButton", background=[("active", "#95285c")])
        style.configure("Treeview", rowheight=29, background=PAPER, fieldbackground=PAPER, foreground=INK)
        self.messages, self.player = queue.Queue(), None
        self.player = GuitarPlayer(lambda kind, data: self.messages.put((kind, data)))
        self.input_probe=InputProbe(lambda kind,data:self.messages.put((kind,data)))
        self.last_input_trace=None
        self.current_input_trace=None
        self.tempo_source=()
        self.tempo_bpm=100
        self.time_signature=(4,4)
        self.measure_count=0
        self.bar_changes=();self.default_timbre='clean';self.playing_real=False
        self.capo=0;self.chord_changes=();self.mode_states={};self.active_mode='品格模式'
        self.tab_editor=None
        self.library_window=None
        self.game_warning=""
        self.probe_feedback=tk.StringVar(value="先选定游戏窗口，再从单键测试开始")
        self.profiles = {"和弦模式": GameProfile(), "品格模式": GameProfile.frets()}
        from .settings import read_layouts
        from .log_learning import LogEstimate
        self.settings_dir=Path(settings_dir) if settings_dir is not None else (Path(__file__).resolve().parents[1]/'settings' if enable_native else None)
        self.local_layouts=read_layouts(self.settings_dir)
        for label,profile in list(self.profiles.items()):
            if profile.mode in self.local_layouts:self.profiles[label]=copy.deepcopy(self.local_layouts[profile.mode])
        self.log_estimate=LogEstimate();self.learning_running=False
        self.learn_logs=tk.BooleanVar(value=True)
        if self.settings_dir:
            try:self.learn_logs.set(json.loads((self.settings_dir/'timing.json').read_text(encoding='utf-8')).get('enabled') is not False)
            except (OSError,ValueError,AttributeError):pass
        self.learning_info=tk.StringVar(value=self.log_estimate.description())
        self.mode = tk.StringVar(value="品格模式")
        self.notation = tk.StringVar(value="六线谱 TAB")
        self.tab_step = tk.StringVar(value="1/4")
        self.bpm = tk.StringVar(value="100")
        self.tap = tk.StringVar(value=str(ADAPTIVE.tap_ms))
        self.input_speed=tk.StringVar(value=ADAPTIVE.label)
        self.timing_hint=tk.StringVar()
        self.page = tk.StringVar(value="1")
        self.game_timbre=tk.StringVar(value='清音')
        self.game_mode=tk.StringVar(value='品格')
        self.window = tk.StringVar()
        self.status = tk.StringVar(value="先写一段曲谱，或点击圆盘插入和弦与弦号")
        self.info = tk.StringVar()
        self.target = tk.StringVar(value="预演不发输入；核对游戏当前模式与音色，模式不同时开头自动按 Z；起始页指目标模式切入后的页码")
        self.window_items = {}
        self.score, self.current_chord, self.current_notes, self.current_page = None, "I", (), 0
        self.hotkey_ids, self.hotkeys, self.pending_parse, self.elapsed = (), None, None, 0
        self.stop_label=tk.StringVar(value='停止 F9')
        self.dirty = False
        self.file_path = None
        self.enable_native = enable_native
        self.preparing_audio = False
        self.audio_cancel = threading.Event()
        self._build()
        self.editor.insert("1.0", DEFAULT_TAB)
        self.editor.edit_modified(False)
        self.editor.bind("<<Modified>>", self._edited)
        self.editor.bind("<Control-s>", lambda event: self.save_score())
        self.editor.bind("<Control-o>", lambda event: self.open_score())
        self.bind('<F9>',lambda event:self.stop(),add='+')
        self.protocol("WM_DELETE_WINDOW", self.close)
        self.after(40, self._poll)
        self.after(100, self.analyze)
        if enable_native:
            self.hotkeys = Hotkeys(lambda kind, data: self.messages.put((kind, data)))
            self.after(180, self.refresh_windows)
            self.after(250, self.refresh_learning)

    @property
    def profile(self):
        return self.profiles[self.mode.get()]

    @property
    def busy(self):
        return (self.player.running or self.preparing_audio or self.input_probe.running
                or bool(self.library_window and self.library_window.busy))

    @property
    def input_timing(self):
        base=LABELS[self.input_speed.get()]
        return self.log_estimate.timing() if base.key=='adaptive' and self.learn_logs.get() else base

    def refresh_learning(self):
        if self.learning_running:return
        self.learning_running=True
        def run():
            try:
                from .log_learning import analyze_logs
                result=analyze_logs(Path(__file__).resolve().parents[1]/'logs')
                self.messages.put(('learning_ready',result))
            except Exception as error:self.messages.put(('learning_error',str(error)))
        threading.Thread(target=run,daemon=True).start()

    def learning_changed(self):
        if self.settings_dir:
            try:
                self.settings_dir.mkdir(parents=True,exist_ok=True)
                atomic_json(self.settings_dir/'timing.json',{'enabled':self.learn_logs.get()})
            except OSError as error:self.status.set('日志调优开关未保存：'+str(error))
        if not self.busy:self.analyze()

    def timing_dialog(self):
        dialog=tk.Toplevel(self);dialog.title('日志调优 · 本机输入耗时');dialog.geometry('650x340')
        ttk.Label(dialog,text='根据实际输入耗时，提前准备下一次切换',font=('Microsoft YaHei UI',15,'bold'),padding=16).pack(anchor='w')
        ttk.Checkbutton(dialog,text='稳拍自适应使用最近日志的准备余量（下次演奏生效）',variable=self.learn_logs,command=self.learning_changed).pack(anchor='w',padx=16)
        ttk.Label(dialog,textvariable=self.learning_info,wraplength=600,padding=16).pack(anchor='w')
        ttk.Label(dialog,text='只学习本机调度和输入开销，不改 BPM、音符时值或按住时间。\nWindows 接收输入不能证明游戏发声；游戏翻页所需等待仍保留。\n关闭开关即可恢复默认余量；不会修改程序代码。',wraplength=600,padding=16).pack(anchor='w')
        ttk.Button(dialog,text='重新分析最近 20 份日志',command=self.refresh_learning).pack(anchor='e',padx=16)
        self.refresh_learning()

    @property
    def stop_shortcut(self):
        if 2 in self.hotkey_ids:return 'F9'
        if 3 in self.hotkey_ids:return 'Ctrl+Alt+F9'
        return None

    def control_hint(self,text):
        return text.replace('F9',self.stop_shortcut or '停止按钮')

    def hotkeys_changed(self,registered):
        self.hotkey_ids=tuple(registered)
        shortcut=self.stop_shortcut
        self.stop_label.set('停止 '+shortcut if shortcut else '停止')
        self._playback_compact=None;self.after_idle(self._layout_playback_bar)
        if 3 in registered:
            self.status.set('F9 被占用，已改用 Ctrl+Alt+F9 停止；可以正常演奏。')
        elif 2 not in registered:
            self.status.set('全局停止快捷键不可用，仍可演奏；点击“停止”或切出游戏即可停止。')

    def input_speed_changed(self,event=None):
        if self.busy:
            self.stop();self.status.set('已停止当前播放；新的输入档位将在下次开始时使用')
        self.tap.set(str(self.input_timing.tap_ms));self.dirty=True;self.analyze()

    def _build(self):
        header = ttk.Frame(self, padding=(24, 18, 24, 12))
        self.header=header
        header.pack(fill="x")
        ttk.Label(header, text="异环 / 吉他编曲器", font=("Microsoft YaHei UI", 21, "bold")).pack(side="left")
        ttk.Label(header, text=f"v{__version__}", foreground=MUTED).pack(side="left", padx=12)
        ttk.Button(header, text="打开曲谱", command=self.open_score).pack(side="right", padx=4)
        ttk.Button(header, text="保存曲谱", command=self.save_score).pack(side="right", padx=4)
        ttk.Button(header, text="试弹《小星星》", command=self.load_demo).pack(side="right", padx=4)
        ttk.Button(header,text="导入 MIDI",command=self.import_midi).pack(side="right",padx=4)
        self._build_playback_bar()
        controls = ttk.Frame(self, padding=(24, 0, 24, 12))
        self.controls=controls
        controls.pack(fill="x")
        ttk.Label(controls, text="演奏模式").pack(side="left")
        mode_box = ttk.Combobox(controls, textvariable=self.mode, values=list(self.profiles), state="readonly", width=10)
        mode_box.pack(side="left", padx=(6, 18))
        mode_box.bind("<<ComboboxSelected>>", self.mode_changed)
        for label, variable, low, high in (("速度 BPM", self.bpm, 20, 360), ("按键毫秒", self.tap, 15, 200), ("游戏起始页", self.page, 1, 5)):
            ttk.Label(controls, text=label).pack(side="left")
            box = ttk.Spinbox(controls, textvariable=variable, from_=low, to=high, width=5, command=self.analyze)
            if variable is self.page:self.page_box=box
            box.pack(side="left", padx=(6, 18))
            box.bind("<FocusOut>", lambda event: self.analyze())
        ttk.Button(controls, text="布局与坐标校准", command=self.calibrate).pack(side="right")
        timing_row=ttk.Frame(self,padding=(24,0,24,8));timing_row.pack(fill='x')
        ttk.Label(timing_row,text='输入速度').pack(side='left')
        self.speed_box=ttk.Combobox(timing_row,textvariable=self.input_speed,values=tuple(LABELS),state='readonly',width=22)
        self.speed_box.pack(side='left',padx=8);self.speed_box.bind('<<ComboboxSelected>>',self.input_speed_changed)
        self.library_button=ttk.Button(timing_row,text='我的曲库',command=self.open_library,style='Accent.TButton')
        self.library_button.pack(side='right')
        self.adapt_button=ttk.Button(timing_row,text='预览指法适配',command=self.adapt_fingering)
        self.adapt_button.pack(side='right',padx=8)
        ttk.Button(timing_row,text='日志调优',command=self.timing_dialog).pack(side='right')
        ttk.Label(timing_row,textvariable=self.timing_hint,foreground=INK).pack(side='left')
        target_row = ttk.Frame(self, padding=(24, 0, 24, 14))
        self.target_row=target_row
        target_row.pack(fill="x")
        ttk.Label(target_row, text="目标窗口").pack(side="left")
        self.window_box = ttk.Combobox(target_row, textvariable=self.window, state="readonly", width=38)
        self.window_box.pack(side="left", padx=8)
        ttk.Button(target_row, text="刷新窗口", command=self.refresh_windows).pack(side="left")
        ttk.Combobox(target_row,textvariable=self.game_timbre,values=tuple(TONE_NAMES.values()),state='readonly',width=6).pack(side='right')
        ttk.Label(target_row,text='游戏当前音色').pack(side='right',padx=(8,6))
        current_mode=ttk.Combobox(target_row,textvariable=self.game_mode,values=('品格','和弦'),state='readonly',width=6)
        current_mode.pack(side='right',padx=(4,8));current_mode.bind('<<ComboboxSelected>>',lambda event:self.analyze())
        ttk.Label(target_row,text='游戏当前模式').pack(side='right',padx=(8,2))
        # Reserve the fixed top controls and bottom status before giving the
        # editor the remaining space. A large Text request must not hide buttons.
        bottom = ttk.Frame(self, padding=(24,0,24,10))
        bottom.pack(side="bottom",fill="x")
        self.timeline = tk.Canvas(bottom, height=64, background=BG, highlightthickness=0)
        self.timeline.pack(fill="x",pady=(4,0))
        self.timeline.bind("<Configure>", lambda event: self.draw_timeline())
        from .widgets import StatusBanner
        self.status_banner=StatusBanner(bottom,self.status)
        self.status_banner.pack(fill='x',pady=(0,6))
        target_label = ttk.Label(bottom,textvariable=self.target,foreground=MUTED,wraplength=1100)
        target_label.pack(anchor="w")
        bottom.bind("<Configure>",lambda event: target_label.configure(wraplength=max(240,event.width-48)))
        panes = ttk.Panedwindow(self, orient="horizontal")
        panes.pack(fill="both", expand=True, padx=24)
        left, right = ttk.Frame(panes), ttk.Frame(panes)
        panes.add(left, weight=5)
        panes.add(right, weight=6)
        caption = ttk.Frame(left)
        caption.pack(fill="x", pady=(0, 8))
        ttk.Label(caption, text="曲谱", font=("Microsoft YaHei UI", 12, "bold")).pack(side="left")
        ttk.Button(caption,text="图形编谱",command=self.open_visual_editor).pack(side="right",padx=5)
        notation_box = ttk.Combobox(caption, textvariable=self.notation, values=("六线谱 TAB", "指令谱"), state="readonly", width=10)
        notation_box.pack(side="left", padx=8)
        notation_box.bind("<<ComboboxSelected>>", self.notation_changed)
        ttk.Label(caption, text="网格拍数").pack(side="left")
        step_box = ttk.Combobox(caption, textvariable=self.tab_step, width=5,
                               values=("1", "1/2", "1/3", "1/4", "1/6", "1/8", "1/12", "1/16", "1/32", "1/64"))
        step_box.pack(side="left", padx=5)
        step_box.bind("<FocusOut>", lambda event: self.analyze())
        self.editor = tk.Text(left, wrap="none", undo=True, bg=PAPER, fg=INK, insertbackground=ACCENT,
                              font=("Consolas", 12), relief="flat", padx=16, pady=16, spacing1=4, spacing3=5, width=46, height=12)
        horizontal = ttk.Scrollbar(left, orient="horizontal", command=self.editor.xview)
        horizontal.pack(side="bottom", fill="x", padx=(0, 12))
        self.editor.configure(xscrollcommand=horizontal.set)
        self.editor.tag_configure("playing", background="#f8e1eb")
        self.editor.tag_configure("comment", foreground=MUTED)
        ttk.Label(left, textvariable=self.info, foreground=MUTED, wraplength=440).pack(side="bottom",anchor="w", pady=8)
        self.editor.pack(fill="both", expand=True, padx=(0,12))
        right_heading = ttk.Frame(right)
        right_heading.pack(fill="x",pady=(0,8))
        ttk.Label(right_heading, text="游戏布局", font=("Microsoft YaHei UI", 12, "bold")).pack(side="left")
        ttk.Button(right_heading,text="写谱说明",command=self.show_notation_help).pack(side="right")
        ttk.Button(right_heading,text="输入测试",command=self.open_input_tests).pack(side="right",padx=(0,6))
        self.wheel = tk.Canvas(right, background=INK, height=250, highlightthickness=0)
        self.wheel.bind("<Configure>", lambda event: self.draw_wheel())
        self.wheel.bind("<Button-1>", self.wheel_click)
        add_row = ttk.Frame(right, padding=(0, 8))
        add_row.pack(side="bottom",fill="x")
        for text, token in (("上扫 1→6", "↑ "), ("下扫 6→1", "↓ "), ("休止 0", "0 ")):
            ttk.Button(add_row, text=text, command=lambda value=token: self.insert(value)).pack(side="left", padx=(0, 8))
        ttk.Label(right,text="TAB 数字表示品位，0 是空弦；精确节奏可逐音填写。",foreground=MUTED,wraplength=480).pack(side="bottom",anchor="w",pady=6)
        self.wheel.pack(fill="both",expand=True)
        self._vertical_compact=None
        self.bind('<Configure>',self._layout_vertical,add='+')
        self._layout_vertical()

    def _layout_vertical(self,event=None):
        if event is not None and event.widget is not self:return
        compact=self.winfo_height()<680
        if compact==self._vertical_compact:return
        self._vertical_compact=compact
        self.header.configure(padding=(24,10,24,6) if compact else (24,18,24,12))
        self.controls.configure(padding=(24,0,24,6 if compact else 12))
        self.target_row.configure(padding=(24,0,24,8 if compact else 14))
        if compact:self.timeline.pack_forget()
        else:self.timeline.pack(fill='x',pady=(4,0),before=self.status_banner)

    def _build_playback_bar(self):
        self.playback_bar = ttk.Frame(self,padding=(24,0,24,10))
        self.playback_bar.pack(fill="x")
        self.game_play_button = ttk.Button(self.playback_bar,text="5 秒后自动演奏",style="Accent.TButton",command=lambda: self.start(True))
        self.audition_button = ttk.Button(self.playback_bar,text="本地试听",command=lambda: self.start(False,audible=True))
        self.preview_button = ttk.Button(self.playback_bar,text="预演 · 不发输入",command=lambda: self.start(False))
        self.pause_button = ttk.Button(self.playback_bar,text="暂停 / 继续 F8",command=self.player.toggle_pause)
        self.stop_button = ttk.Button(self.playback_bar,textvariable=self.stop_label,command=self.stop)
        self.time_text = ttk.Label(self.playback_bar,text="00:00 / 00:00",foreground=MUTED)
        self._playback_compact = None
        self.playback_bar.bind("<Configure>",self._layout_playback_bar)
        self._layout_playback_bar()

    def _layout_playback_bar(self,event=None):
        buttons=(self.game_play_button,self.audition_button,self.preview_button,self.pause_button,self.stop_button)
        needed=sum(button.winfo_reqwidth()+8 for button in buttons)+self.time_text.winfo_reqwidth()+8
        compact=self.playback_bar.winfo_width()-48 < needed
        if compact == self._playback_compact:
            return
        self._playback_compact=compact
        for widget in (*buttons,self.time_text):
            widget.grid_forget()
        for column in range(6):
            self.playback_bar.columnconfigure(column,weight=0,minsize=0)
        if compact:
            for column in range(4):
                self.playback_bar.columnconfigure(column,weight=1)
            self.game_play_button.grid(row=0,column=0,columnspan=2,sticky="ew",padx=(0,8),pady=(0,6))
            self.audition_button.grid(row=0,column=2,sticky="ew",padx=(0,8),pady=(0,6))
            self.preview_button.grid(row=0,column=3,sticky="ew",pady=(0,6))
            self.pause_button.grid(row=1,column=0,columnspan=2,sticky="ew",padx=(0,8))
            self.stop_button.grid(row=1,column=2,sticky="ew",padx=(0,8))
            self.time_text.grid(row=1,column=3,sticky="e")
        else:
            for column,button in enumerate(buttons):
                self.playback_bar.columnconfigure(column,weight=1)
                button.grid(row=0,column=column,sticky="ew",padx=(0,8))
            self.time_text.grid(row=0,column=5,sticky="e")

    def show_notation_help(self):
        dialog=tk.Toplevel(self)
        dialog.title("写谱说明")
        dialog.geometry("620x430")
        text=tk.Text(dialog,wrap="word",padx=18,pady=18,font=("Microsoft YaHei UI",11))
        text.pack(fill="both",expand=True)
        text.insert("1.0","六线谱 TAB\n从上到下是吉他 1～6 弦；数字表示品位，0 表示空弦。\n\n逐音节奏\n每段六线谱前写：节奏: 1 1/2 1/3 3/2\n依次对应一拍、半拍、三分之一拍、一拍半。r:1/2 插入半拍休止。有节奏行时字符间距不计时；没有时按“网格拍数”计时。\n\n指令谱\n{II} 6 5:1/2 [3 2 1]:2 | {Zero} 6 | ↓ ↑ 0\n数字表示弦号，冒号后为拍数。↑ 上扫弦，↓ 下扫弦，0 为休止。\n\n演奏控制在主窗口标题下方：粉色“5 秒后自动演奏”向游戏发送输入；“本地试听”使用合成参考音；F9 停止。")
        text.configure(state="disabled")

    def open_input_tests(self):
        dialog=tk.Toplevel(self)
        dialog.title("游戏输入连接测试")
        dialog.geometry("760x535")
        dialog.transient(self)
        ttk.Label(dialog,text="先验证游戏有没有收到输入，再测试曲谱",font=("Microsoft YaHei UI",14,"bold"),padding=16).pack(anchor="w")
        ttk.Label(dialog,text=self.control_hint("主窗口先选中游戏窗口。每项会倒计时 3 秒，请切回游戏吉他界面。\n单键测试不使用鼠标坐标，也不切换模式或翻页；可用 F9 停止，切出游戏也会停止。"),wraplength=630,padding=(16,0,16,16)).pack(anchor="w")
        for kind,label,description in (
            ("key","1. 测试拨弦：数字 6 三次","不依赖校准；应听到吉他 1 弦被拨三次"),
            ("pointer","2. 测试鼠标定位","移到当前页顶部区域，不点击、不拨弦"),
            ("select","3. 测试选和弦／品位并拨弦","选择当前页顶部区域；需先校准坐标"),
            ("page","4. 测试翻页并拨弦","按当前输入档位翻到下一页；测试后需重新对齐起始页"),
        ):
            row=ttk.Frame(dialog,padding=(16,4))
            row.pack(fill="x")
            ttk.Button(row,text=label,command=lambda choice=kind:self.start_input_test(choice)).pack(side="left")
            ttk.Label(row,text=description,foreground=MUTED).pack(side="left",padx=12)
        from .widgets import StatusBanner
        StatusBanner(dialog,self.probe_feedback).pack(fill='x',padx=16,pady=8)
        row=ttk.Frame(dialog,padding=16)
        row.pack(fill="x")
        ttk.Button(row,text="查看最近输入记录",command=self.show_input_log).pack(side="left")
        ttk.Button(row,textvariable=self.stop_label,command=self.stop).pack(side="right")

    def start_input_test(self,kind):
        if self.busy:
            self.probe_feedback.set("先停止当前演奏或测试")
            return
        hwnd=self.window_items.get(self.window.get())
        if not hwnd:
            self.probe_feedback.set("请先在主窗口的“目标窗口”中选择游戏窗口")
            return
        try:
            trace=InputTrace(Path(__file__).resolve().parents[1]/"logs","connection_test:"+kind,buffered=True)
            self.last_input_trace=trace.path
            self.editor.configure(state="disabled")
            profile=copy.deepcopy(self.profile);profile.initial_page=int(self.page.get())-1
            if not 0<=profile.initial_page<profile.page_count:raise ValueError('游戏起始页无效')
            self.input_probe.start(hwnd,profile,kind,trace,timing=self.input_timing)
        except Exception as error:
            self.editor.configure(state="normal")
            self.probe_feedback.set(str(error))

    def show_input_log(self):
        if not self.last_input_trace:
            self.probe_feedback.set("尚无输入记录，请先运行连接测试或自动演奏")
            return
        if self.current_input_trace:self.current_input_trace.flush()
        dialog=tk.Toplevel(self)
        dialog.title("最近输入记录")
        dialog.geometry("850x520")
        ttk.Label(dialog,text=str(self.last_input_trace),wraplength=800,padding=10).pack(anchor="w")
        text=tk.Text(dialog,wrap="word",font=("Consolas",9),padx=10,pady=10)
        text.pack(fill="both",expand=True)
        try:
            rows=Path(self.last_input_trace).read_text(encoding="utf-8").splitlines()[-100:]
            text.insert("1.0","\n".join(rows))
        except OSError as error:
            text.insert("1.0",str(error))
        text.configure(state="disabled")

    def accept_visual_score(self,score,summary="",chord_mode=False):
        from .midi_import import score_to_tab
        if self.busy:raise ValueError("请先停止播放，再应用曲谱")
        if chord_mode:
            from .chord_score import score_to_commands
            text=score_to_commands(score);parse_guitar(text,score.bpm)
        else:
            text=score_to_tab(score);parse_tab(text,score.bpm,capo=score.capo)
        self.mode.set('和弦模式' if chord_mode else '品格模式');self.active_mode=self.mode.get()
        self.notation.set('指令谱' if chord_mode else '六线谱 TAB')
        self.tempo_source=score.base_tempo_map if score.base_tempo_map is not None else score.tempo_map
        self.tempo_bpm=score.bpm
        self.time_signature=score.time_signature
        self.measure_count=score.measures
        self.bar_changes=score.bar_changes;self.default_timbre=score.default_timbre
        self.capo=score.capo;self.chord_changes=score.chord_changes if chord_mode else ()
        self.bpm.set(f"{score.bpm:.6f}".rstrip('0').rstrip('.'))
        self.editor.delete("1.0","end")
        self.editor.insert("1.0",text)
        self.editor.edit_modified(False)
        self.dirty=True
        self.analyze()
        if summary:self.status.set(summary+("；游戏动作需检查："+self.game_warning if self.game_warning else ""))

    def adapt_fingering(self,score=None):
        if self.busy:return None
        score=score or self.analyze()
        if score is None:return None
        if self.profile.mode!='fret':return score
        from .arrangement import adapt_score
        try:adapted,report,changed=adapt_score(score,int(self.page.get())-1,self.input_timing,int(self.tap.get())/1000)
        except (ValueError,KeyError) as error:
            self.status.set('指法适配失败：'+str(error));return None
        self.adaptive_report=report
        if changed:
            separators=self.editor.cget('autoseparators')
            self.editor.configure(autoseparators=False);self.editor.edit_separator()
            try:self.accept_visual_score(adapted,report)
            finally:
                self.editor.edit_separator();self.editor.configure(autoseparators=separators)
        else:self.status.set(report)
        return self.score if changed else adapted

    def open_library(self):
        if self.library_window is not None and self.library_window.winfo_exists():
            self.library_window.deiconify();self.library_window.lift();return
        try:
            from .library_ui import LibraryWindow
            self.library_window=LibraryWindow(self)
        except OSError as error:self.status.set('无法打开曲库：'+str(error))

    def open_visual_editor(self):
        if self.busy:return
        if self.tab_editor is not None and self.tab_editor.winfo_exists():
            self.tab_editor.deiconify();self.tab_editor.lift();return
        score=self.analyze()
        if score is None:return
        try:
            if self.mode.get()=='和弦模式':
                from .chord_editor import VisualChordEditor
                VisualChordEditor(self,score,lambda score:self.accept_visual_score(score,chord_mode=True))
            else:
                from .visual_editor import VisualTabEditor
                VisualTabEditor(self,score,self.accept_visual_score)
        except ValueError as error:self.status.set(str(error))

    def import_midi(self,path=None):
        if self.busy:return
        path=path or filedialog.askopenfilename(parent=self,title="导入 MIDI",filetypes=[("MIDI 文件","*.mid *.midi")])
        if not path:return
        if self.dirty and not messagebox.askyesno("导入 MIDI","当前有未保存的修改，仍要导入新曲谱吗？",parent=self):return
        try:
            from .midi_import import inspect_midi,convert_melody
            source=inspect_midi(path)
            if not 20<=source.bpm<=360:raise ValueError("文件的起始速度超出当前支持的 20～360 BPM")
        except Exception as error:
            self.status.set("MIDI 读取失败："+str(error));return
        dialog=tk.Toplevel(self)
        dialog.title("MIDI 导入 · 选择旋律轨道")
        dialog.geometry("760x490")
        dialog.transient(self)
        ttk.Label(dialog,text=Path(path).name,font=("Microsoft YaHei UI",14,"bold"),padding=12).pack(anchor="w")
        tree=ttk.Treeview(dialog,columns=("notes","range"),show="tree headings",height=8)
        tree.heading("#0",text="轨道")
        tree.heading("notes",text="音符数")
        tree.heading("range",text="MIDI 音域")
        tree.column("#0",width=400);tree.column("notes",width=100);tree.column("range",width=170)
        tree.pack(fill="both",expand=True,padx=12)
        for track in source.tracks:
            tree.insert("","end",iid=str(track.index),text=f"{track.index} · {track.name}",values=(len(track.notes),f"{min(n.pitch for n in track.notes)}～{max(n.pitch for n in track.notes)}"))
        tree.selection_set(str(source.tracks[0].index))
        row=ttk.Frame(dialog,padding=12);row.pack(fill="x")
        transpose=tk.StringVar(value="0");highest=tk.BooleanVar(value=True)
        ttk.Label(row,text="整轨移调（半音）").pack(side="left")
        ttk.Spinbox(row,textvariable=transpose,from_=-24,to=24,width=5).pack(side="left",padx=8)
        ttk.Checkbutton(row,text="同时起音时取最高音，其余音符明确不选",variable=highest).pack(side="left")
        meter=source.signatures[0][1]
        feedback=tk.StringVar(value=f"起始 {source.bpm:g} BPM；{meter[0]}/{meter[1]}；速度节点 {len(source.tempo_map)} 个，导入后保留速度变化。鼓通道已排除。"+
                             ('包含变拍号：保留位于小节边界的标记，其余位置会在导入结果中说明。' if len(source.signatures)>1 else ''))
        ttk.Label(dialog,textvariable=feedback,wraplength=720,padding=12).pack(anchor="w")
        def accept():
            try:
                if not tree.selection():raise ValueError("先选一个轨道")
                score,report=convert_melody(source,int(tree.selection()[0]),int(transpose.get()),highest.get(),int(self.page.get())-1,
                                           timing=self.input_timing,tap=int(self.tap.get())/1000)
                self.accept_visual_score(score,report)
                dialog.destroy()
                self.open_visual_editor()
            except Exception as error:feedback.set(str(error))
        ttk.Button(dialog,text="导入为品格旋律，并打开图形编谱",command=accept).pack(anchor="e",padx=12,pady=(0,12))

    def insert(self, text):
        if self.player.running:
            return
        if self.notation.get() == "六线谱 TAB":
            self.status.set("六线谱请在对应弦行直接填写品位；扫弦等动作可切到“指令谱”编写")
            return
        self.editor.insert("insert", text)
        self.editor.focus_set()

    def example_text(self):
        if self.notation.get() == "六线谱 TAB":
            return DEFAULT_TAB
        return DEFAULT_TEXT if self.mode.get() == "和弦模式" else FRET_EXAMPLE

    def load_demo(self):
        if self.busy:
            return
        text = self.editor.get("1.0", "end-1c")
        if self.dirty and text not in (DEFAULT_TEXT, FRET_EXAMPLE, DEFAULT_TAB, DEMO_TAB) and not messagebox.askyesno("载入试弹曲", "当前有未保存的修改，仍要替换为试弹曲吗？", parent=self):
            return
        self.mode.set("品格模式")
        self.active_mode='品格模式';self.chord_changes=()
        self.notation.set("六线谱 TAB")
        self.bpm.set(str(DEMO_BPM))
        self.tempo_source=()
        self.time_signature=(4,4);self.measure_count=0
        self.bar_changes=();self.default_timbre='clean'
        self.capo=0
        self.editor.delete("1.0", "end")
        self.editor.insert("1.0", DEMO_TAB)
        self.editor.edit_modified(False)
        self.dirty = True
        self.analyze()
        self.status.set("试弹曲已载入：先点“本地试听”听参考效果；进游戏试弹只需校准 I、III、V 三个区域")

    def notation_changed(self, event=None):
        if self.player.running:
            self.player.stop()
        if self.notation.get() == "六线谱 TAB":
            self.mode.set("品格模式")
        self.mode_changed()

    def insert_example(self):
        if self.busy:
            return
        text = self.editor.get("1.0", "end-1c")
        if self.dirty and text not in (DEFAULT_TEXT, FRET_EXAMPLE, DEFAULT_TAB) and not messagebox.askyesno("载入示例", "当前有未保存的修改，仍要替换为示例曲谱吗？", parent=self):
            return
        self.editor.delete("1.0", "end")
        self.tempo_source=()
        self.time_signature=(4,4);self.measure_count=0
        self.bar_changes=();self.default_timbre='clean'
        self.capo=0
        self.chord_changes=()
        self.editor.insert("1.0", self.example_text())
        self.dirty = True
        self.analyze()

    def mode_changed(self, event=None, loaded=False):
        if self.busy:
            self.stop()
        new_mode=self.mode.get()
        if not loaded and new_mode!=self.active_mode:
            attrs=('tempo_source','tempo_bpm','time_signature','measure_count','bar_changes','default_timbre','capo','chord_changes')
            self.mode_states[self.active_mode]=({name:getattr(self,name) for name in attrs},
                self.editor.get('1.0','end-1c'),self.bpm.get(),self.page.get(),self.notation.get())
            state=self.mode_states.get(new_mode)
            if state:
                metadata,text,bpm,page,notation=state
                for name,value in metadata.items():setattr(self,name,value)
                self.bpm.set(bpm);self.page.set(page);self.notation.set(notation)
            else:
                self.tempo_source=();self.tempo_bpm=100;self.time_signature=(4,4);self.measure_count=0
                self.bar_changes=();self.default_timbre='clean';self.capo=0;self.chord_changes=()
                self.bpm.set('100');self.page.set('1')
                self.notation.set('指令谱' if new_mode=='和弦模式' else '六线谱 TAB')
                text=self.example_text()
            self.editor.delete('1.0','end');self.editor.insert('1.0',text);self.editor.edit_modified(False)
        self.active_mode=new_mode
        self.page_box.configure(to=self.profile.page_count)
        self.current_chord = "G" if self.mode.get() == "和弦模式" else "I"
        if self.mode.get() == "和弦模式":
            self.notation.set("指令谱")
            self.capo=0
        if self.editor.get("1.0", "end-1c") in (DEFAULT_TEXT, FRET_EXAMPLE, DEFAULT_TAB):
            self.editor.delete("1.0", "end")
            self.editor.insert("1.0", self.example_text())
        self.current_page = int(self.page.get()) - 1 if self.page.get().isdigit() else 0
        self.dirty = True
        self.draw_wheel()
        self.analyze()

    def _edited(self, event=None):
        if not self.editor.edit_modified():
            return
        self.editor.edit_modified(False)
        self.chord_changes=()
        self.dirty = True
        if self.pending_parse:
            self.after_cancel(self.pending_parse)
        self.pending_parse = self.after(250, self.analyze)

    def analyze(self):
        self.pending_parse = None
        if self.busy:
            return self.score
        try:
            text = self.editor.get("1.0", "end-1c")
            if self.notation.get() == "六线谱 TAB":
                if self.mode.get() != "品格模式":
                    raise ValueError("六线谱使用品格模式")
                score = parse_tab(text, float(self.bpm.get()), self.tab_step.get(),self.capo)
            else:
                score = parse_guitar(text, float(self.bpm.get()))
                if self.mode.get()=='品格模式':score=apply_capo(score,self.capo)
            if self.tempo_source:
                from .midi_import import scale_tempos
                score=replace(score,tempo_map=scale_tempos(self.tempo_source,self.tempo_bpm,score.bpm))
            score=replace(score,time_signature=self.time_signature,measures=self.measure_count)
            if self.mode.get()=='和弦模式':score=replace(score,chord_changes=self.chord_changes)
            score=apply_changes(score,self.bar_changes,self.default_timbre,score.tempo_map)
            page = int(self.page.get()) - 1
            if not 0 <= page < self.profile.page_count:
                raise ValueError(f"当前模式起始页应为 1～{self.profile.page_count}")
            self.profile.initial_page = page
            self.profile.initial_timbre=next(key for key,label in TONE_NAMES.items() if label==self.game_timbre.get())
            self.profile.initial_mode='chord' if self.game_mode.get()=='和弦' else 'fret'
            self.current_page = page
            tap = int(self.tap.get()) / 1000
            if not .015 <= tap <= .2:
                raise ValueError("按键时长应为 15～200 毫秒")
            self.game_warning=""
            timing_config=self.input_timing
            self.timing_hint.set(f'翻页＋选品约 {timing_config.change_budget(1):.2f} 秒')
            try:make_plan(score,self.profile,tap=tap,timing=timing_config)
            except ValueError as error:self.game_warning=str(error)
            self.score = score
            timing = "逐音节奏" if re.search(r"(?im)^\s*(?:rhythm|节奏)\s*[:：]", text) else "网格节奏"
            self.info.set(f"{len(score.events)} 个节奏事件 · {float(score.beats):g} 拍 · {score.seconds:.1f} 秒 · {timing}")
            self.status.set("谱面可试听；游戏动作需要调整："+self.game_warning if self.game_warning else "谱面可试听；游戏连通性请先用“输入测试”实测")
            self.draw_timeline()
            self.draw_wheel()
            return score
        except (ValueError, KeyError) as error:
            self.score = None
            self.info.set(str(error))
            self.status.set('曲谱有误：'+str(error))
            self.draw_timeline()
            return None

    def refresh_windows(self):
        if not self.enable_native:
            return
        try:
            items = windows()
            self.window_items = {f"{label}  ({i + 1})": hwnd for i, (hwnd, label) in enumerate(items)}
            self.window_box.configure(values=list(self.window_items))
            if self.window.get() not in self.window_items:
                self.window.set("")
        except Exception as error:
            self.status.set(str(error))

    def stop(self):
        if self.tab_editor is not None:self.tab_editor.stop_preview()
        if self.library_window is not None:self.library_window.stop_preview()
        self.audio_cancel.set()
        self.player.stop()
        self.input_probe.stop()

    def start(self, real, audible=False):
        if self.busy:
            return
        score = self.analyze()
        if score is None:
            self.status.set(self.info.get())
            return
        try:
            self.playing_real=real
            profile = copy.deepcopy(self.profile)
            if audible:
                if profile.mode != "fret":
                    raise ValueError("和弦音高尚未核对；请点“预演”查看动作节奏，或在游戏中试听")
                from .audio import SoundPreviewBackend
                self.preparing_audio = True
                self.audio_cancel.clear()
                self.editor.configure(state="disabled")
                self.status.set(self.control_hint("正在生成本地参考音频，可用 F9 取消…"))
                tap = int(self.tap.get()) / 1000
                def prepare():
                    try:
                        backend = SoundPreviewBackend(score, Path(__file__).resolve().parents[1]/".preview", self.audio_cancel)
                        self.messages.put(("audio_ready", (score, profile, backend, tap)))
                    except Exception as error:
                        self.messages.put(("audio_error", str(error)))
                threading.Thread(target=prepare, daemon=True).start()
                return
            if real:
                hwnd = self.window_items.get(self.window.get())
                if not hwnd:
                    raise ValueError("先在“目标窗口”中选择游戏窗口")
                if self.input_timing.key=='adaptive' and profile.mode=='fret':
                    score=self.adapt_fingering(score)
                    if score is None:return
                make_plan(score,profile,tap=int(self.tap.get())/1000,timing=self.input_timing)
                trace=InputTrace(Path(__file__).resolve().parents[1]/"logs","auto_play",buffered=True)
                trace.record("score",events=len(score.events),seconds=score.seconds,bpm=score.bpm,input_speed=self.input_timing.key)
                trace.record('timing_config',**self.input_timing.__dict__,learned_margin=self.learn_logs.get() and self.log_estimate.ready)
                if self.input_timing.key=='adaptive' and profile.mode=='fret':trace.record('adaptation',summary=getattr(self,'adaptive_report','保留当前指法'))
                self.last_input_trace=trace.path
                self.current_input_trace=trace
                backend = WindowsBackend(hwnd,profile,trace=trace)
            else:
                backend = PreviewBackend()
            self.current_page = profile.initial_page
            self.elapsed = 0
            self.editor.configure(state="disabled")
            self.player.start(score, profile, backend, countdown=5 if real else 0, tap=int(self.tap.get()) / 1000,timing=self.input_timing)
        except Exception as error:
            if self.current_input_trace and not self.player.running:
                self.current_input_trace.close();self.current_input_trace=None
            self.editor.configure(state="normal")
            self.status.set(str(error))

    def _poll(self):
        try:
            while True:
                kind, data = self.messages.get_nowait()
                if kind == "pause":
                    if self.tab_editor is not None and self.tab_editor.player.running:self.tab_editor.player.toggle_pause()
                    else:self.player.toggle_pause()
                elif kind == "stop":
                    self.stop()
                elif kind=="probe_state":
                    self.status.set(data)
                    self.probe_feedback.set(data)
                elif kind=="probe_done":
                    message,path=data
                    self.last_input_trace=Path(path)
                    self.editor.configure(state="normal")
                    self.status.set(message)
                    self.probe_feedback.set(message+"\n记录："+path)
                elif kind == "audio_ready":
                    self.preparing_audio = False
                    score, profile, backend, tap = data
                    try:
                        if self.audio_cancel.is_set():
                            backend.close()
                            self.editor.configure(state="normal")
                            self.status.set("本地试听已取消")
                        else:
                            self.elapsed = 0
                            self.current_page = profile.initial_page
                            self.player.start(score, profile, backend, tap=tap)
                    except Exception as error:
                        backend.close()
                        self.editor.configure(state="normal")
                        self.status.set(str(error))
                elif kind == "audio_error":
                    self.preparing_audio = False
                    self.editor.configure(state="normal")
                    self.status.set("本地试听已取消" if self.audio_cancel.is_set() else "试听失败：" + data)
                elif kind == "hotkeys":
                    self.hotkeys_changed(data)
                elif kind=='learning_ready':
                    self.learning_running=False;self.log_estimate=data
                    self.learning_info.set(data.description())
                    if not self.busy:
                        previous_status=self.status.get();self.analyze();self.status.set(previous_status)
                elif kind=='learning_error':
                    self.learning_running=False;self.learning_info.set('日志分析失败，继续使用默认值：'+data)
                elif kind in ("state", "done", "error"):
                    self.status.set(self.control_hint(data) if kind=='state' else data)
                    if kind in ("done", "error"):
                        if self.current_input_trace:
                            self.current_input_trace.record("playback_result",result=kind,message=data)
                            self.current_input_trace.close()
                            self.current_input_trace=None
                            if self.learn_logs.get():self.refresh_learning()
                        self.editor.configure(state="normal")
                        self.current_notes = ()
                        self.draw_wheel()
                elif kind == "target":
                    self.target.set("目标：" + data)
                elif kind == "chord":
                    self.current_chord = data
                    self.draw_wheel()
                elif kind=='timbre':
                    if self.playing_real:self.game_timbre.set(TONE_NAMES[data])
                elif kind=='mode':
                    if self.playing_real:self.game_mode.set('和弦' if data=='chord' else '品格')
                elif kind == "page":
                    self.current_page = data
                    self.draw_wheel()
                elif kind == "note":
                    index, self.current_notes = data
                    self.editor.tag_remove("playing", "1.0", "end")
                    if index >= 0 and self.score:
                        event = self.score.events[index]
                        line = event.line
                        if event.source_spans:
                            for row, column, length in event.source_spans:
                                self.editor.tag_add("playing", f"{row}.{column}", f"{row}.{column+length}")
                        else:
                            self.editor.tag_add("playing", f"{line}.0", f"{line}.end")
                        self.editor.see(f"{line}.0")
                    self.draw_wheel()
                elif kind == "progress":
                    self.elapsed = data
                    self.draw_timeline()
        except queue.Empty:
            pass
        self.after(40, self._poll)

    def draw_wheel(self):
        canvas = self.wheel
        canvas.delete("all")
        width, height = max(80, canvas.winfo_width()), max(40, canvas.winfo_height())
        content_height=height-22 if height>90 else height
        cx, cy, radius = width*.47, content_height*.5, min(width*.32,content_height*.44)
        label_size=max(7,min(17,int(radius*.12)))
        labels = [name for name in self.profile.chords if self.profile.pages[name] == self.current_page]
        if self.profile.mode == "fret" and self.current_page == 4:
            labels = ["Zero"] * 6
        self.hit_regions = []
        for slot in range(6):
            label = labels[slot] if slot < len(labels) else "—"
            selected = label == self.current_chord
            canvas.create_arc(cx-radius, cy-radius, cx+radius, cy+radius, start=60-slot*60, extent=60,
                              fill=ACCENT if selected else "#2e4b62", outline=INK, width=4)
            angle = math.radians(90 - slot * 60)
            x, y = cx + .78*radius*math.cos(angle), cy - .78*radius*math.sin(angle)
            canvas.create_text(x, y, text=label, fill="white", font=("Segoe UI",label_size,"bold"))
            if label != "—":
                self.hit_regions.append((x, y, radius*.28, "{" + label + "} "))
        inner = radius * .53
        canvas.create_oval(cx-inner, cy-inner, cx+inner, cy+inner, fill="#13293c", outline="#567083", width=3)
        for index in range(6):
            string = 6 - index
            y = cy + (index - 2.5) * inner * .27
            active = string in self.current_notes
            canvas.create_line(cx-inner*.84, y, cx+inner*.84, y, fill="#ffa1cc" if active else ACCENT,
                               width=4 if active else 2)
            if radius>=60:
                canvas.create_text(cx,y,text=f"{string} 弦  ·  键 {7-string}",fill="white",font=("Microsoft YaHei UI",8),anchor="center")
            self.hit_regions.append((cx, y, inner*.12, f"{string} "))
        if height>90:
            canvas.create_text(12,height-5,text=f"第 {self.current_page+1} 页  ·  {self.mode.get()}  ·  {'自定义坐标' if self.profile.calibrated else '待实机校准'}",
                               anchor="sw",fill="#bdd0de",font=("Microsoft YaHei UI",9))
        if height>=220 and width>=400 and self.profile.mode == "fret" and self.current_chord in (*ROMAN, "Zero"):
            fret = 0 if self.current_chord == "Zero" else ROMAN.index(self.current_chord) + 1
            canvas.create_text(width-10, 14, anchor="ne", fill="#bdd0de", font=("Microsoft YaHei UI", 9),
                               text="标准定弦参考\n" + "\n".join(f"{s}弦 {fret_name(s, fret)}" for s in range(1, 7)) + "\n待游戏实测")

    def wheel_click(self, event):
        if self.notation.get() == "六线谱 TAB":
            self.status.set("六线谱中请直接在对应弦行填写品位数字；圆盘用于显示当前演奏位置")
            return
        for x, y, radius, text in reversed(self.hit_regions):
            if (event.x-x)**2 + (event.y-y)**2 <= radius**2:
                self.insert(text)
                return

    def draw_timeline(self):
        canvas = self.timeline
        canvas.delete("all")
        if not self.score:
            return
        width = max(20, canvas.winfo_width()-4)
        for event in self.score.events:
            start=self.score.seconds_at(event.start)
            x=2+start/max(.01,self.score.seconds)*width
            w=(self.score.seconds_at(event.start+event.beats)-start)/max(.01,self.score.seconds)*width
            canvas.create_rectangle(x, 10, x+w-1, 43, fill="#f2cddd" if event.notes else LINE, outline="")
            if w > 23:
                canvas.create_text(x+w/2, 26, text=event.label, fill=INK, font=("Consolas", 9))
        x = 2 + min(1, self.elapsed / max(.01, self.score.seconds)) * width
        canvas.create_line(x, 6, x, 48, fill=ACCENT, width=2)
        canvas.create_text(2, 60, text="节奏时间线", fill=MUTED, anchor="w", font=("Microsoft YaHei UI", 9))
        def stamp(value):
            return f"{int(value)//60:02d}:{int(value)%60:02d}"
        self.time_text.configure(text=f"{stamp(self.elapsed)} / {stamp(self.score.seconds)}")

    def save_score(self,path=None):
        if self.analyze() is None:
            self.status.set('保存失败：'+self.info.get());return None
        from .library import MusicLibrary
        path = path or filedialog.asksaveasfilename(parent=self, title="保存曲谱", initialdir=str(MusicLibrary().root/'scores'),
                                                   defaultextension=".gscore", filetypes=[("吉他曲谱", "*.gscore")])
        if not path:
            return
        try:
            atomic_json(path, {"version": 2, "text": self.editor.get("1.0", "end-1c"),
                              "bpm": float(self.bpm.get()), "tap_ms": int(self.tap.get()),
                              "profile": self.profile.to_dict(), "tab_step": self.tab_step.get(),
                              "notation": "tab" if self.notation.get() == "六线谱 TAB" else "commands",
                              "tempo_map":[[str(at),tempo] for at,tempo in self.tempo_source],"tempo_bpm":self.tempo_bpm,
                              "time_signature":list(self.time_signature),"measures":self.measure_count,"input_speed":self.input_timing.key,
                              "bar_changes":[c.to_dict() for c in self.bar_changes],"default_timbre":self.default_timbre,"capo":self.capo,
                              "chord_changes":[[str(at),name] for at,name in self.chord_changes]})
            self.dirty, self.file_path = False, path
            self.status.set("曲谱已保存：" + Path(path).name)
            return Path(path)
        except (ValueError, OSError) as error:
            self.status.set("保存失败：" + str(error))

    def open_score(self,path=None):
        if self.busy:
            return
        path = path or filedialog.askopenfilename(parent=self, filetypes=[("曲谱", "*.gscore *.txt"), ("所有文件", "*.*")])
        if not path:
            return
        if self.dirty and not messagebox.askyesno("打开曲谱", "当前有未保存的修改，仍要打开另一份曲谱吗？", parent=self):
            return
        try:
            raw = Path(path).read_text(encoding="utf-8-sig")
            if Path(path).suffix.lower() == ".gscore":
                data = json.loads(raw)
                if not isinstance(data, dict) or data.get("version") not in (1,2) or not isinstance(data.get("text"), str):
                    raise ValueError("曲谱格式或版本无效")
                profile = GameProfile.from_dict(data["profile"])
                from .settings import reuse_layout
                profile=reuse_layout(profile,self.local_layouts.get(profile.mode))
                bpm, tap = float(data["bpm"]), int(data.get("tap_ms", 45))
                notation = data.get("notation", "commands")
                speed=data.get('input_speed',self.input_timing.key)
                if speed not in PRESETS:raise ValueError('输入速度档位无效')
                tempos=tuple((Fraction(str(at)),float(tempo)) for at,tempo in data.get("tempo_map",[]))
                tempo_bpm=float(data.get("tempo_bpm",bpm))
                meter=data.get('time_signature',[4,4]);measures=data.get('measures',0)
                changes=parse_changes(data.get('bar_changes',[]));tone=data.get('default_timbre','clean')
                capo=data.get('capo',0)
                from .chord_score import parse_chord_changes
                chord_marks=parse_chord_changes(data.get('chord_changes',[]))
                if type(capo) is not int or not 0<=capo<=24:raise ValueError('Capo 应为 0～24 品')
                if tone not in TONE_NAMES:raise ValueError('音色应为清音或失真')
                if (not isinstance(meter,list) or len(meter)!=2 or any(type(n) is not int for n in meter)
                    or not 1<=meter[0]<=16 or meter[1] not in (1,2,4,8,16)
                    or type(measures) is not int or not 0<=measures<=25000):
                    raise ValueError('拍号或小节数无效')
                if (any(at<0 or not 0<tempo<60_000_001 for at,tempo in tempos)
                    or not 0<tempo_bpm<=360 or (tempos and tempos[0][0]!=0)
                    or any(a[0]>=b[0] for a,b in zip(tempos,tempos[1:]))):
                    raise ValueError("速度变化数据无效")
                if notation not in ("tab", "commands"):
                    raise ValueError("不支持的曲谱写法")
                if not 20 <= bpm <= 360 or not 15 <= tap <= 200:
                    raise ValueError("速度或按键时长超出支持范围")
                mode = "和弦模式" if profile.mode == "chord" else "品格模式"
                self.profiles[mode] = profile
                self.mode.set(mode)
                self.tempo_source=tempos
                self.tempo_bpm=tempo_bpm
                self.time_signature=tuple(meter);self.measure_count=measures
                self.bar_changes=changes;self.default_timbre=tone
                self.capo=capo;self.chord_changes=chord_marks
                self.notation.set("六线谱 TAB" if notation == "tab" else "指令谱")
                self.tab_step.set(str(data.get("tab_step", "1/4")))
                self.bpm.set(f"{bpm:g}")
                self.tap.set(str(tap))
                self.input_speed.set(PRESETS[speed].label)
                self.page.set(str(profile.initial_page+1))
                self.game_timbre.set(TONE_NAMES[profile.initial_timbre])
                self.game_mode.set('和弦' if (profile.initial_mode or profile.mode)=='chord' else '品格')
                raw = data["text"]
            else:
                self.tempo_source=()
                self.time_signature=(4,4);self.measure_count=0
                self.bar_changes=();self.default_timbre='clean'
                self.capo=0
                self.chord_changes=()
                is_tab = any(re.match(r"\s*[A-Ga-g1-6]\s*\|", line) for line in raw.splitlines())
                self.notation.set("六线谱 TAB" if is_tab else "指令谱")
                if is_tab:
                    self.mode.set("品格模式")
            self.editor.delete("1.0", "end")
            self.editor.insert("1.0", raw)
            self.editor.edit_modified(False)
            self.file_path, self.dirty = path, False
            self.mode_changed(loaded=True)
            self.dirty = False
        except (ValueError, OSError, KeyError, TypeError, ZeroDivisionError) as error:
            self.status.set("打开失败：" + str(error))

    def calibrate(self):
        if self.busy:
            return
        dialog = tk.Toplevel(self)
        dialog.title("游戏布局与坐标校准")
        dialog.geometry(f'760x{min(710,self.winfo_screenheight()-90)}')
        dialog.transient(self)
        editing_mode = self.mode.get()
        working = copy.deepcopy(self.profile)
        ttk.Label(dialog, text="自动校准：3 秒内切回游戏完整吉他界面，识别六根粉色琴弦。\n识别后核对下方示意图；也可导入仅含游戏客户区的 PNG，或手动拾取。", padding=14).pack(anchor="w")
        auto_row=ttk.Frame(dialog,padding=(14,0,14,8));auto_row.pack(fill='x')
        tree = ttk.Treeview(dialog, columns=("page", "x", "y"), show="tree headings", height=7)
        tree.heading("#0", text="和弦 / 品格 / 扫弦")
        for column, label in (("page", "页码"), ("x", "横向位置"), ("y", "纵向位置")):
            tree.heading(column, text=label)
            tree.column(column, width=100, anchor="center")
        tree.column("#0", width=200)
        tree.pack(fill="both", expand=True, padx=14)
        preview=tk.Canvas(dialog,height=135,bg=PAPER,highlightthickness=0);preview.pack(fill='x',padx=14,pady=6)
        feedback = tk.StringVar(value="位置按游戏客户区保存，不包含窗口边框")
        def refresh():
            tree.delete(*tree.get_children())
            for name, point in working.chords.items():
                tree.insert("", "end", iid=name, text=name, values=(working.pages[name]+1, f"{point[0]:.4f}", f"{point[1]:.4f}"))
            tree.insert("", "end", iid="__strum", text="上下扫弦共用空白位置", values=("—", *(f"{n:.4f}" for n in working.strum_point)))
            preview.delete('all');width=700;height=135
            preview.create_rectangle(1,1,width-1,height-1,outline=LINE)
            for name,point in list(working.chords.items())[:6]:
                x,y=point[0]*width,point[1]*height
                preview.create_oval(x-4,y-4,x+4,y+4,fill=ACCENT,outline='')
                preview.create_text(x,y-12,text=name,fill=INK,font=('Segoe UI',9))
            x,y=working.strum_point[0]*width,working.strum_point[1]*height
            preview.create_oval(x-4,y-4,x+4,y+4,fill='#12879a',outline='')
            preview.create_text(x,y+13,text='扫弦点',fill=INK,font=('Microsoft YaHei UI',9))
        refresh()
        def accept_frame(frame):
            from .calibration import detect_wheel
            wheel=detect_wheel(frame);wheel.apply(working);refresh()
            feedback.set(f'已识别六根琴弦：圆心 ({wheel.x:.0f}, {wheel.y:.0f})，六个扇区已生成。请核对扫弦点位于圆盘外，再点“应用校准”；模式、音色和起始页仍按实际填写。')
        def automatic():
            hwnd=self.window_items.get(self.window.get())
            if not hwnd:feedback.set('请先在主窗口选择目标游戏窗口');return
            feedback.set('3 秒后读取所选游戏客户区，请切回完整吉他界面；不会点击或按键')
            def finish():
                if not dialog.winfo_exists():return
                try:accept_frame(capture_client(hwnd))
                except Exception as error:feedback.set(str(error))
            dialog.after(3000,finish)
        def image_calibration():
            path=filedialog.askopenfilename(parent=dialog,title='选择仅含完整游戏客户区的截图',filetypes=[('PNG 图像','*.png')])
            if not path:return
            try:
                from .calibration import from_photo
                photo=tk.PhotoImage(master=dialog,file=path);accept_frame(from_photo(photo))
            except Exception as error:feedback.set(str(error))
        ttk.Button(auto_row,text='3 秒后自动校准',command=automatic,style='Accent.TButton').pack(side='left')
        ttk.Button(auto_row,text='从 PNG 截图识别',command=image_calibration).pack(side='left',padx=8)
        def capture():
            selected = tree.selection()
            hwnd = self.window_items.get(self.window.get())
            if not selected or not hwnd:
                feedback.set("先选择主窗口中的游戏窗口，再选一个需要校准的位置")
                return
            name = selected[0]
            feedback.set(f"3 秒后拾取 {name}，请切到游戏并放好鼠标")
            def finish():
                if not dialog.winfo_exists():
                    return
                try:
                    point, size = pick_relative_point(hwnd)
                    if name == "__strum":
                        working.strum_point = point
                    else:
                        # All pages share the same six sectors: calibrate a slot once.
                        old_point = working.chords[name]
                        for selector in list(working.chords):
                            if working.chords[selector] == old_point:
                                working.chords[selector] = point
                    working.reference_size = size
                    feedback.set(f"已拾取 {name}：{point[0]:.4f}, {point[1]:.4f}")
                    refresh()
                except Exception as error:
                    feedback.set(str(error))
            dialog.after(3000, finish)
        def save():
            working.calibrated = True
            from .settings import write_layout
            try:write_layout(self.settings_dir,working)
            except OSError as error:feedback.set('校准保存失败：'+str(error));return
            self.local_layouts[working.mode]=copy.deepcopy(working)
            self.profiles[editing_mode] = working
            self.dirty = True
            self.draw_wheel()
            dialog.destroy()
        def export():
            path = filedialog.asksaveasfilename(parent=dialog, defaultextension=".json", filetypes=[("布局文件", "*.json")])
            if path:
                try:
                    atomic_json(path, working.to_dict())
                    feedback.set("布局文件已导出")
                except OSError as error:
                    feedback.set(str(error))
        def import_layout():
            nonlocal working
            path = filedialog.askopenfilename(parent=dialog, filetypes=[("布局文件", "*.json")])
            if path:
                try:
                    loaded = load_profile(path)
                    if loaded.mode != working.mode:
                        raise ValueError("导入布局的模式与当前模式不同")
                    working = loaded
                    refresh()
                except (ValueError, OSError, TypeError) as error:
                    feedback.set(str(error))
        row = ttk.Frame(dialog, padding=14)
        row.pack(fill="x")
        ttk.Button(row, text="3 秒后拾取", command=capture).pack(side="left")
        ttk.Button(row, text="导入布局", command=import_layout).pack(side="left", padx=6)
        ttk.Button(row, text="导出布局", command=export).pack(side="left")
        ttk.Button(row, text="应用校准", command=save).pack(side="right")
        ttk.Label(dialog, textvariable=feedback, wraplength=560, padding=14).pack(anchor="w")

    def close(self):
        if self.tab_editor is not None and self.tab_editor.changed:
            self.tab_editor.close()
            if self.tab_editor is not None:return
        if self.dirty and not messagebox.askyesno("关闭", "有未保存的曲谱修改，仍要关闭吗？", parent=self):
            return
        self.stop()
        self.status.set("正在释放输入…")
        def finish():
            if self.busy:
                self.after(25, finish)
                return
            if self.hotkeys:
                self.hotkeys.close()
            if self.tab_editor is not None:self.tab_editor.destroy()
            if self.library_window is not None:self.library_window.destroy()
            if self.current_input_trace:self.current_input_trace.close();self.current_input_trace=None
            for timer in self.tk.call("after", "info"):
                self.after_cancel(timer)
            self.destroy()
        finish()


def main():
    App().mainloop()

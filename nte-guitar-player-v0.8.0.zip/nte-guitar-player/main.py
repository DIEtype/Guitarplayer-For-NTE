import ctypes
import os
from pathlib import Path
import sys
import traceback

if os.name == "nt":
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except (OSError, AttributeError):
        pass

def launch():
    self_test = "--self-test" in sys.argv
    try:
        from guitar_player.bootstrap import ensure_administrator
        if not ensure_administrator(__file__):return 0
        from guitar_player.ui import App
        app = App(enable_native=not self_test)
        if self_test:
            app.withdraw()
            app.update()
            if app.analyze() is None:
                raise RuntimeError(app.info.get())
            app.dirty = False
            app.close()
            print("Startup check passed: Python, Tk, application and TAB parser are ready.")
        else:
            app.mainloop()
        return 0
    except Exception:
        details = traceback.format_exc()
        log_path = Path(__file__).resolve().with_name("startup_error.log")
        try:
            log_path.write_text(
                f"Python: {sys.version}\nExecutable: {sys.executable}\nWorking directory: {os.getcwd()}\n\n{details}",
                encoding="utf-8",
            )
        except OSError:
            pass
        print(details, file=sys.stderr)
        if os.name == "nt" and not self_test:
            ctypes.windll.user32.MessageBoxW(
                None, f"程序启动失败。\n\n报错详情已写入：\n{log_path}\n\n{details.splitlines()[-1]}",
                "吉他编曲器 · 启动失败", 0x10,
            )
        return 1

if __name__ == "__main__":
    raise SystemExit(launch())

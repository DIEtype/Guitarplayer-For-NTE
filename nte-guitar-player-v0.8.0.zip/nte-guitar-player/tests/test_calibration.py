import copy
import json
from pathlib import Path
import tempfile
import tkinter as tk
from tkinter import ttk
import unittest
from unittest.mock import patch

from guitar_player.calibration import Frame, detect_wheel, from_photo
from guitar_player.game_profile import GameProfile
from guitar_player.settings import read_layouts, write_layout, reuse_layout
from guitar_player.ui import App


def wheel_frame(w=1000, h=700, cx=700, cy=300, spacing=18, lines=6):
    pixels = bytearray(bytes((12, 25, 35)) * (w * h))
    for i in range(lines):
        y = round(cy - 2.5 * spacing + i * spacing)
        for dy in range(2):
            start = ((y + dy) * w + cx - spacing * 4) * 3
            pixels[start:start + spacing * 8 * 3] = bytes((221, 45, 135)) * (spacing * 8)
    # A wide pink sector is not a string line.
    for y in range(70, 160):
        start = (y * w + cx - 80) * 3
        pixels[start:start + 160 * 3] = bytes((200, 45, 110)) * 160
    return Frame(w, h, bytes(pixels))


class CalibrationTests(unittest.TestCase):
    def test_scaled_wheel_places_six_slots_and_keeps_song_state(self):
        for frame in (wheel_frame(), wheel_frame(1500, 900, 1060, 390, 24)):
            wheel = detect_wheel(frame)
            self.assertAlmostEqual(wheel.spacing, 18 if frame.width == 1000 else 24)
            for profile in (GameProfile(), GameProfile.frets()):
                profile.initial_page = 2; profile.initial_timbre = 'distorted'
                wheel.apply(profile)
                self.assertTrue(profile.calibrated)
                self.assertEqual(profile.reference_size, (frame.width, frame.height))
                self.assertEqual((profile.initial_page, profile.initial_timbre), (2, 'distorted'))
                self.assertEqual(len(set(profile.chords.values())), 6)
                x, y = profile.strum_point
                self.assertGreater(abs(x * (frame.width - 1) - wheel.x), wheel.radius)

    def test_incomplete_strings_and_blank_images_fail_without_mutation(self):
        profile = GameProfile(); before = copy.deepcopy(profile.to_dict())
        for frame in (wheel_frame(lines=5), Frame(1000, 700, bytes(1000 * 700 * 3))):
            with self.assertRaisesRegex(ValueError, '没有可靠识别'):
                detect_wheel(frame).apply(profile)
            self.assertEqual(profile.to_dict(), before)

    def test_bgra_capture_and_rgb_have_identical_detection(self):
        rgb = wheel_frame()
        bgra = bytearray()
        for i in range(0, len(rgb.data), 3):
            r, g, b = rgb.data[i:i + 3]; bgra.extend((b, g, r, 0))
        self.assertEqual(detect_wheel(rgb), detect_wheel(Frame(rgb.width, rgb.height, bytes(bgra), 4, True)))

    def test_settings_reuse_coordinates_without_overwriting_song_start(self):
        with tempfile.TemporaryDirectory() as folder:
            profile = GameProfile.frets(); detect_wheel(wheel_frame()).apply(profile)
            write_layout(folder, profile)
            loaded = read_layouts(folder)['fret']
            song = GameProfile.frets(); song.initial_page = 4; song.initial_timbre = 'distorted'
            reused = reuse_layout(song, loaded)
            self.assertEqual(reused.chords, loaded.chords)
            self.assertEqual((reused.initial_page, reused.initial_timbre), (4, 'distorted'))
            self.assertFalse(song.calibrated)
            self.assertFalse(reuse_layout(GameProfile(), loaded).calibrated)

    def test_malformed_settings_fall_back_and_invalid_pixels_fail(self):
        with tempfile.TemporaryDirectory() as folder:
            (Path(folder) / 'layouts.json').write_text('[]', encoding='utf-8')
            self.assertEqual(read_layouts(folder), {})
        with self.assertRaises(ValueError):Frame(1000, 700, b'broken')


class CalibrationGuiTests(unittest.TestCase):
    def test_automatic_button_applies_persists_and_survives_loading_demo(self):
        def descendants(widget):
            return [child for item in widget.winfo_children() for child in (item, *descendants(item))]
        with tempfile.TemporaryDirectory() as folder:
            app = App(enable_native=False, settings_dir=folder); app.withdraw(); app.update()
            try:
                app.window_items = {'fake game': 123}; app.window.set('fake game')
                app.calibrate()
                dialog = next(w for w in app.winfo_children() if isinstance(w, tk.Toplevel))
                dialog.after = lambda delay, callback: callback()
                buttons = [w for w in descendants(dialog) if isinstance(w, ttk.Button)]
                with patch('guitar_player.ui.capture_client', return_value=wheel_frame()) as capture:
                    next(b for b in buttons if b.cget('text') == '3 秒后自动校准').invoke()
                    capture.assert_called_once_with(123)
                next(b for b in buttons if b.cget('text') == '应用校准').invoke()
                self.assertTrue(app.profile.calibrated)
                expected = app.profile.chords.copy(); app.dirty = False
                app.open_score(Path(__file__).resolve().parents[1] / 'examples/小星星_试弹.gscore')
                self.assertEqual(app.profile.chords, expected)
                self.assertTrue(read_layouts(folder)['fret'].calibrated)
                image = tk.PhotoImage(master=app, data=b'P6\n100 100\n255\n' + bytes((12, 40, 100)) * 10000, format='ppm')
                self.assertEqual(from_photo(image).data, bytes((12, 40, 100)) * 10000)
            finally:
                app.dirty = False; app.close()


if __name__ == '__main__':unittest.main()

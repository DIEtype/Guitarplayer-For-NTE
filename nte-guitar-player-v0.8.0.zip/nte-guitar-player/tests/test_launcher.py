from pathlib import Path
import subprocess
import unittest


ROOT = Path(__file__).resolve().parents[1]


class LauncherTests(unittest.TestCase):
    def test_batch_files_have_windows_line_endings_and_ascii_content(self):
        for name in ("start.cmd", "启动吉他编曲器.cmd", "check_startup.cmd"):
            with self.subTest(name=name):
                data = (ROOT / name).read_bytes()
                data.decode("ascii")
                self.assertIn(b"\r\n", data)
                self.assertNotIn(b"\n", data.replace(b"\r\n", b""))

    def test_real_windows_launcher_from_another_directory(self):
        for name in ("start.cmd", "启动吉他编曲器.cmd"):
            with self.subTest(name=name):
                result = subprocess.run(
                    ["cmd.exe", "/d", "/c", str(ROOT / name), "--self-test"],
                    cwd=ROOT.parent, input=b"\n", capture_output=True, timeout=30,
                )
                self.assertEqual(result.returncode, 0, repr(result.stdout + result.stderr))
                self.assertIn(b"Startup check passed", result.stdout)


if __name__ == "__main__":
    unittest.main()

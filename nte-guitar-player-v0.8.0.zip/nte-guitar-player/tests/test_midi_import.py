from fractions import Fraction as F
from pathlib import Path
import tempfile
import unittest

from guitar_player.midi_import import inspect_midi,convert_melody,score_to_tab,scale_tempos,mido
from guitar_player.guitar import GuitarScore,make_plan,parse_guitar
from guitar_player.game_profile import GameProfile,ROMAN
from guitar_player.music import fret_pitch
from guitar_player.tab import parse_tab


class MidiImportTests(unittest.TestCase):
    def setUp(self):
        self.folder=tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent)
        self.addCleanup(self.folder.cleanup)

    def write_midi(self,notes,drums=False,tempos=((0,500000),),midi_type=1):
        midi=mido.MidiFile(type=midi_type,ticks_per_beat=960)
        conductor=mido.MidiTrack();midi.tracks.append(conductor)
        previous=0
        for at,tempo in tempos:
            conductor.append(mido.MetaMessage('set_tempo',tempo=tempo,time=at-previous));previous=at
        track=mido.MidiTrack();midi.tracks.append(track)
        track.append(mido.MetaMessage('track_name',name='Lead'))
        events=[]
        for pitch,start,end in notes:
            events.extend(((start,1,pitch),(end,0,pitch)))
        previous=0
        for at,on,pitch in sorted(events):
            track.append(mido.Message('note_on' if on else 'note_off',note=pitch,velocity=80 if on else 0,time=at-previous))
            previous=at
        if drums:
            drum=mido.MidiTrack();midi.tracks.append(drum)
            drum.extend((mido.Message('note_on',channel=9,note=36,velocity=90),mido.Message('note_off',channel=9,note=36,time=960)))
        path=Path(self.folder.name)/'test.mid';midi.save(path)
        return path

    def test_tracks_drums_exact_beats_and_tempo_changes(self):
        source=inspect_midi(self.write_midi([(64,0,480),(67,960,1440),(69,1920,2240)],True,((0,500000),(960,1000000))))
        self.assertEqual(len(source.tracks),1)
        self.assertEqual(source.tracks[0].name,'Lead')
        self.assertEqual(source.tracks[0].notes[-1].end,F(7,3))
        score,report=convert_melody(source,1)
        self.assertEqual([e.start for e in score.events if e.notes],[F(0),F(1),F(2)])
        self.assertEqual([e.beats for e in score.events],[F(1,2),F(1,2),F(1,2),F(1,2),F(1,3)])
        self.assertAlmostEqual(score.seconds,11/6)
        self.assertIn('速度节点 2',report)
        for event,pitch in zip((e for e in score.events if e.notes),(64,67,69)):
            fret=0 if event.chord=='Zero' else ROMAN.index(event.chord)+1
            self.assertEqual(fret_pitch(event.notes[0],fret),pitch)

    def test_polyphony_requires_explicit_reduction_and_reports_omissions(self):
        source=inspect_midi(self.write_midi([(60,0,1920),(64,0,1920),(67,960,1440)]))
        with self.assertRaisesRegex(ValueError,'同时起音'):convert_melody(source,1,highest=False)
        score,report=convert_melody(source,1,highest=True)
        self.assertEqual(len([e for e in score.events if e.notes]),2)
        self.assertEqual(score.events[0].beats,1)
        self.assertIn('同拍未选 1 音',report)
        self.assertIn('截短重叠尾音 1 处',report)

    def test_no_automatic_octave_folding(self):
        source=inspect_midi(self.write_midi([(30,0,960)]))
        with self.assertRaisesRegex(ValueError,'不会逐音折八度'):convert_melody(source,1)
        score,_=convert_melody(source,1,transpose=12)
        event=score.events[0];fret=0 if event.chord=='Zero' else ROMAN.index(event.chord)+1
        self.assertEqual(fret_pitch(event.notes[0],fret),42)

    def test_route_uses_same_fret_for_different_strings_when_possible(self):
        source=inspect_midi(self.write_midi([(65,0,960),(60,960,1920),(65,1920,2880)]))
        score,_=convert_melody(source,1)
        self.assertEqual({e.chord for e in score.events},{'I'})
        self.assertEqual([e.notes[0] for e in score.events],[1,2,1])
        self.assertFalse(any(s.kind=='page' for s in make_plan(score,GameProfile.frets())))

    def test_generated_tab_roundtrip_preserves_start_duration_pitch_and_rests(self):
        source=inspect_midi(self.write_midi([(40,240,560),(88,960,1440),(64,1680,1920)]))
        score,_=convert_melody(source,1)
        parsed=parse_tab(score_to_tab(score),score.bpm)
        self.assertEqual(parsed.beats,score.beats)
        self.assertEqual([(e.notes,e.start,e.beats) for e in parsed.events],[(e.notes,e.start,e.beats) for e in score.events])
        self.assertEqual([e.chord for e in parsed.events if e.notes],[e.chord for e in score.events if e.notes])

    def test_tempo_scaling_preserves_relative_changes(self):
        score=GuitarScore((),F(4),120,((F(0),500000),(F(2),1000000)))
        slower=GuitarScore((),F(4),60,scale_tempos(score.tempo_map,120,60))
        self.assertAlmostEqual(score.seconds_at(1),.5)
        self.assertAlmostEqual(score.seconds_at(3),2)
        self.assertAlmostEqual(slower.seconds,score.seconds*2)

    def test_missing_note_off_is_closed_at_track_end(self):
        path=self.write_midi([(64,0,960)])
        midi=mido.MidiFile(path)
        midi.tracks[1]=mido.MidiTrack([mido.Message('note_on',note=64,velocity=80),mido.MetaMessage('end_of_track',time=480)])
        midi.save(path)
        source=inspect_midi(path)
        self.assertEqual(source.tracks[0].notes[0].end,F(1,2))

    def test_unsupported_type_and_empty_file_are_rejected(self):
        with self.assertRaisesRegex(ValueError,'MIDI 2'):inspect_midi(self.write_midi([(64,0,960)],midi_type=2))
        with self.assertRaisesRegex(ValueError,'没有可导入'):inspect_midi(self.write_midi([]))

    def test_rest_allows_preparation_before_it_ends(self):
        score=parse_guitar('{I} 1:2 0:1/64 {II} 1')
        steps=make_plan(score,GameProfile.frets())
        self.assertEqual(list(steps),sorted(steps,key=lambda s:s.at))
        self.assertEqual(sum(s.kind=='chord_down' for s in steps),2)
        moves=[s for s in steps if s.kind=='chord_move']
        self.assertLess(moves[1].at,score.seconds_at(score.events[1].start))


if __name__=='__main__':unittest.main()

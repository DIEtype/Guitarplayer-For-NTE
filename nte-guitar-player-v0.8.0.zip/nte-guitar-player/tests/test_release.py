from pathlib import Path
import tempfile
import unittest

from build_release import release_files


class ReleaseTests(unittest.TestCase):
    def test_allowlist_excludes_user_content_even_if_new_folders_appear(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            keep = ('README.md', 'main.py', 'guitar_player/ui.py', 'docs/help.md', 'vendor/mido/__init__.py')
            omit = ('library/scores/private.gscore', 'logs/input.jsonl', 'settings/layouts.json',
                    'cover_build/photo.png', 'new-personal-folder/private.txt', '.env', 'fix_launcher.py',
                    'guitar_player/__pycache__/ui.pyc', 'vendor/bin/tool.exe', 'docs/private.pem')
            for name in (*keep, *omit):
                path = root / name; path.parent.mkdir(parents=True, exist_ok=True); path.write_text('test')
            self.assertEqual({str(path.relative_to(root)).replace('\\', '/') for path in release_files(root)}, set(keep))


if __name__ == '__main__':unittest.main()

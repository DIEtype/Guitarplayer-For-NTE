from dataclasses import replace
import json
from pathlib import Path
import tempfile
import unittest

from guitar_player.log_learning import analyze_logs
from guitar_player.timing import ADAPTIVE
from guitar_player.guitar import parse_guitar, make_plan
from guitar_player.game_profile import GameProfile


def session(explicit=True):
    rows = [{'event': 'session', 'purpose': 'auto_play'}, {'event': 'target', 'title': '异环'}]
    for i in range(12):
        for action in ('chord_move', 'chord_down', 'chord_up', 'note', 'release'):
            if explicit:
                rows.append({'event': 'operation', 'action': action, 'duration_ms': 8})
            else:
                rows.extend(({'event': 'schedule', 'action': action, 'perf_ns': i * 1e9,
                              'actual': i + .001, 'guard_until': i},
                             {'event': 'pointer' if action == 'chord_move' else 'send_input',
                              'perf_ns': i * 1e9 + 8e6, 'accepted': 1, 'requested': 1}))
    return rows


class LogLearningTests(unittest.TestCase):
    def estimate(self, rows):
        with tempfile.TemporaryDirectory() as folder:
            (Path(folder) / 'input-test.jsonl').write_text('\n'.join(json.dumps(row) for row in rows), encoding='utf-8')
            return analyze_logs(folder)

    def test_new_and_old_logs_produce_bounded_host_margin(self):
        for explicit in (True, False):
            estimate = self.estimate(session(explicit))
            self.assertTrue(estimate.ready)
            self.assertGreater(estimate.margin, ADAPTIVE.jitter_margin)
            self.assertLessEqual(estimate.margin, .090)
            self.assertIn('不代表游戏已发声', estimate.description())
            timing = estimate.timing()
            self.assertEqual((timing.page_wait, timing.mouse_hold, timing.after_select, timing.tap_ms),
                             (ADAPTIVE.page_wait, ADAPTIVE.mouse_hold, ADAPTIVE.after_select, ADAPTIVE.tap_ms))

    def test_preparation_advances_and_music_timestamps_stay_exact(self):
        score = parse_guitar('{I} 1 {VII} 2 {XIII} 3', 100)
        timing = self.estimate(session()).timing()
        original = make_plan(score, GameProfile.frets(), timing=ADAPTIVE, tap=.04)
        learned = make_plan(score, GameProfile.frets(), timing=timing, tap=.04)
        self.assertEqual([s.at for s in original if s.kind == 'note'], [s.at for s in learned if s.kind == 'note'])
        self.assertLess(learned[0].at, original[0].at)

    def test_rejected_input_preview_and_other_targets_cannot_train(self):
        rows = session(); rows.append({'event': 'send_input', 'requested': 1, 'accepted': 0})
        estimate = self.estimate(rows)
        self.assertFalse(estimate.ready); self.assertEqual(estimate.rejected_files, 1)
        rows = session(); rows[0]['purpose'] = 'preview'
        self.assertFalse(self.estimate(rows).ready)
        rows = session(); rows[1]['title'] = 'Other app'
        self.assertFalse(self.estimate(rows).ready)

    def test_invalid_outliers_missing_samples_and_corrupt_rows_do_not_tune(self):
        rows = session()[:2] + [{'event': 'operation', 'action': 'chord_move', 'duration_ms': value}
                               for value in (-1, float('nan'), float('inf'), 6000, '8', None)]
        self.assertEqual(self.estimate(rows).timing(), ADAPTIVE)
        self.assertFalse(self.estimate(session()[:10]).ready)
        rows = session(); rows += [{'event': 'operation', 'action': 'chord_down', 'duration_ms': 140}] * 100
        self.assertEqual(self.estimate(rows).margin, .090)


if __name__ == '__main__':unittest.main()

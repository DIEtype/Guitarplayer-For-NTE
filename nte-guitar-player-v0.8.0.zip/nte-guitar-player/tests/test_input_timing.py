import unittest
from guitar_player.guitar import make_plan,parse_guitar,GuitarError
from guitar_player.game_profile import GameProfile
from guitar_player.timing import SAFE,FAST,TURBO,PRESETS


class InputTimingTests(unittest.TestCase):
    def test_compatible_schedule_still_uses_point_three_seconds(self):
        self.assertAlmostEqual(SAFE.change_budget(1),.3)
        self.assertAlmostEqual(FAST.change_budget(1),.14)
        self.assertAlmostEqual(TURBO.change_budget(1),.08)
        self.assertAlmostEqual(FAST.change_budget(2),.22)

    def test_fast_allows_eighth_note_page_switch_without_changing_music(self):
        score=parse_guitar('{I} 1:1/2 {VII} 1:1/2',120)
        with self.assertRaisesRegex(GuitarError,'翻页需要 0.30'):make_plan(score,GameProfile.frets(),timing=SAFE)
        plan=make_plan(score,GameProfile.frets(),timing=FAST,tap=.03)
        self.assertEqual([step.at for step in plan if step.kind=='note'],[0,.25])
        self.assertEqual(plan[-1].at,.5)
        second_move=[step for step in plan if step.kind=='chord_move'][1]
        second_page=[step for step in plan if step.kind=='page'][0]
        self.assertAlmostEqual(second_move.at-second_page.at,.08)

    def test_turbo_allows_sixteenth_note_page_switch(self):
        score=parse_guitar('{I} 1:1/4 {VII} 1:1/4',120)
        with self.assertRaisesRegex(GuitarError,'翻页需要'):make_plan(score,GameProfile.frets(),timing=FAST,tap=.03)
        plan=make_plan(score,GameProfile.frets(),timing=TURBO,tap=.02)
        self.assertEqual([s.at for s in plan if s.kind=='note'],[0,.125])

    def test_even_fastest_setting_rejects_impossible_transition(self):
        with self.assertRaisesRegex(GuitarError,'过密|翻页需要'):
            make_plan(parse_guitar('{I} 1:1/64 {VII} 1:1/64',360),GameProfile.frets(),timing=TURBO,tap=.02)

    def test_order_waits_click_holds_and_releases_remain_valid(self):
        score=parse_guitar('{I} 1 {XIII} 2 {Zero} 6 {II} 1',100)
        for timing in PRESETS.values():
            plan=make_plan(score,GameProfile.frets(),timing=timing,tap=timing.tap_ms/1000)
            self.assertEqual(list(plan),sorted(plan,key=lambda step:step.at))
            moves=[s.at for s in plan if s.kind=='chord_move']
            down=[s.at for s in plan if s.kind=='chord_down'];up=[s.at for s in plan if s.kind=='chord_up']
            for move,press,release in zip(moves,down,up):
                self.assertAlmostEqual(press-move,timing.mouse_settle)
                self.assertAlmostEqual(release-press,timing.mouse_hold)
            self.assertEqual([s.at for s in plan if s.kind=='note'],[0,.6,1.2,1.8])

    def test_floating_point_boundary_is_accepted(self):
        score=parse_guitar('{I} 1:1/4 {VII} 1:1/4 {I} 1:1/4',120)
        make_plan(score,GameProfile.frets(),timing=TURBO,tap=.045)


if __name__=='__main__':unittest.main()

from dataclasses import replace
from fractions import Fraction as F
import json
from pathlib import Path
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

from guitar_player.audio import WavPreviewBackend
from guitar_player.game_profile import GameProfile
from guitar_player.guitar import parse_guitar
from guitar_player.library import MusicLibrary,clean_name,read_score,wav_info
from guitar_player.library_ui import LibraryWindow
from guitar_player.player import Cancelled
from guitar_player.ui import App
from guitar_player.widgets import notice_style

HERE=Path(__file__).resolve().parent


class Sound:
    SND_FILENAME,SND_ASYNC,SND_NODEFAULT=0x20000,1,2
    def __init__(self):self.calls=[]
    def PlaySound(self,path,flags):self.calls.append((path,flags))


class LibraryTests(unittest.TestCase):
    def test_import_copies_into_app_library_and_keeps_original_and_name_collisions(self):
        with tempfile.TemporaryDirectory(dir=HERE) as folder:
            base=Path(folder);library=MusicLibrary(base/'library');source=base/'乐曲.mid';source.write_bytes(b'MThd')
            first=library.add_file(source);second=library.add_file(source)
            self.assertEqual(first.parent,library.root/'midi');self.assertNotEqual(first,second)
            self.assertEqual(first.read_bytes(),source.read_bytes())
            self.assertEqual(library.add_file(first),first)
            self.assertEqual(len(library.items()),2)
            self.assertNotIn('/',clean_name('../乐曲:1'))
            self.assertEqual(clean_name('CON'),'_CON')

    def test_stored_wav_survives_preview_resume_and_cleanup(self):
        with tempfile.TemporaryDirectory(dir=HERE) as folder:
            library=MusicLibrary(Path(folder)/'library');score=parse_guitar('{I} 1:1/4',120)
            path=library.export_audio(score,'演示');original=path.read_bytes();sound=Sound()
            self.assertAlmostEqual(wav_info(path)[0],.275,places=3)
            backend=WavPreviewBackend(path,Path(folder)/'.preview',sound)
            backend.sync_playback(0,False);backend.sync_playback(.10,True);backend.sync_playback(.10,False)
            slice_path=Path(sound.calls[-1][0]);self.assertNotEqual(slice_path,path)
            backend.close();self.assertFalse(slice_path.exists());self.assertEqual(path.read_bytes(),original)
            other=library.export_audio(score,'演示');self.assertNotEqual(path,other)
            self.assertEqual(len(library.items()),2)

    def test_cancelled_export_leaves_no_partial_or_listed_file(self):
        with tempfile.TemporaryDirectory(dir=HERE) as folder:
            library=MusicLibrary(Path(folder)/'library');cancel=threading.Event();cancel.set()
            with self.assertRaises(Cancelled):library.export_audio(parse_guitar('{I} 1'),'cancel',cancel)
            self.assertEqual(library.items(),[]);self.assertEqual(list((library.root/'audio').iterdir()),[])

    def test_score_preview_preserves_saved_tempo_and_measure_metadata(self):
        from guitar_player.midi_import import score_to_tab
        with tempfile.TemporaryDirectory(dir=HERE) as folder:
            score=parse_guitar('{I} 1:2 {III} 2:2',120);path=Path(folder)/'saved.gscore'
            path.write_text(json.dumps({'version':1,'profile':GameProfile.frets().to_dict(),'bpm':60,
                'text':score_to_tab(score),'notation':'tab','tempo_bpm':120,'tempo_map':[['0',500000],['2',1000000]],
                'time_signature':[6,8],'measures':4}),encoding='utf-8')
            result,text=read_score(path)
            self.assertEqual((result.time_signature,result.measures),((6,8),4))
            self.assertAlmostEqual(result.seconds,6);self.assertIn('节奏:',text)

    def test_error_warning_running_and_completion_have_distinct_text_and_color(self):
        states=[notice_style(message) for message in ('试听失败：文件损坏','谱面需要调整：间隔不足','正在演奏','WAV 已保存：song.wav')]
        self.assertEqual(len({state[0] for state in states}),4)
        self.assertEqual(len({state[1] for state in states}),4)


class LibraryUITests(unittest.TestCase):
    def setUp(self):
        self.folder=tempfile.TemporaryDirectory(dir=HERE)
        self.app=App(enable_native=False);self.app.withdraw();self.app.update()
        self.sound=Sound();self.window=LibraryWindow(self.app,Path(self.folder.name)/'library',self.sound)
        self.app.library_window=self.window;self.window.withdraw();self.window.update()

    def tearDown(self):
        self.window.stop_preview()
        deadline=time.perf_counter()+5
        while self.window.busy and time.perf_counter()<deadline:self.app.update();time.sleep(.01)
        self.window.destroy();self.app.dirty=False;self.app.close();self.folder.cleanup()

    def wait_for(self,predicate):
        deadline=time.perf_counter()+5
        while not predicate() and time.perf_counter()<deadline:self.app.update();time.sleep(.01)
        self.assertTrue(predicate(),self.window.feedback.get())

    def test_save_current_export_select_preview_and_reload_without_real_audio(self):
        source=replace(parse_guitar('{I} 1:1/4 {III} 2:1/4',120),time_signature=(6,8),measures=1)
        self.app.accept_visual_score(source);self.window.name.set('测试乐曲');self.window.save_current()
        scores=list((self.window.library.root/'scores').glob('*.gscore'));self.assertEqual(len(scores),1)
        self.window.export_audio();self.wait_for(lambda:not self.window.preparing)
        audio=list((self.window.library.root/'audio').glob('*.wav'));self.assertEqual(len(audio),1)
        self.app.update();self.assertEqual(self.window.selected.path,audio[0])
        self.window.preview();self.wait_for(lambda:bool(self.sound.calls))
        self.assertTrue(self.app.busy);self.window.stop_preview();self.wait_for(lambda:not self.window.busy)
        self.assertTrue(audio[0].exists());self.assertIsNone(self.sound.calls[-1][0])
        self.window.refresh(scores[0]);self.app.update()
        with patch('guitar_player.ui.messagebox.askyesno',return_value=True):self.window.load_selected()
        self.assertEqual(Path(self.app.file_path),scores[0])
        self.assertEqual((self.app.score.time_signature,self.app.score.measures),((6,8),1))

    def test_midi_can_be_browsed_filtered_and_previewed_by_selected_track(self):
        from guitar_player.midi_import import mido
        path=Path(self.folder.name)/'lead.mid';midi=mido.MidiFile();track=mido.MidiTrack();midi.tracks.append(track)
        track.extend([mido.Message('note_on',note=65,velocity=80),mido.Message('note_off',note=65,time=120)]);midi.save(path)
        stored=self.window.library.add_file(path);self.window.refresh(stored);self.app.update()
        self.assertEqual(len(self.window.track_items),1);self.assertIn('声部',self.window.summary.get())
        self.window.preview();self.wait_for(lambda:bool(self.sound.calls))
        self.window.stop_preview();self.wait_for(lambda:not self.window.busy)
        self.assertTrue(stored.exists());self.window.search.set('不存在');self.app.update()
        self.assertEqual(self.window.tree.get_children(),())

    def test_library_actions_and_status_banner_fit_minimum_window(self):
        self.window.attributes('-alpha',0);self.window.attributes('-disabled',True)
        self.window.geometry('850x580');self.window.deiconify();self.app.update()
        for widget in (self.window.save_button,self.window.export_button,self.window.preview_button,self.window.load_button,self.window.banner):
            self.assertTrue(widget.winfo_ismapped())
            self.assertLessEqual(widget.winfo_rootx()+widget.winfo_width(),self.window.winfo_rootx()+self.window.winfo_width())
            self.assertLessEqual(widget.winfo_rooty()+widget.winfo_height(),self.window.winfo_rooty()+self.window.winfo_height())


if __name__=='__main__':unittest.main()

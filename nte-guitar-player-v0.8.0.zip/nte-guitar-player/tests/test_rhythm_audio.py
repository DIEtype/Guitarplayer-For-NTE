from array import array
from fractions import Fraction
from pathlib import Path
import tempfile
import threading
import unittest
import wave

from guitar_player.audio import RATE, SoundPreviewBackend, render_wav
from guitar_player.demo import DEMO_TAB
from guitar_player.game_profile import GameProfile
from guitar_player.guitar import GuitarError, make_plan, parse_guitar
from guitar_player.player import Cancelled
from guitar_player.tab import parse_tab

HERE = Path(__file__).resolve().parent


def tab_body(top="--1---3---5--"):
    return "\n".join(label + "|" + (top if i == 0 else "-"*len(top)) + "|" for i, label in enumerate("eBGDAE"))


class RhythmTests(unittest.TestCase):
    def test_exact_triplet_and_dotted_duration(self):
        score = parse_tab("节奏: 1/3 1/3 3/2\n" + tab_body())
        self.assertEqual([event.start for event in score.events], [0,Fraction(1,3),Fraction(2,3)])
        self.assertEqual(score.beats, Fraction(13,6))

    def test_spacing_and_grid_do_not_change_explicit_rhythm(self):
        text = "rhythm: 1/8 1/16 1/960\n" + tab_body()
        first = parse_tab(text, step_beats="1/4")
        second = parse_tab(text, step_beats="1/64")
        self.assertEqual(first.events, second.events)
        self.assertEqual(first.beats,Fraction(1,8)+Fraction(1,16)+Fraction(1,960))

    def test_explicit_rests_do_not_consume_tab_notes(self):
        score = parse_tab("节奏: r:1/2 1 r:1/4 1/2 2\n" + tab_body())
        self.assertEqual([event.notes for event in score.events], [(),(1,),(),(1,),(1,)])
        self.assertEqual(score.beats,Fraction(17,4))

    def test_invalid_rhythm_is_rejected(self):
        for row in ("1 1", "1 1 1 1", "1 0 1", "1 1/0 1", "1 NaN 1", "1 -1 1"):
            with self.subTest(row=row), self.assertRaises(GuitarError):
                parse_tab("节奏: "+row+"\n"+tab_body())

    def test_rhythm_belongs_to_following_six_lines(self):
        with self.assertRaises(GuitarError):
            parse_tab(tab_body()+"\n节奏: 1 1 1")

    def test_demo_has_fourteen_notes_and_no_page_changes(self):
        score=parse_tab(DEMO_TAB)
        self.assertEqual(len(score.events),14)
        self.assertEqual(score.beats,16)
        self.assertAlmostEqual(score.seconds,9.6)
        self.assertEqual({event.chord for event in score.events},{"I","III","V"})
        self.assertFalse(any(step.kind=="page" for step in make_plan(score,GameProfile.frets())))


class FakeSound:
    SND_FILENAME, SND_ASYNC, SND_NODEFAULT = 0x20000, 1, 2

    def __init__(self):
        self.calls=[]

    def PlaySound(self,path,flags):
        self.calls.append((path,flags))


class AudioTests(unittest.TestCase):
    def test_wav_has_correct_duration_and_reference_pitch(self):
        score=parse_guitar("{I} 1",120)
        with tempfile.TemporaryDirectory(dir=HERE) as folder:
            path=render_wav(score,Path(folder)/"tone.wav")
            with wave.open(str(path),"rb") as stream:
                self.assertEqual(stream.getframerate(),RATE)
                self.assertEqual(stream.getnchannels(),1)
                self.assertAlmostEqual(stream.getnframes()/RATE,.65,places=3)
                samples=array("h",stream.readframes(stream.getnframes()))
            crossings=[i for i in range(int(.02*RATE),int(.4*RATE)) if samples[i-1]<=0<samples[i]]
            measured=(len(crossings)-1)*RATE/(crossings[-1]-crossings[0])
            self.assertAlmostEqual(measured,349.228,delta=2)

    def test_preview_pause_resume_and_cleanup_without_real_audio(self):
        with tempfile.TemporaryDirectory(dir=HERE) as folder:
            sound=FakeSound()
            backend=SoundPreviewBackend(parse_guitar("{I} 1",120),folder,sound=sound)
            backend.sync_playback(-.02,False)
            self.assertEqual(sound.calls,[])
            backend.sync_playback(0,False)
            backend.sync_playback(.2,True)
            self.assertIsNone(sound.calls[-1][0])
            backend.sync_playback(.2,False)
            with wave.open(sound.calls[-1][0],"rb") as stream:
                self.assertAlmostEqual(stream.getnframes()/RATE,.45,places=3)
            backend.close()
            self.assertFalse(list(Path(folder).glob("*.wav")))

    def test_cancelled_render_leaves_no_partial_audio(self):
        with tempfile.TemporaryDirectory(dir=HERE) as folder:
            cancelled=threading.Event()
            cancelled.set()
            with self.assertRaises(Cancelled):
                SoundPreviewBackend(parse_guitar("{I} 1"),folder,cancelled,FakeSound())
            self.assertFalse(list(Path(folder).glob("*.wav")))


if __name__ == "__main__":
    unittest.main()

"""Export the application's chord Canvas and two editable demonstration scores."""
from fractions import Fraction as F
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from PIL import Image,ImageDraw,ImageFont
from render_editor_preview import render
from guitar_player.chord_score import ChordDocument
from guitar_player.chord_editor import VisualChordEditor,PATTERNS
from guitar_player.ui import App
from guitar_player.guitar import DOWN,UP


def main():
    app=App(enable_native=False);app.withdraw();app.update()
    app.mode.set('和弦模式');app.mode_changed();app.game_mode.set('和弦')
    easy=ChordDocument(bpm=80,bars=4)
    for bar,(chord,bass) in enumerate((('G',6),('Em',6),('C',5),('D',4))):
        easy.set_chord(bar*4,chord);easy.fill_pattern(bar,PATTERNS[0],bass)
    app.accept_visual_score(easy.score(),chord_mode=True)
    app.save_score(ROOT/'examples/和弦试弹_第一页.gscore')
    doc=ChordDocument(bpm=88,bars=4)
    for bar,chord in enumerate(('G','Cmaj7','C5','G/B')):doc.set_chord(bar*4,chord)
    doc.fill_pattern(0,PATTERNS[0],6);doc.fill_pattern(1,PATTERNS[1],5)
    for at,notes in ((8,(5,4)),(9,(3,)),(10,(UP,)),(11,(DOWN,)),(12,(5,)),(13,(3,)),(14,(DOWN,)),(15,(UP,))):
        doc.write_action(at,notes,1)
    doc.set_chord(14,'D/F#');doc.set_bar_change(2,96,None,'distorted')
    app.accept_visual_score(doc.score(),chord_mode=True)
    app.save_score(ROOT/'examples/四页和弦_拨弦与扫弦.gscore')
    editor=VisualChordEditor(app,doc.score(),lambda score:None);editor.withdraw();editor.select_cursor(0,6);editor.draw(1120)
    staff=render(editor.canvas,1120,588,app)
    image=Image.new('RGB',(2240,1450),'#edf2f6');draw=ImageDraw.Draw(image)
    heading=ImageFont.truetype('C:/Windows/Fonts/msyhbd.ttc',36)
    body=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',27)
    draw.text((40,18),'和弦伴奏   四页预设 / 拨弦与扫弦 / 小节音色标记',font=heading,fill='#213c57')
    for index,button in enumerate(editor.music_buttons.values()):image.paste(render(button,53,58,app),(40+index*120,76))
    draw.text((40,206),'箭头沿弦号表示发声顺序：上扫 1→6（向下画），下扫 6→1（向上画）。',font=body,fill='#62798d')
    image.paste(staff,(0,260));image.save(ROOT/'examples/和弦伴奏_谱面预览.png')
    editor.destroy();app.dirty=False;app.close()
    print('Exported chord Canvas, first-page practice and four-page demonstration.')


if __name__=='__main__':main()

from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock
from guitar_player.bootstrap import ensure_administrator


class BootstrapTests(unittest.TestCase):
    def api(self,admin=False,result=42):
        api=Mock();api.IsUserAnAdmin.return_value=admin;api.ShellExecuteW.return_value=result
        return api

    def test_admin_process_does_not_launch_another_copy(self):
        api=self.api(admin=True)
        self.assertTrue(ensure_administrator('main.py',argv=[],api=api))
        api.ShellExecuteW.assert_not_called()

    def test_request_uses_runas_quotes_chinese_path_and_exits_parent(self):
        api=self.api()
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as directory:
            entry=Path(directory)/'谱曲 与 空格'/'main.py'
            self.assertFalse(ensure_administrator(entry,argv=['--example','a b'],executable=Path(directory)/'python.exe',api=api))
            args=api.ShellExecuteW.call_args.args
            self.assertEqual(args[1],'runas')
            self.assertIn('"'+str(entry.resolve())+'"',args[3]);self.assertIn('"a b"',args[3])
            self.assertIn('--admin-requested',args[3]);self.assertEqual(args[4],str(entry.parent.resolve()))

    def test_prefer_pythonw_without_console_when_available(self):
        api=self.api()
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as directory:
            python=Path(directory)/'python.exe';pythonw=Path(directory)/'pythonw.exe';pythonw.touch()
            ensure_administrator('main.py',argv=[],executable=python,api=api)
            self.assertEqual(api.ShellExecuteW.call_args.args[2],str(pythonw.resolve()))

    def test_cancel_or_launch_error_does_not_continue_without_elevation(self):
        for result in (None,0,5,31,32):
            with self.subTest(result=result),self.assertRaisesRegex(RuntimeError,'管理员启动被取消'):
                ensure_administrator('main.py',argv=[],api=self.api(result=result))

    def test_failed_elevated_child_does_not_loop(self):
        api=self.api()
        with self.assertRaisesRegex(RuntimeError,'停止重复申请'):
            ensure_administrator('main.py',argv=['--admin-requested'],api=api)
        api.ShellExecuteW.assert_not_called()

    def test_self_test_and_explicit_offline_mode_never_request_uac(self):
        for argv in (['--self-test'],['--no-admin']):
            api=self.api()
            self.assertTrue(ensure_administrator('main.py',argv=argv,api=api))
            api.IsUserAnAdmin.assert_not_called();api.ShellExecuteW.assert_not_called()


if __name__=='__main__':unittest.main()

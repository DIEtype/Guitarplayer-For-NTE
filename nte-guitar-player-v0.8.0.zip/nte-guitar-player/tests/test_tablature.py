from fractions import Fraction as F
import unittest

from guitar_player.guitar import parse_guitar
from guitar_player.tablature import TabDocument,TabCell,note_duration,identify_duration,rhythm_parts
from guitar_player.midi_import import score_to_tab
from guitar_player.tab import parse_tab


class TablatureTests(unittest.TestCase):
    def test_musical_values_dots_and_triplets(self):
        self.assertEqual(note_duration(1),4)
        self.assertEqual(note_duration(8),F(1,2))
        self.assertEqual(note_duration(16,True),F(3,8))
        self.assertEqual(note_duration(8,False,True),F(1,3))
        self.assertEqual(identify_duration(F(3,2)),(4,True,False))
        self.assertEqual(identify_duration(F(1,3)),(8,False,True))

    def test_write_into_empty_bar_without_insert_button(self):
        doc=TabDocument(bars=4)
        doc.write(F(1,2),3,12,F(1,2))
        self.assertEqual(doc.at(F(1,2)),TabCell(F(1,2),F(1,2),3,12))
        score=doc.score()
        self.assertEqual(score.events[0].notes,())
        self.assertEqual(score.events[1].notes,(3,))
        self.assertEqual(score.events[1].chord,'XII')
        self.assertEqual(score.beats,16)

    def test_resize_reflows_following_notes_without_losing_any(self):
        doc=TabDocument([TabCell(F(0),F(1),1,2),TabCell(F(1),F(1),2,3)],bars=1)
        doc.resize(0,F(4))
        self.assertEqual([c.start for c in doc.cells],[0,4])
        self.assertEqual(doc.bars,2)
        doc.resize(0,F(1,2))
        self.assertEqual([c.start for c in doc.cells],[0,F(1,2)])

    def test_insert_at_blank_space_pushes_only_when_needed(self):
        doc=TabDocument([TabCell(F(2),F(1),1,3)],bars=1)
        doc.write(0,1,1,F(1,2));self.assertEqual(doc.cells[1].start,2)
        doc.write(F(1),1,5,F(2));self.assertEqual(doc.cells[2].start,3)

    def test_inserting_inside_held_note_is_explicitly_rejected(self):
        doc=TabDocument([TabCell(F(0),F(2),1,3)])
        with self.assertRaisesRegex(ValueError,'前一个音符'):doc.write(F(1),2,5,F(1))
        self.assertEqual(len(doc.cells),1)

    def test_meter_changes_rebar_without_changing_music(self):
        doc=TabDocument([TabCell(F(0),F(1),1,3),TabCell(F(3),F(2),2,5)],bars=1)
        before=list(doc.cells)
        doc.set_meter(6,8)
        self.assertEqual(doc.bar_beats,3);self.assertEqual(doc.bars,2)
        self.assertEqual(doc.cells,before)
        self.assertEqual(doc.score().time_signature,(6,8))

    def test_cross_bar_note_remains_one_attack_in_export(self):
        doc=TabDocument([TabCell(F(3),F(3),1,12)],bars=2)
        score=doc.score()
        self.assertEqual(len([e for e in score.events if e.notes]),1)
        parsed=parse_tab(score_to_tab(score))
        notes=[e for e in parsed.events if e.notes]
        self.assertEqual((notes[0].start,notes[0].beats),(3,3))

    def test_copy_measure_and_remove_empty_measure(self):
        doc=TabDocument([TabCell(F(0),F(1),1,1),TabCell(F(4),F(1),1,3)],bars=3)
        doc.copy_bar(0)
        self.assertEqual([(c.start,c.fret) for c in doc.cells],[(0,1),(4,1),(8,3)])
        self.assertEqual(doc.bars,4)
        doc.remove_empty_bar(3);self.assertEqual(doc.bars,3)
        with self.assertRaisesRegex(ValueError,'清除'):doc.remove_empty_bar(0)

    def test_copy_bar_with_tied_note_does_not_silently_split_it(self):
        doc=TabDocument([TabCell(F(3),F(2),1,3)],bars=2)
        with self.assertRaisesRegex(ValueError,'跨小节延音'):doc.copy_bar(0)

    def test_bpm_scales_tempo_curve_and_snapshot_restores_settings(self):
        doc=TabDocument(bpm=120,bars=1,tempo_map=((F(0),500000),(F(2),1000000)))
        state=doc.snapshot();self.assertEqual(doc.score().seconds,3)
        doc.bpm=60;doc.set_meter(3,4)
        self.assertEqual(doc.score().seconds,4)
        doc.restore(state)
        self.assertEqual((doc.bpm,doc.meter,doc.bars),(120,(4,4),1))

    def test_explicit_rest_and_delete_preserve_later_placement(self):
        doc=TabDocument([TabCell(F(1),F(1),2,3)],bars=1)
        doc.write(0,1,None,F(1,2));doc.delete(F(0))
        self.assertEqual(doc.cells,[TabCell(F(1),F(1),2,3)])

    def test_import_reconstructs_gaps_and_more_than_one_measure(self):
        score=parse_guitar('{I} 1 0:2 {III} 2:6')
        doc=TabDocument.from_score(score)
        self.assertEqual(len(doc.cells),2)
        self.assertEqual(doc.cells[1].start,3)
        self.assertEqual(doc.bars,4)
        self.assertEqual([e.start for e in doc.score().events if e.notes],[0,3])

    def test_implicit_rests_fill_the_bar_and_respect_tied_notes(self):
        doc=TabDocument([TabCell(F(1,2),F(1,2),1,3),TabCell(F(3),F(2),2,5)],bars=2)
        self.assertEqual(doc.rest_spans(0),[(F(0),F(1,2)),(F(1),F(2))])
        self.assertEqual(doc.rest_spans(1),[(F(5),F(3))])
        for gap in (F(5,4),F(1,3),F(7,16),F(1,960)):
            self.assertEqual(sum(rhythm_parts(gap)),gap)


if __name__=='__main__':unittest.main()

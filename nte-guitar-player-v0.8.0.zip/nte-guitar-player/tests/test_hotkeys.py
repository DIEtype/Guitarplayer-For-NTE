import unittest
from unittest.mock import Mock,patch

from guitar_player.native import Hotkeys


class HotkeyAPI:
    def __init__(self,available,messages=()):
        self.available=set(available);self.messages=list(messages);self.requested=[];self.released=[]
    def RegisterHotKey(self,hwnd,ident,modifiers,key):
        self.requested.append((ident,modifiers,key));return ident in self.available
    def UnregisterHotKey(self,hwnd,ident):self.released.append(ident)
    def PeekMessageW(self,message,*_):
        if not self.messages:return 0
        message._obj.wParam=self.messages.pop(0);return 1


class HotkeyTests(unittest.TestCase):
    def run_hotkeys(self,available,messages=()):
        api=HotkeyAPI(available,messages);events=[]
        hotkeys=Hotkeys.__new__(Hotkeys);hotkeys.emit=lambda kind,data:events.append((kind,data))
        hotkeys.stop_event=Mock();hotkeys.stop_event.wait.side_effect=(False,True)
        with patch('guitar_player.native.user32',return_value=api):hotkeys._run()
        return api,events

    def test_available_f9_does_not_reserve_a_second_stop_shortcut(self):
        api,events=self.run_hotkeys((1,2),(2,))
        self.assertEqual([r[0] for r in api.requested],[1,2])
        self.assertEqual(events,[('hotkeys',(1,2)),('stop',None)])
        self.assertEqual(api.released,[1,2])

    def test_f9_conflict_uses_ctrl_alt_f9_and_dispatches_stop(self):
        api,events=self.run_hotkeys((1,3),(3,))
        self.assertIn((3,0x4003,0x78),api.requested)
        self.assertEqual(events,[('hotkeys',(1,3)),('stop',None)])
        self.assertEqual(api.released,[1,3])

    def test_no_registered_shortcuts_reports_availability_without_failure(self):
        api,events=self.run_hotkeys(())
        self.assertEqual(events,[('hotkeys',())]);self.assertEqual(api.released,[])

    def test_pause_conflict_does_not_disable_available_stop_key(self):
        _,events=self.run_hotkeys((2,),(2,))
        self.assertEqual(events,[('hotkeys',(2,)),('stop',None)])


if __name__=='__main__':unittest.main()

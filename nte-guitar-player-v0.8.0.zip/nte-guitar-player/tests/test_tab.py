from fractions import Fraction
import unittest

from guitar_player.game_profile import GameProfile
from guitar_player.guitar import GuitarError, make_plan
from guitar_player.tab import DEFAULT_TAB, parse_tab


def tab(*bodies):
    return "\n".join(label + "|" + body + "|" for label, body in zip("eBGDAE", bodies))


class TabTests(unittest.TestCase):
    def test_default_tab_can_be_scheduled(self):
        score = parse_tab(DEFAULT_TAB, 100, "1/4")
        self.assertEqual(score.beats, 8)
        self.assertEqual(score.events[0].notes, ())
        self.assertEqual(score.events[1].notes, (1,))
        self.assertEqual(score.events[1].chord, "Zero")
        steps = make_plan(score, GameProfile.frets())
        self.assertEqual([step.data[0] for step in steps if step.kind == "page"], ["R", "T", "R", "T", "R"])

    def test_two_digit_frets_and_grid_time(self):
        score = parse_tab(tab("--12--24", "--------", "--------", "--------", "--------", "--------"), 120, "1/2")
        self.assertEqual(score.events[1].chord, "XII")
        self.assertEqual(score.events[1].start, 1)
        self.assertEqual(score.events[2].chord, "XXIV")
        self.assertEqual(score.events[2].start, 3)
        self.assertEqual(score.events[1].source_spans, ((1, 4, 2),))

    def test_same_fret_double_stop(self):
        score = parse_tab(tab("--2---", "--2---", "------", "------", "------", "------"))
        self.assertEqual(score.events[-1].notes, (1, 2))
        self.assertEqual(len(score.events[-1].source_spans), 2)

    def test_different_fret_chord_requires_arrangement(self):
        with self.assertRaisesRegex(GuitarError, "同拍跨品位"):
            parse_tab(tab("--3---", "--0---", "------", "------", "------", "------"))

    def test_alignment_and_invalid_fret(self):
        for text in (tab("--25--", "------", "------", "------", "------", "------"),
                     tab("----", "-----", "----", "----", "----", "----"),
                     "e|--0--|", tab("--2h3-", "------", "------", "------", "------", "------")):
            with self.subTest(text=text), self.assertRaises(GuitarError):
                parse_tab(text)

    def test_multiple_blocks_accumulate_beats(self):
        block = tab("0---", "----", "----", "----", "----", "----")
        score = parse_tab(block + "\n\n" + block, 100, "1/4")
        self.assertEqual(score.beats, 2)
        self.assertEqual(score.events[1].start, 1)

    def test_page_three_and_four_reach_all_frets(self):
        profile = GameProfile.frets()
        self.assertEqual(len(profile.chords), 25)
        self.assertEqual(profile.pages["XIII"], 2)
        self.assertEqual(profile.pages["XXIV"], 3)
        steps = make_plan(parse_tab(tab("24------", "--------", "--------", "--------", "--------", "--------")), profile)
        self.assertEqual([step.data[0] for step in steps if step.kind == "page"], ["R", "R"])

    def test_bad_grid_value(self):
        with self.assertRaises(GuitarError):
            parse_tab(DEFAULT_TAB, step_beats="1/0")


if __name__ == "__main__":
    unittest.main()

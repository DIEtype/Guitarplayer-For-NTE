from fractions import Fraction as F
from pathlib import Path
import json
import tempfile
import unittest
from unittest.mock import patch

from guitar_player.arrangement import adapt_score,transition_count
from guitar_player.game_profile import GameProfile,ROMAN
from guitar_player.guitar import parse_guitar,make_plan
from guitar_player.music import fret_pitch
from guitar_player.player import GuitarPlayer
from guitar_player.timing import ADAPTIVE
from guitar_player.diagnostics import InputTrace


class Clock:
    def __init__(self):self.now=100.
    def read(self):return self.now
    def sleep(self,seconds):self.now+=max(seconds,.0001)


class Cancel:
    def __init__(self,clock):self.clock=clock;self.cancelled=False
    def is_set(self):return self.cancelled
    def set(self):self.cancelled=True
    def wait(self,seconds):self.clock.sleep(seconds);return self.cancelled


class FakeLiveBackend:
    def __init__(self,clock,click_delay=0,key_delay=0):
        self.clock=clock;self.click_delay=click_delay;self.key_delay=key_delay
        self.calls=[];self.held=False
    def check_target(self):pass
    def acquire_target(self):return 'fake game'
    def chord_move(self,name):self.calls.append(('move',self.clock.now,name))
    def chord_down(self,name):
        self.clock.sleep(self.click_delay)
        self.calls.append(('down',self.clock.now,name));self.held=True
    def chord_up(self):self.calls.append(('up',self.clock.now));self.held=False
    def press(self,actions):
        self.calls.append(('press',self.clock.now,tuple(a.key for a in actions)))
        self.held=bool(actions);self.clock.sleep(self.key_delay)
    def release_all(self):self.calls.append(('release',self.clock.now));self.held=False


class AdaptiveTests(unittest.TestCase):
    def pitches(self,score):
        return [fret_pitch(e.notes[0],0 if e.chord=='Zero' else ROMAN.index(e.chord)+1) for e in score.events if e.notes]

    def test_observed_page_hopping_pattern_can_stay_on_one_page(self):
        sequence=['VIII','III','VIII','XV']*8+['XX']
        source=parse_guitar(' '.join('{'+fret+'} 1:1/2' for fret in sequence),168)
        adapted,report,changed=adapt_score(source,0,ADAPTIVE,.04)
        self.assertGreater(changed,0)
        self.assertGreater(transition_count(source,0),30)
        self.assertLessEqual(transition_count(adapted,0),2)
        self.assertEqual(self.pitches(source),self.pitches(adapted))
        self.assertEqual([(e.start,e.beats) for e in source.events],[(e.start,e.beats) for e in adapted.events])
        make_plan(adapted,GameProfile.frets(),timing=ADAPTIVE,tap=.04)
        self.assertIn('音高、起音与时值保持',report)

    def test_rest_tempo_and_measure_metadata_survive(self):
        from dataclasses import replace
        score=replace(parse_guitar('{VIII} 1:1/2 0:1/3 {III} 1:2',120),
                      tempo_map=((F(0),500000),(F(1),1000000)),time_signature=(6,8),measures=3)
        result,_,_=adapt_score(score,0,ADAPTIVE,.04)
        self.assertEqual((result.tempo_map,result.time_signature,result.measures,result.beats),
                         (score.tempo_map,score.time_signature,score.measures,score.beats))
        self.assertEqual(result.events[1],score.events[1])

    def test_polyphony_is_preserved_without_silent_simplification(self):
        score=parse_guitar('{I} [1 2]')
        result,report,changed=adapt_score(score,0,ADAPTIVE,.04)
        self.assertEqual((result,changed),(score,0));self.assertIn('保留原指法',report)

    def run_clocked(self,score,click_delay=0,key_delay=0,backend_class=FakeLiveBackend):
        clock=Clock();backend=backend_class(clock,click_delay,key_delay);messages=[]
        player=GuitarPlayer(lambda kind,data:messages.append((kind,data)))
        player.live=True;player.timing=ADAPTIVE;player.transaction=False;player.pause_requested=False
        player.plan=make_plan(score,GameProfile.frets(),timing=ADAPTIVE,tap=.04)
        player.cancel=Cancel(clock)
        with patch('guitar_player.player.time.perf_counter',side_effect=clock.read),patch('guitar_player.player.time.sleep',side_effect=clock.sleep):
            player._run(score,GameProfile.frets(),backend,0,.72)
        return backend,messages

    def test_late_click_does_not_compress_its_actual_hold_or_confirm_wait(self):
        backend,messages=self.run_clocked(parse_guitar('{I} 1',100),click_delay=.025)
        down=next(c[1] for c in backend.calls if c[0]=='down')
        up=next(c[1] for c in backend.calls if c[0]=='up')
        press=next(c[1] for c in backend.calls if c[0]=='press')
        self.assertGreaterEqual(up-down,ADAPTIVE.mouse_hold-1e-9)
        self.assertGreaterEqual(press-up,ADAPTIVE.after_select-1e-9)
        self.assertEqual(messages[-1][0],'done')

    def test_slow_input_call_does_not_shorten_note_press(self):
        backend,messages=self.run_clocked(parse_guitar('{I} 1',100),key_delay=.02)
        press=next(c[1] for c in backend.calls if c[0]=='press')
        release=next(c[1] for c in backend.calls if c[0]=='release' and c[1]>=press)
        self.assertGreaterEqual(release-press,.06-1e-9)
        self.assertFalse(backend.held);self.assertEqual(messages[-1][0],'done')

    def test_page_hold_and_page_wait_follow_the_actual_input_completion(self):
        backend,messages=self.run_clocked(parse_guitar('{VII} 1',100),key_delay=.02)
        page_press=next(c[1] for c in backend.calls if c[0]=='press' and c[2]==('T',))
        page_release=next(c[1] for c in backend.calls if c[0]=='release' and c[1]>=page_press)
        move=next(c[1] for c in backend.calls if c[0]=='move')
        self.assertGreaterEqual(page_release-page_press,.02+ADAPTIVE.page_hold-1e-9)
        self.assertGreaterEqual(move-page_press,.02+ADAPTIVE.page_wait-1e-9)
        self.assertEqual(messages[-1][0],'done')

    def test_large_stall_stops_before_rushing_overdue_notes(self):
        backend,messages=self.run_clocked(parse_guitar('{I} 1 {II} 1',100),click_delay=.2)
        self.assertFalse(any(c[0]=='press' for c in backend.calls))
        self.assertFalse(backend.held);self.assertEqual(messages[-1][0],'error')
        self.assertIn('停止以免挤拍',messages[-1][1])

    def test_tone_change_keeps_actual_v_hold_during_overlapping_fret_selection(self):
        from guitar_player.tablature import TabDocument,TabCell
        class ToneBackend(FakeLiveBackend):
            def __init__(self,*args):super().__init__(*args);self.keys=set()
            def key_down(self,key):
                self.clock.sleep(self.key_delay);self.keys.add(key);self.calls.append(('tone_down',self.clock.now,key))
            def key_up(self,key):self.calls.append(('tone_up',self.clock.now,key));self.keys.discard(key)
            def release_actions(self,actions):
                self.calls.append(('release',self.clock.now));self.held=False
            def release_all(self):super().release_all();self.keys.clear()
        doc=TabDocument([TabCell(F(0),F(1),1,1),TabCell(F(1),F(1),1,2)],bpm=120,meter=(1,4),bars=2)
        doc.set_bar_change(1,timbre='distorted')
        backend,messages=self.run_clocked(doc.score(),key_delay=.04,backend_class=ToneBackend)
        down=next(c[1] for c in backend.calls if c[0]=='tone_down')
        up=next(c[1] for c in backend.calls if c[0]=='tone_up')
        self.assertGreaterEqual(up-down,.04-1e-9)
        last_note=[c[1] for c in backend.calls if c[0]=='press'][-1]
        self.assertGreaterEqual(last_note-up,.05-1e-9)
        self.assertFalse(backend.keys);self.assertEqual(messages[-1][0],'done')

    def test_fast_native_note_durations_are_not_silently_shrunk(self):
        with self.assertRaisesRegex(ValueError,'连续拨弦过密'):
            make_plan(parse_guitar('{I} 1:1/64 1:1/64',360),GameProfile.frets(),timing=ADAPTIVE,tap=.04)

    def test_buffered_trace_flushes_in_order_with_monotonic_stamps(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as directory:
            trace=InputTrace(directory,'buffered_test',buffered=True)
            for i in range(100):trace.record('sample',index=i)
            self.assertTrue(trace.flush());trace.close()
            rows=[json.loads(line) for line in trace.path.read_text(encoding='utf-8').splitlines()]
            self.assertEqual([r['index'] for r in rows[1:]],list(range(100)))
            self.assertEqual([r['perf_ns'] for r in rows],sorted(r['perf_ns'] for r in rows))


if __name__=='__main__':unittest.main()

from dataclasses import replace
from fractions import Fraction as F
from pathlib import Path
import tempfile
import unittest
import wave

from guitar_player.tablature import TabDocument,TabCell
from guitar_player.measures import MeasureChange,crop_from_measure,timbre_points,parse_changes
from guitar_player.guitar import make_plan
from guitar_player.game_profile import GameProfile
from guitar_player.timing import ADAPTIVE
from guitar_player.audio import render_wav
from guitar_player.native import WindowsBackend
from guitar_player.profile import Binding


class MeasureTests(unittest.TestCase):
    def document(self):
        doc=TabDocument([TabCell(F(i*4),F(1),1,i+1) for i in range(4)],bpm=120,bars=5)
        doc.set_bar_change(1,80,(3,4),'distorted')
        doc.set_bar_change(3,150,(6,8),'clean')
        return doc

    def test_changes_inherit_and_meter_reflows_following_bar_contents(self):
        doc=self.document()
        self.assertEqual([b.start for b in doc.layout],[0,4,7,10,13])
        self.assertEqual([c.start for c in doc.cells],[0,4,7,10])
        self.assertEqual([b.meter for b in doc.layout],[(4,4),(3,4),(3,4),(6,8),(6,8)])
        score=doc.score();self.assertAlmostEqual(score.seconds,8.9)
        self.assertEqual(timbre_points(score),((0,'clean'),(4,'distorted'),(10,'clean')))
        self.assertAlmostEqual(score.seconds_at(10),6.5)
        self.assertAlmostEqual(float(score.beat_at_seconds(6.9)),11,places=5)

    def test_unset_all_fields_restores_inherited_defaults_without_losing_notes(self):
        doc=self.document();doc.set_bar_change(1)
        self.assertEqual([b.start for b in doc.layout],[0,4,8,12,15])
        self.assertEqual([c.start for c in doc.cells],[0,4,8,12])
        self.assertNotIn(1,doc.bar_changes)
        self.assertEqual(timbre_points(doc.score()),((0,'clean'),))

    def test_insert_before_moves_notes_and_annotations_together(self):
        doc=self.document();original=[(c.start,c.fret) for c in doc.cells]
        doc.insert_bar(1)
        self.assertEqual([b.start for b in doc.layout],[0,4,8,11,14,17])
        self.assertEqual([(c.start,c.fret) for c in doc.cells],[(0,1)]+[(at+4,fret) for at,fret in original[1:]])
        self.assertEqual(set(doc.bar_changes),{2,4})
        self.assertEqual(timbre_points(doc.score()),((0,'clean'),(8,'distorted'),(14,'clean')))

    def test_insert_after_inherits_current_meter_and_preserves_crossing_tie(self):
        doc=TabDocument([TabCell(F(3),F(3),1,5)],bpm=120,bars=3)
        doc.insert_bar(1)
        self.assertEqual(doc.cells,[TabCell(F(3),F(7),1,5)])
        self.assertEqual(len([e for e in doc.score().events if e.notes]),1)
        doc=self.document();doc.insert_bar(2)
        self.assertEqual(doc.bar(2).beats,3)
        self.assertEqual([c.start for c in doc.cells],[0,4,10,13])
        self.assertEqual(set(doc.bar_changes),{1,4})

    def test_insert_and_remove_retime_original_midi_tempo_nodes(self):
        doc=TabDocument(bpm=120,bars=3,tempo_map=((F(0),500000),(F(4),750000),(F(8),400000)))
        original=doc.tempo_map;doc.insert_bar(1)
        self.assertEqual(doc.tempo_map,((0,500000),(8,750000),(12,400000)))
        doc.remove_empty_bar(1);self.assertEqual(doc.tempo_map,original)

    def test_removing_changed_empty_bar_keeps_following_effective_settings(self):
        doc=TabDocument(bars=4);doc.set_bar_change(1,90,(3,4),'distorted')
        doc.remove_empty_bar(1)
        self.assertEqual((doc.bar_changes[1].bpm,doc.bar(1).meter,doc.bar_changes[1].timbre),(90,(3,4),'distorted'))

    def test_snapshot_and_score_roundtrip_keep_independent_defaults_and_marks(self):
        doc=self.document();state=doc.snapshot();score=doc.score()
        result=TabDocument.from_score(score)
        self.assertEqual(result.snapshot(),state)
        result.set_bar_change(1);result.restore(state);self.assertEqual(result.snapshot(),state)

    def test_crop_carries_active_tempo_meter_and_tone_and_rebases_future_marks(self):
        source=self.document().score();cropped,offset=crop_from_measure(source,2)
        self.assertEqual(offset,7);self.assertEqual(cropped.bpm,80)
        self.assertEqual((cropped.time_signature,cropped.default_timbre,cropped.measures),((3,4),'distorted',3))
        self.assertEqual([e.start for e in cropped.events if e.notes],[0,3])
        self.assertAlmostEqual(cropped.seconds,source.seconds-source.seconds_at(offset))
        self.assertEqual(timbre_points(cropped),((0,'distorted'),(3,'clean')))

    def test_crop_includes_continuation_only_once_at_preview_start(self):
        doc=TabDocument([TabCell(F(3),F(3),1,12)],bars=2)
        score,offset=crop_from_measure(doc.score(),1)
        notes=[e for e in score.events if e.notes]
        self.assertEqual((offset,len(notes),notes[0].start,notes[0].beats),(4,1,0,2))

    def test_marker_validation_rejects_invalid_or_duplicate_fields(self):
        for data in ([{'bar':1,'bpm':0}],[{'bar':1,'meter':[3,3]}],[{'bar':1,'timbre':'other'}],[{'bar':1},{'bar':1}]):
            with self.subTest(data=data),self.assertRaises(ValueError):parse_changes(data)

    def test_native_plan_toggles_only_at_effective_tone_changes(self):
        score=self.document().score();plan=make_plan(score,GameProfile.frets(),timing=ADAPTIVE,tap=.04)
        down=[s for s in plan if s.kind=='timbre_down'];up=[s for s in plan if s.kind=='timbre_up']
        self.assertEqual([s.data for s in down],['distorted','clean'])
        for a,b in zip(down,up):self.assertAlmostEqual(b.at-a.at,.04)
        self.assertLess(down[0].at,score.seconds_at(4));self.assertLess(up[0].at,score.seconds_at(4))
        clean=TabDocument(bars=1).score();profile=GameProfile.frets();profile.initial_timbre='distorted'
        self.assertEqual(len([s for s in make_plan(clean,profile) if s.kind=='timbre_down']),1)

    def test_selective_releases_do_not_cut_the_v_key_or_drop_its_tracking(self):
        backend=WindowsBackend.__new__(WindowsBackend);backend.held_keys=[];backend.held_buttons=set();calls=[]
        backend.check_target=lambda:None;backend._send=lambda entries:calls.extend(entries)
        backend._key=lambda key,up=False:('key',key,up);backend._button=lambda button,up=False:('mouse',button,up)
        backend.key_down('V');backend.press((Binding(1,'key','6'),));backend.held_buttons.add('left')
        backend.chord_up();self.assertEqual(backend.held_keys,['V','6'])
        backend.release_actions((Binding(1,'key','6'),));self.assertEqual(backend.held_keys,['V'])
        self.assertNotIn(('key','V',True),calls)
        backend.key_up('V');self.assertEqual(backend.held_keys,[]);self.assertEqual(calls[-1],('key','V',True))

    def test_markers_after_shortened_text_do_not_extend_the_playback_plan(self):
        doc=TabDocument([TabCell(F(0),F(1),1,1)],bars=4)
        doc.set_bar_change(3,timbre='distorted')
        score=replace(doc.score(),beats=F(1),events=doc.score().events[:1])
        plan=make_plan(score,GameProfile.frets(),timing=ADAPTIVE,tap=.04)
        self.assertFalse(any(step.kind=='timbre_down' for step in plan))
        self.assertLessEqual(plan[-1].at,score.seconds)

    def test_reference_audio_changes_tone_at_mark_but_keeps_timing(self):
        doc=TabDocument([TabCell(F(0),F(1),1,3),TabCell(F(1),F(1),1,3)],bpm=120,meter=(1,4),bars=2)
        clean=doc.score();doc.set_bar_change(1,timbre='distorted');marked=doc.score()
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as folder:
            paths=[render_wav(score,Path(folder)/f'{i}.wav') for i,score in enumerate((clean,marked))]
            data=[]
            for path in paths:
                with wave.open(str(path),'rb') as stream:data.append(stream.readframes(stream.getnframes()))
            self.assertEqual(len(data[0]),len(data[1]));split=int(.5*22050)*2
            self.assertEqual(data[0][:split],data[1][:split]);self.assertNotEqual(data[0][split:],data[1][split:])

    def test_midi_meter_changes_at_bar_boundaries_are_preserved(self):
        from guitar_player.midi_import import MidiSource,MidiTrack,MidiNote,convert_melody
        track=MidiTrack(0,'旋律',[MidiNote(65,F(at),F(at+1),80,0) for at in (0,4,7)])
        source=MidiSource(Path('unused.mid'),[track],((F(0),500000),),((F(0),(4,4)),(F(4),(3,4)),(F(7),(6,8))))
        score,report=convert_melody(source,0);doc=TabDocument.from_score(score)
        self.assertEqual([(c.bar,c.meter) for c in score.bar_changes],[(1,(3,4)),(2,(6,8))])
        self.assertEqual([b.start for b in doc.layout[:3]],[0,4,7]);self.assertIn('已保留 2 处',report)

    def test_midi_off_boundary_meter_is_reported(self):
        from guitar_player.midi_import import MidiSource,MidiTrack,MidiNote,convert_melody
        source=MidiSource(Path('unused.mid'),[MidiTrack(0,'旋律',[MidiNote(65,F(0),F(1),80,0)])],
                          ((F(0),500000),),((F(0),(4,4)),(F(1,2),(3,4))))
        score,report=convert_melody(source,0)
        self.assertEqual(score.bar_changes,());self.assertIn('无法按小节边界放置 1 处',report)


if __name__=='__main__':unittest.main()

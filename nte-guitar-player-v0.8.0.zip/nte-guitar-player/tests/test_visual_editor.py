from fractions import Fraction as F
import tempfile
from pathlib import Path
import time
import unittest
from types import SimpleNamespace
from unittest.mock import patch

from guitar_player.ui import App
from guitar_player.visual_editor import VisualTabEditor
from guitar_player.guitar import parse_guitar


class VisualEditorTests(unittest.TestCase):
    def setUp(self):
        self.app=App(enable_native=False);self.app.withdraw();self.app.update()
        self.applied=[]
        self.editor=VisualTabEditor(self.app,parse_guitar('{I} 1 {III} 2'),self.applied.append)
        self.editor.withdraw();self.editor.draw()

    def tearDown(self):
        self.editor.destroy() if not self.editor.closed else None
        self.app.dirty=False;self.app.close()

    def digits(self,text):
        for char in text:self.editor.key(SimpleNamespace(char=char))

    def test_empty_staff_click_then_type_inserts_note_directly(self):
        self.editor.clear()
        left,top,width=self.editor.bar_boxes[0]
        self.editor.click(SimpleNamespace(x=left+58,y=top+55+2*22))
        self.digits('24')
        cell=self.editor.doc.at(F(0))
        self.assertEqual((cell.string,cell.fret),(3,24))
        self.editor.choose_value(8)
        self.assertEqual(self.editor.doc.at(F(0)).beats,F(1,2))
        self.editor.move_horizontal(1);self.digits('2')
        self.assertEqual(self.editor.doc.at(F(1,2)).fret,2)

    def test_click_blank_second_measure_and_type(self):
        self.editor.clear()
        left,top,width=self.editor.bar_boxes[1]
        self.editor.click(SimpleNamespace(x=left+58,y=top+55))
        self.digits('12')
        self.assertEqual(self.editor.doc.at(F(4)).fret,12)
        self.assertEqual(self.editor.doc.bars,4)

    def test_note_buttons_dots_triplets_resize_without_set_button(self):
        self.editor.choose_value(8)
        self.editor.triplet_var.set(True);self.editor.choose_modifiers()
        self.assertEqual(self.editor.doc.at(0).beats,F(1,3))
        self.assertEqual(self.editor.doc.cells[1].start,F(1,3))
        self.editor.triplet_var.set(False);self.editor.dot_var.set(True);self.editor.choose_modifiers()
        self.assertEqual(self.editor.doc.at(0).beats,F(3,4))

    def test_bpm_meter_multiple_measures_undo_redo_and_apply(self):
        self.editor.bpm.set('132');self.editor.numerator.set('6');self.editor.denominator.set('8')
        self.editor.settings_changed();self.editor.add_bar()
        self.assertEqual((self.editor.doc.bpm,self.editor.doc.meter,self.editor.doc.bars),(132,(6,8),5))
        self.editor.undo();self.assertEqual(self.editor.doc.bars,4)
        self.editor.redo();self.assertEqual(self.editor.doc.bars,5)
        self.editor.apply()
        score=self.applied[0]
        self.assertEqual((score.bpm,score.time_signature,score.measures),(132,(6,8),5))
        self.assertEqual(score.beats,15)

    def test_cursor_crosses_measure_and_grows_score(self):
        self.editor.clear();self.editor.select_cursor(15,2);self.digits('7')
        self.editor.move_horizontal(1)
        self.assertEqual((self.editor.at,self.editor.doc.bars),(16,5))
        self.digits('9');self.assertEqual(self.editor.doc.at(16).fret,9)

    def test_delete_clear_and_undo(self):
        before=tuple(self.editor.doc.cells)
        self.editor.delete();self.assertEqual(len(self.editor.doc.cells),1)
        self.editor.undo();self.assertEqual(tuple(self.editor.doc.cells),before)
        self.editor.clear();self.assertFalse(self.editor.doc.cells)
        self.editor.undo();self.assertEqual(tuple(self.editor.doc.cells),before)

    def test_invalid_bpm_does_not_apply_or_lose_score(self):
        self.editor.bpm.set('bad');self.assertFalse(self.editor.apply())
        self.assertFalse(self.applied)
        self.assertEqual(self.editor.doc.bpm,100)

    def test_rhythm_is_vector_symbols_instead_of_per_note_beat_labels(self):
        self.editor.choose_value(16)
        texts=[self.editor.canvas.itemcget(item,'text') for item in self.editor.canvas.find_all() if self.editor.canvas.type(item)=='text']
        self.assertFalse(any('拍' in text for text in texts))
        self.assertTrue(any(self.editor.canvas.type(item)=='line' for item in self.editor.canvas.find_all()))
        self.assertEqual(len(self.editor.music_buttons),7)

    def test_preview_uses_local_audio_and_stop_cleans_up(self):
        from test_rhythm_audio import FakeSound
        from guitar_player.audio import SoundPreviewBackend
        sound=FakeSound()
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as directory:
            def factory(score,cache,cancel):return SoundPreviewBackend(score,directory,cancel,sound)
            with patch('guitar_player.audio.SoundPreviewBackend',side_effect=factory):
                self.editor.preview()
                deadline=time.monotonic()+8
                while not sound.calls and time.monotonic()<deadline:
                    self.app.update();time.sleep(.01)
                self.assertTrue(sound.calls,self.editor.feedback.get())
                self.editor.stop_preview()
                while self.editor.player.running and time.monotonic()<deadline:
                    self.app.update();time.sleep(.01)
                self.assertFalse(self.editor.player.running)
                self.assertIsNone(sound.calls[-1][0]);self.assertFalse(list(Path(directory).glob('*.wav')))

    def test_normal_short_window_keeps_footer_and_music_buttons_visible(self):
        self.app.attributes('-alpha',0);self.app.attributes('-disabled',True)
        self.app.deiconify();self.editor.attributes('-alpha',0);self.editor.attributes('-disabled',True)
        self.editor.geometry('900x600');self.editor.deiconify();self.app.update()
        for widget in [self.editor.preview_button,*self.editor.music_buttons.values()]:
            self.assertTrue(widget.winfo_ismapped())
            self.assertLessEqual(widget.winfo_rooty()+widget.winfo_height(),self.editor.winfo_rooty()+self.editor.winfo_height())
        self.assertGreater(self.editor.canvas.winfo_height(),200)

    def test_visual_melody_rejects_polyphony_explicitly(self):
        with self.assertRaisesRegex(ValueError,'单音旋律'):
            VisualTabEditor(self.app,parse_guitar('{I} [1 2]'),lambda score:None)

    def test_insert_before_after_and_undo_move_bar_marks_with_notes(self):
        from guitar_player.tablature import TabDocument,TabCell
        self.editor.doc=TabDocument([TabCell(F(4),F(1),1,7)],bars=3)
        self.editor.select_cursor(4)
        self.editor.set_measure_change(90,(3,4),'distorted')
        self.editor.insert_bar(False)
        self.assertEqual(self.editor.doc.cells[0].start,8)
        self.assertEqual(self.editor.doc.bar_changes[2].timbre,'distorted')
        self.editor.undo();self.assertEqual(self.editor.doc.cells[0].start,4)
        self.editor.insert_bar(True);self.assertEqual(self.editor.doc.bar(2).beats,3)
        self.assertEqual(self.editor.doc.bars,4)

    def test_tone_shortcut_adds_visible_bar_annotation_and_preserves_other_marks(self):
        self.editor.select_cursor(4)
        self.editor.set_measure_change(140,(3,4),'distorted')
        self.editor.key(SimpleNamespace(char='v'))
        mark=self.editor.doc.bar_changes[1]
        self.assertEqual((mark.bpm,mark.meter,mark.timbre),(140,(3,4),'clean'))
        labels=[self.editor.canvas.itemcget(item,'text') for item in self.editor.canvas.find_withtag('measure_mark')]
        self.assertTrue(any('清音' in label and '140' in label and '3/4' in label for label in labels))
        self.editor.undo();self.assertEqual(self.editor.doc.bar_changes[1].timbre,'distorted')

    def test_preview_from_current_bar_rebases_audio_but_keeps_original_play_cursor(self):
        from test_rhythm_audio import FakeSound
        from guitar_player.audio import SoundPreviewBackend
        from guitar_player.tablature import TabDocument,TabCell
        doc=TabDocument([TabCell(F(0),F(1),1,1),TabCell(F(4),F(1),1,5)],bpm=120,bars=3)
        doc.set_bar_change(1,90,(3,4),'distorted');self.editor.doc=doc
        self.editor.bpm.set('120');self.editor.select_cursor(5)
        captured=[];sound=FakeSound()
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as directory:
            def factory(score,cache,cancel):
                captured.append(score);return SoundPreviewBackend(score,directory,cancel,sound)
            with patch('guitar_player.audio.SoundPreviewBackend',side_effect=factory):
                self.editor.preview();deadline=time.monotonic()+8
                while not sound.calls and time.monotonic()<deadline:self.app.update();time.sleep(.01)
                self.assertTrue(sound.calls,self.editor.feedback.get())
                self.assertEqual((self.editor.preview_offset,captured[0].bpm,captured[0].default_timbre),(4,90,'distorted'))
                self.assertEqual([e.chord for e in captured[0].events if e.notes],['V'])
                self.assertGreaterEqual(self.editor.play_at,4)
                self.editor.stop_preview()
                while self.editor.player.running and time.monotonic()<deadline:self.app.update();time.sleep(.01)
                self.assertFalse(self.editor.player.running)

    def test_measure_settings_dialog_applies_values_at_selected_bar(self):
        import tkinter as tk
        from tkinter import ttk
        self.editor.select_cursor(4);self.editor.measure_dialog()
        dialog=next(child for child in self.editor.winfo_children() if isinstance(child,tk.Toplevel));dialog.withdraw()
        controls=[child for row in dialog.winfo_children() for child in row.winfo_children()]
        entry=next(child for child in controls if type(child) is ttk.Entry)
        entry.insert(0,'144')
        boxes=[child for child in controls if isinstance(child,ttk.Combobox)]
        boxes[0].set('3/4');boxes[1].set('失真')
        button=next(child for child in dialog.winfo_children() if isinstance(child,ttk.Button));button.invoke()
        mark=self.editor.doc.bar_changes[1]
        self.assertEqual((mark.bpm,mark.meter,mark.timbre),(144,(3,4),'distorted'))

    def test_capo_converts_existing_score_and_can_be_undone(self):
        from test_capo import pitches
        cells=tuple(self.editor.doc.cells);original=pitches(self.editor.doc.score())
        self.editor.capo.set('2');self.assertTrue(self.editor.settings_changed())
        self.assertEqual(tuple(self.editor.doc.cells),cells)
        self.assertEqual(pitches(self.editor.doc.score()),[pitch+2 for pitch in original])
        self.editor.undo();self.assertEqual(self.editor.capo.get(),'0')
        self.assertEqual(pitches(self.editor.doc.score()),original)


if __name__=='__main__':unittest.main()

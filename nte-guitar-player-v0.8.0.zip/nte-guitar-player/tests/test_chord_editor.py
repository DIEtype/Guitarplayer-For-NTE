from fractions import Fraction as F
from pathlib import Path
from types import SimpleNamespace
import tempfile
import time
import unittest
import gc
from unittest.mock import patch,Mock

from guitar_player.ui import App
from guitar_player.chord_editor import VisualChordEditor
from guitar_player.chord_score import ChordDocument
from guitar_player.guitar import parse_guitar,UP,DOWN
from guitar_player.library import read_score
from guitar_player.player import GuitarPlayer
from guitar_player.game_profile import GameProfile


class ChordEditorTests(unittest.TestCase):
    def setUp(self):
        self.app=App(enable_native=False);self.app.withdraw();self.app.update()
        self.app.mode.set('和弦模式');self.app.mode_changed()
        self.app.open_visual_editor();self.editor=self.app.tab_editor
        self.editor.withdraw();self.editor.draw()

    def tearDown(self):
        if self.editor and not self.editor.closed:self.editor.destroy()
        self.app.dirty=False;self.app.close()
        gc.collect()

    def test_mode_switch_opens_chord_editor_and_restores_fret_document(self):
        self.assertIsInstance(self.editor,VisualChordEditor)
        self.editor.destroy()
        self.app.mode.set('品格模式');self.app.mode_changed()
        self.assertEqual(self.app.notation.get(),'六线谱 TAB')
        self.assertIsNotNone(self.app.analyze())

    def test_staff_click_writes_string_and_rhythm_controls_work(self):
        self.editor.clear();self.editor.choose_value(8)
        left,top,width=self.editor.bar_boxes[0]
        self.editor.click(SimpleNamespace(x=left+58,y=top+55+5*22))
        cell=self.editor.doc.at(0)
        self.assertEqual((cell.notes,cell.beats),((6,),F(1,2)))
        self.editor.move_horizontal(1);self.editor.key(SimpleNamespace(char='3'))
        self.assertEqual(self.editor.doc.at(F(1,2)).notes,(3,))

    def test_palette_marks_strums_multistring_and_undo(self):
        self.editor.clear();self.editor.palette_page.set(self.editor.page_labels[3]);self.editor.update_palette()
        self.editor.chord_buttons[2].invoke()
        self.assertEqual(self.editor.doc.chord_at(0),'D/F#')
        self.editor.put_sweep(DOWN)
        self.assertEqual(self.editor.doc.at(0).notes,(DOWN,))
        self.editor.multiple.set(True)
        self.editor.key(SimpleNamespace(char='6'));self.editor.key(SimpleNamespace(char='3'))
        self.assertEqual(self.editor.doc.at(0).notes,(3,6))
        self.editor.undo();self.assertEqual(self.editor.doc.at(0).notes,(6,))
        self.editor.redo();self.assertEqual(self.editor.doc.at(0).notes,(3,6))
        self.assertTrue(self.editor.canvas.find_withtag('chord_mark'))
        self.assertTrue(self.editor.canvas.find_withtag('pluck'))

    def test_strum_arrows_follow_game_string_order_on_tab(self):
        self.editor.clear();self.editor.put_sweep(UP)
        self.editor.move_horizontal(1);self.editor.put_sweep(DOWN);self.editor.draw()
        arrows=self.editor.canvas.find_withtag('strum')
        self.assertEqual(len(arrows),2)
        up,down=[self.editor.canvas.coords(item) for item in arrows]
        top=self.editor.bar_boxes[0][1]
        self.assertEqual(up,[up[0],top+55,up[0],top+165])
        self.assertEqual(down,[down[0],top+165,down[0],top+55])
        self.assertEqual(self.app.profile.bindings[UP].button,'left')
        self.assertEqual(self.app.profile.bindings[DOWN].button,'right')

    def test_measure_changes_chord_marks_and_save_reopen_are_preserved(self):
        self.editor.clear();self.editor.choose_chord('Cmaj7');self.editor.put_sweep(DOWN)
        self.editor.select_cursor(4);self.editor.choose_chord('Am7/G');self.editor.put_sweep(UP)
        self.editor.set_measure_change(90,(3,4),'distorted')
        self.assertTrue(self.editor.apply(),self.editor.feedback.get())
        self.assertEqual(self.app.mode.get(),'和弦模式')
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as folder:
            path=Path(folder)/'chords.gscore';self.app.save_score(path)
            loaded,_=read_score(path)
            self.assertEqual(loaded.chord_changes,self.editor.doc.score().chord_changes)
            self.assertEqual(loaded.bar_changes,self.editor.doc.score().bar_changes)
            self.app.dirty=False;self.app.open_score(path)
            self.assertEqual(self.app.chord_changes,loaded.chord_changes)
            self.assertEqual(self.app.profile.page_count,4)

    def test_current_bar_preview_uses_silent_backend_and_never_sends_input(self):
        self.editor.clear();self.editor.select_cursor(4);self.editor.choose_chord('Am');self.editor.put_sweep(UP)
        with patch('guitar_player.audio.SoundPreviewBackend',side_effect=AssertionError('must not synthesize unknown voicing')):
            self.editor.preview()
        self.assertEqual(self.editor.preview_offset,4)
        self.assertTrue(self.editor.player.running)
        self.editor.stop_preview();self.editor.player.thread.join(2)
        self.assertFalse(self.editor.player.running)

    def test_controls_fit_supported_editor_width(self):
        self.app.attributes('-alpha',0);self.app.attributes('-disabled',True);self.app.deiconify();self.app.update()
        self.editor.attributes('-alpha',0);self.editor.attributes('-disabled',True)
        for width in (820,1180):
            self.editor.geometry(f'{width}x760');self.editor.deiconify();self.app.update()
            for button in self.editor.chord_buttons+[self.editor.pattern_button]:
                self.assertTrue(button.winfo_ismapped())
                self.assertLessEqual(button.winfo_rootx()-self.editor.winfo_rootx()+button.winfo_width(),width)
            self.assertGreater(self.editor.canvas.winfo_height(),100)

    def test_game_mode_is_updated_after_z_and_not_on_preview(self):
        self.app.playing_real=True;self.app.messages.put(('mode','chord'));self.app._poll()
        self.assertEqual(self.app.game_mode.get(),'和弦')
        self.app.playing_real=False;self.app.messages.put(('mode','fret'));self.app._poll()
        self.assertEqual(self.app.game_mode.get(),'和弦')


class ChordPlaybackTests(unittest.TestCase):
    def test_native_plan_sends_z_before_chord_and_releases_keys(self):
        gc.collect()
        backend=Mock();events=[];profile=GameProfile();profile.initial_mode='fret'
        player=GuitarPlayer(lambda kind,data:events.append((kind,data)))
        player.start(parse_guitar('{G} [6 3 2]:1/2',240),profile,backend)
        player.thread.join(4)
        self.assertFalse(player.running)
        self.assertEqual([call.args for call in backend.key_down.call_args_list],[('Z',)])
        self.assertEqual([call.args for call in backend.key_up.call_args_list],[('Z',)])
        self.assertEqual(len(backend.press.call_args.args[0]),3)
        self.assertTrue(backend.release_all.called)
        self.assertTrue(any(kind=='done' for kind,data in events),events)


if __name__=='__main__':unittest.main()

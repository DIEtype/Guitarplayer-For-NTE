import ctypes
import json
import os
from pathlib import Path
import tempfile
import unittest

from guitar_player.diagnostics import InputProbe,InputTrace
from guitar_player.game_profile import GameProfile
from guitar_player.native import INPUT,KEYBDINPUT,WindowsBackend,integrity_level

HERE=Path(__file__).resolve().parent


class FakeBackend:
    def __init__(self,*args,**kwargs):
        self.calls=[]
        self.held=False
    def acquire_target(self):return "test target"
    def check_target(self):pass
    def press(self,actions):
        self.calls.append(("press",tuple(a.key for a in actions)))
        self.held=True
    def release_all(self):
        self.calls.append(("release",))
        self.held=False
    def chord_move(self,name):self.calls.append(("move",name))
    def chord_down(self,name):self.calls.append(("click",name))
    def chord_up(self):self.calls.append(("up",))


class InputDiagnosticTests(unittest.TestCase):
    def test_key_probe_bypasses_mouse_and_uses_game_digit_six(self):
        with tempfile.TemporaryDirectory(dir=HERE) as folder:
            trace=InputTrace(folder,"test")
            backend=FakeBackend()
            messages=[]
            probe=InputProbe(lambda k,d:messages.append((k,d)))
            probe._wait=lambda seconds,backend=None:None
            probe.start(123,GameProfile.frets(),"key",trace,lambda *a,**k:backend,countdown=0)
            probe.thread.join(2)
            self.assertEqual([call for call in backend.calls if call[0]=="press"],[("press",("6",))]*3)
            self.assertFalse(any(call[0] in ("move","click") for call in backend.calls))
            self.assertFalse(backend.held)
            self.assertEqual(messages[-1][0],"probe_done")
            rows=[json.loads(row) for row in trace.path.read_text(encoding="utf-8").splitlines()]
            self.assertEqual(rows[-1]["event"],"probe_finished")

    def test_pointer_probe_never_clicks_or_presses(self):
        with tempfile.TemporaryDirectory(dir=HERE) as folder:
            backend=FakeBackend()
            probe=InputProbe(lambda *args:None)
            probe._wait=lambda seconds,backend=None:None
            probe.start(123,GameProfile.frets(),"pointer",InputTrace(folder,"test"),lambda *a,**k:backend,countdown=0)
            probe.thread.join(2)
            self.assertEqual(backend.calls,[("move","I"),("release",)])

    def test_probe_error_still_releases(self):
        with tempfile.TemporaryDirectory(dir=HERE) as folder:
            backend=FakeBackend()
            def fail(actions):
                backend.held=True
                raise RuntimeError("input rejected")
            backend.press=fail
            messages=[]
            probe=InputProbe(lambda k,d:messages.append((k,d)))
            probe._wait=lambda seconds,backend=None:None
            probe.start(123,GameProfile.frets(),"key",InputTrace(folder,"test"),lambda *a,**k:backend,countdown=0)
            probe.thread.join(2)
            self.assertFalse(backend.held)
            self.assertIn("input rejected",messages[-1][1][0])

    def test_cancel_countdown_does_not_construct_input_backend(self):
        with tempfile.TemporaryDirectory(dir=HERE) as folder:
            constructed=[]
            probe=InputProbe(lambda *args:None)
            probe.start(123,GameProfile.frets(),"key",InputTrace(folder,"test"),lambda *a,**k:constructed.append(True),countdown=1)
            probe.stop()
            probe.thread.join(2)
            self.assertFalse(constructed)

    def test_windows_rejection_is_logged(self):
        with tempfile.TemporaryDirectory(dir=HERE) as folder:
            backend=WindowsBackend.__new__(WindowsBackend)
            backend.trace=InputTrace(folder,"test")
            class Api:
                def SendInput(self,*args):
                    ctypes.set_last_error(5)
                    return 0
            backend.api=Api()
            with self.assertRaisesRegex(RuntimeError,"0/1"):
                backend._send([INPUT(type=1,ki=KEYBDINPUT(0,7,8,0,0))])
            row=json.loads(backend.trace.path.read_text(encoding="utf-8").splitlines()[-1])
            self.assertEqual((row["accepted"],row["win_error"]),(0,5))
            self.assertEqual(row["inputs"][0]["scan"],7)

    def test_can_read_own_windows_integrity_level(self):
        self.assertIn(integrity_level(os.getpid()),(0x1000,0x2000,0x2100,0x3000,0x4000))

    def test_page_probe_uses_selected_timing_and_wraps_to_first_page(self):
        from guitar_player.timing import FAST
        with tempfile.TemporaryDirectory(dir=HERE) as folder:
            backend=FakeBackend();profile=GameProfile.frets();profile.initial_page=4;waits=[]
            probe=InputProbe(lambda *args:None);probe._wait=lambda seconds,backend=None:waits.append(seconds)
            probe.start(123,profile,'page',InputTrace(folder,'test'),lambda *a,**k:backend,countdown=0,timing=FAST)
            probe.thread.join(2)
            self.assertEqual([call for call in backend.calls if call[0]=='press'],[('press',('T',)),('press',('6',))])
            self.assertIn(('move','I'),backend.calls);self.assertIn(('click','I'),backend.calls)
            self.assertEqual(waits,[FAST.page_hold,FAST.page_wait-FAST.page_hold,FAST.mouse_settle,FAST.mouse_hold,FAST.after_select,FAST.tap_ms/1000])
            self.assertFalse(backend.held)

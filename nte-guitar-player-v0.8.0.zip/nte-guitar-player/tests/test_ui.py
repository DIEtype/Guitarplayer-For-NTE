import json
from pathlib import Path
import tempfile
import time
import unittest
import tkinter as tk
from dataclasses import replace
from fractions import Fraction
from unittest.mock import patch

from guitar_player.ui import App, FRET_EXAMPLE, atomic_json


class UITests(unittest.TestCase):
    def setUp(self):
        self.app = App(enable_native=False)
        self.app.withdraw()
        self.app.update()

    def tearDown(self):
        self.app.dirty = False
        self.app.close()

    def test_both_modes_parse_and_draw(self):
        self.assertIsNotNone(self.app.analyze())
        self.app.mode.set("品格模式")
        self.app.notation.set("指令谱")
        self.app.editor.delete("1.0", "end")
        self.app.editor.insert("1.0", FRET_EXAMPLE)
        self.app.mode_changed()
        self.assertIsNotNone(self.app.analyze())
        self.assertTrue(self.app.wheel.find_all())

    def test_playback_buttons_remain_visible_in_short_windows(self):
        self.app.attributes('-alpha',0)
        self.app.attributes('-disabled',True)
        self.app.minsize(1,1)
        for width,height in ((1024,600),(940,560),(640,560),(1240,820)):
            with self.subTest(width=width,height=height):
                self.app.geometry(f'{width}x{height}')
                self.app.deiconify()
                self.app.update()
                for button in (self.app.game_play_button,self.app.audition_button,self.app.preview_button,self.app.pause_button,self.app.stop_button):
                    self.assertTrue(button.winfo_ismapped(),button.cget('text'))
                    x=button.winfo_rootx()-self.app.winfo_rootx()
                    y=button.winfo_rooty()-self.app.winfo_rooty()
                    self.assertGreaterEqual(x,0)
                    self.assertGreaterEqual(y,0)
                    self.assertLessEqual(x+button.winfo_width(),self.app.winfo_width())
                    self.assertLessEqual(y+button.winfo_height(),self.app.winfo_height())
                self.assertLess(self.app.game_play_button.winfo_rooty(),self.app.editor.winfo_rooty())

    def test_narrow_window_wraps_playback_controls(self):
        self.app.attributes('-alpha',0)
        self.app.attributes('-disabled',True)
        self.app.minsize(1,1)
        self.app.geometry('640x560')
        self.app.deiconify()
        self.app.update()
        self.assertTrue(self.app._playback_compact)
        self.assertGreater(self.app.stop_button.winfo_rooty(),self.app.game_play_button.winfo_rooty())

    def test_demo_button_loads_playable_timed_tab(self):
        self.app.load_demo()
        self.assertEqual(len(self.app.score.events),14)
        self.assertEqual(self.app.score.beats,16)
        self.assertIn("逐音节奏",self.app.info.get())

    def test_local_audition_starts_and_stops_without_real_audio(self):
        from guitar_player.audio import SoundPreviewBackend
        class Sound:
            SND_FILENAME, SND_ASYNC, SND_NODEFAULT = 0x20000,1,2
            def __init__(self):
                self.calls=[]
            def PlaySound(self,path,flags):
                self.calls.append(path)
        sound=Sound()
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as directory:
            def factory(score,cache,cancel):
                return SoundPreviewBackend(score,directory,cancel,sound)
            self.app.load_demo()
            with patch("guitar_player.audio.SoundPreviewBackend",side_effect=factory):
                self.app.start(False,audible=True)
                deadline=time.perf_counter()+5
                while not sound.calls and time.perf_counter()<deadline:
                    self.app.update()
                    time.sleep(.01)
            self.assertTrue(sound.calls,self.app.status.get())
            self.app.stop()
            while (self.app.player.running or self.app.preparing_audio) and time.perf_counter()<deadline:
                self.app.update()
                time.sleep(.01)
            self.assertFalse(self.app.player.running)
            self.assertIsNone(sound.calls[-1])
            self.assertFalse(list(Path(directory).glob("*.wav")))

    def test_save_and_reopen_preserves_profile_and_text(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as directory:
            path = str(Path(directory) / "test.gscore")
            self.app.profile.strum_point = (.82, .63)
            original = self.app.editor.get("1.0", "end-1c")
            with patch("guitar_player.ui.filedialog.asksaveasfilename", return_value=path):
                self.app.save_score()
            self.app.editor.delete("1.0", "end")
            self.app.editor.edit_modified(False)
            with patch("guitar_player.ui.filedialog.askopenfilename", return_value=path):
                self.app.open_score()
            self.assertEqual(self.app.editor.get("1.0", "end-1c"), original)
            self.assertEqual(self.app.profile.strum_point, (.82, .63))
            self.assertIsNotNone(self.app.score)

    def test_bad_file_does_not_replace_current_score(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as directory:
            path = str(Path(directory) / "invalid.gscore")
            atomic_json(path, {"version": 1, "text": "bad", "profile": {}})
            original = self.app.editor.get("1.0", "end-1c")
            with patch("guitar_player.ui.filedialog.askopenfilename", return_value=path):
                self.app.open_score()
            self.assertEqual(self.app.editor.get("1.0", "end-1c"), original)
            self.assertIn("打开失败", self.app.status.get())

    def test_tempo_changes_survive_editor_save_reopen_and_bpm_scaling(self):
        from guitar_player.guitar import parse_guitar
        score=replace(parse_guitar('{I} 1:2 {III} 2:2',120),tempo_map=((Fraction(0),500000),(Fraction(2),1000000)))
        self.app.accept_visual_score(score)
        self.app.bpm.set('60');self.app.analyze()
        self.assertAlmostEqual(self.app.score.seconds,6)
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as directory:
            path=str(Path(directory)/'tempo.gscore')
            with patch('guitar_player.ui.filedialog.asksaveasfilename',return_value=path):self.app.save_score()
            self.app.tempo_source=()
            with patch('guitar_player.ui.filedialog.askopenfilename',return_value=path):self.app.open_score()
            self.assertAlmostEqual(self.app.score.seconds,6)
            self.assertEqual(self.app.tempo_source,score.tempo_map)

    def test_malformed_tempo_data_does_not_replace_score(self):
        original=self.app.editor.get('1.0','end-1c')
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as directory:
            path=str(Path(directory)/'bad-tempo.gscore')
            for tempos in ((('1/0',500000),),(('0',500000),('0',1000000)),(('1',500000),)):
                atomic_json(path,{'version':1,'text':'bad','profile':self.app.profile.to_dict(),'bpm':120,'tempo_map':tempos})
                with patch('guitar_player.ui.filedialog.askopenfilename',return_value=path):self.app.open_score()
                self.assertIn('打开失败',self.app.status.get())
                self.assertEqual(self.app.editor.get('1.0','end-1c'),original)

    def test_game_timing_warning_does_not_block_offline_preview(self):
        from guitar_player.guitar import parse_guitar
        self.app.accept_visual_score(parse_guitar('{I} 1:1/64 {VII} 1:1/64',360))
        self.assertTrue(self.app.game_warning)
        self.app.start(False)
        self.app.player.thread.join(timeout=2)
        self.assertFalse(self.app.player.running)
        self.app.update()
        self.assertNotIn('error',self.app.status.get().lower())

    def test_midi_dialog_import_opens_editable_score(self):
        from guitar_player.midi_import import mido
        from guitar_player.visual_editor import VisualTabEditor
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as directory:
            path=Path(directory)/'lead.mid'
            midi=mido.MidiFile();track=mido.MidiTrack();midi.tracks.append(track)
            track.extend([mido.Message('note_on',note=65,velocity=80),mido.Message('note_off',note=65,time=480)])
            midi.save(path)
            with patch('guitar_player.ui.filedialog.askopenfilename',return_value=str(path)):self.app.import_midi()
            dialog=next(w for w in self.app.winfo_children() if isinstance(w,tk.Toplevel))
            button=next(w for w in dialog.winfo_children() if isinstance(w,tk.ttk.Button))
            button.invoke()
            editors=[w for w in self.app.winfo_children() if isinstance(w,VisualTabEditor)]
            self.assertEqual(len(editors),1)
            self.assertEqual(len(self.app.score.events),1)
            self.assertEqual(self.app.score.events[0].chord,'I')
            self.assertEqual(len(self.app.tempo_source),1)

    def test_new_import_and_edit_buttons_are_visible_at_normal_minimum_size(self):
        from tkinter import ttk
        self.app.attributes('-alpha',0);self.app.attributes('-disabled',True)
        self.app.geometry('940x560');self.app.deiconify();self.app.update()
        def descendants(widget):
            for child in widget.winfo_children():
                yield child
                yield from descendants(child)
        buttons={w.cget('text'):w for w in descendants(self.app) if isinstance(w,ttk.Button)}
        for label in ('导入 MIDI','图形编谱','输入测试','我的曲库','预览指法适配'):
            button=buttons[label]
            self.assertTrue(button.winfo_ismapped(),label)
            self.assertLessEqual(button.winfo_rootx()+button.winfo_width(),self.app.winfo_rootx()+self.app.winfo_width(),label)
            self.assertLessEqual(button.winfo_rooty()+button.winfo_height(),self.app.winfo_rooty()+self.app.winfo_height(),label)
        self.assertTrue(self.app.status_banner.winfo_ismapped())
        self.assertGreater(self.app.editor.winfo_height(),100)

    def test_adaptive_preview_preserves_pitch_and_timing_and_can_undo_the_rewrite(self):
        from guitar_player.arrangement import transition_count
        from guitar_player.game_profile import ROMAN
        from guitar_player.guitar import parse_guitar
        from guitar_player.music import fret_pitch
        from guitar_player.timing import ADAPTIVE
        source=parse_guitar('{VIII} 1:1/2 {III} 1:1/2 {VIII} 1:1/2 {XV} 1:1/2',168)
        self.app.accept_visual_score(source);before=self.app.editor.get('1.0','end-1c')
        result=self.app.adapt_fingering()
        self.assertEqual(self.app.input_timing,ADAPTIVE);self.assertEqual(self.app.game_warning,'')
        pitch=lambda e:fret_pitch(e.notes[0],0 if e.chord=='Zero' else ROMAN.index(e.chord)+1)
        self.assertEqual([pitch(e) for e in source.events],[pitch(e) for e in result.events])
        self.assertEqual([(e.start,e.beats) for e in source.events],[(e.start,e.beats) for e in result.events])
        self.assertLess(transition_count(result,0),transition_count(source,0))
        self.assertTrue(self.app.dirty);self.app.editor.edit_undo()
        self.assertEqual(self.app.editor.get('1.0','end-1c'),before)

    def test_game_start_without_global_stop_still_adapts_and_starts(self):
        from guitar_player.arrangement import transition_count
        from guitar_player.guitar import parse_guitar,make_plan
        self.app.accept_visual_score(parse_guitar('{VIII} 1:1/2 {III} 1:1/2 {VIII} 1:1/2 {XV} 1:1/2',168))
        self.app.hotkey_ids=();self.app.window.set('fake');self.app.window_items={'fake':1}
        with patch('guitar_player.ui.WindowsBackend') as backend,patch('guitar_player.ui.InputTrace'),patch.object(self.app.player,'start') as start:
            self.app.start(True)
            self.assertTrue(backend.called);self.assertTrue(start.called,self.app.status.get())
            score,profile,_=start.call_args.args
            self.assertLessEqual(transition_count(score,0),2)
            self.assertEqual(start.call_args.kwargs['timing'].key,'adaptive')
            self.assertEqual(start.call_args.kwargs['countdown'],5)
            make_plan(score,profile,tap=.04,timing=self.app.input_timing)

    def test_input_probe_is_not_blocked_by_unavailable_global_stop(self):
        self.app.hotkey_ids=();self.app.window.set('fake');self.app.window_items={'fake':1}
        with patch('guitar_player.ui.InputTrace'),patch.object(self.app.input_probe,'start') as start:
            self.app.start_input_test('key')
            self.assertTrue(start.called,self.app.probe_feedback.get())
            self.assertEqual(start.call_args.args[0],1)
            self.assertEqual(start.call_args.args[2],'key')

    def test_stop_shortcut_hint_updates_without_disabling_playback(self):
        self.app.hotkeys_changed((1,3))
        self.assertEqual(self.app.stop_label.get(),'停止 Ctrl+Alt+F9')
        self.assertIn('Ctrl+Alt+F9',self.app.control_hint('可用 F9 停止'))
        self.app.hotkeys_changed(())
        self.assertEqual(self.app.stop_label.get(),'停止')
        self.assertIn('仍可演奏',self.app.status.get())
        self.assertNotIn('F9',self.app.control_hint('可用 F9 停止'))
        self.assertFalse(self.app.game_play_button.instate(['disabled']))

    def test_measure_changes_and_tone_survive_file_and_library_roundtrip(self):
        from guitar_player.tablature import TabDocument,TabCell
        from guitar_player.library import read_score
        doc=TabDocument([TabCell(Fraction(0),Fraction(1),1,3),TabCell(Fraction(4),Fraction(1),1,5)],bpm=120,bars=3)
        doc.set_bar_change(1,90,(3,4),'distorted');doc.set_capo(2);source=doc.score()
        self.app.accept_visual_score(source);self.app.game_timbre.set('失真')
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as directory:
            path=Path(directory)/'changes.gscore';self.app.save_score(path)
            self.assertEqual(json.loads(path.read_text(encoding='utf-8'))['version'],2)
            self.app.bar_changes=();self.app.default_timbre='distorted'
            self.app.open_score(path)
            self.assertEqual(self.app.score.bar_changes,source.bar_changes)
            self.assertEqual(self.app.score.default_timbre,'clean')
            self.assertEqual(self.app.score.capo,2)
            self.assertEqual(self.app.game_timbre.get(),'失真')
            self.assertEqual(self.app.score.tempo_map,source.tempo_map)
            restored,_=read_score(path)
            self.assertEqual(restored.bar_changes,source.bar_changes)
            self.assertEqual(restored.capo,2)
            self.assertAlmostEqual(restored.seconds,source.seconds)

    def test_meter_measure_count_and_trailing_empty_bars_survive_save_reopen(self):
        from guitar_player.tablature import TabDocument
        doc=TabDocument(bpm=132,meter=(6,8),bars=7)
        doc.write(0,1,12,Fraction(1,2))
        self.app.accept_visual_score(doc.score())
        self.assertEqual((self.app.score.time_signature,self.app.score.measures),((6,8),7))
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as directory:
            path=str(Path(directory)/'measured.gscore')
            with patch('guitar_player.ui.filedialog.asksaveasfilename',return_value=path):self.app.save_score()
            self.app.time_signature=(4,4);self.app.measure_count=0
            with patch('guitar_player.ui.filedialog.askopenfilename',return_value=path):self.app.open_score()
            self.assertEqual((self.app.score.time_signature,self.app.score.measures,self.app.score.bpm),((6,8),7,132))
            self.assertEqual(self.app.score.beats,21)

    def test_invalid_meter_does_not_replace_current_score(self):
        original=self.app.editor.get('1.0','end-1c')
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as directory:
            path=str(Path(directory)/'bad-meter.gscore')
            atomic_json(path,{'version':1,'text':'bad','profile':self.app.profile.to_dict(),'bpm':100,'time_signature':[4,0]})
            with patch('guitar_player.ui.filedialog.askopenfilename',return_value=path):self.app.open_score()
            self.assertEqual(self.app.editor.get('1.0','end-1c'),original)
            self.assertIn('打开失败',self.app.status.get())

    def test_input_speed_changes_validation_without_changing_score(self):
        from guitar_player.guitar import parse_guitar
        from guitar_player.timing import SAFE,FAST
        self.app.accept_visual_score(parse_guitar('{I} 1:1/2 {VII} 1:1/2',120))
        text=self.app.editor.get('1.0','end-1c')
        self.app.input_speed.set(SAFE.label);self.app.input_speed_changed()
        self.assertIn('翻页需要 0.30',self.app.game_warning)
        self.app.input_speed.set(FAST.label);self.app.input_speed_changed()
        self.assertEqual(self.app.game_warning,'');self.assertEqual(self.app.tap.get(),'30')
        self.assertEqual(self.app.editor.get('1.0','end-1c'),text)
        self.assertEqual(self.app.score.bpm,120)

    def test_input_speed_survives_save_reopen(self):
        from guitar_player.timing import TURBO,SAFE
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as directory:
            path=str(Path(directory)/'input-speed.gscore')
            self.app.input_speed.set(TURBO.label);self.app.input_speed_changed()
            with patch('guitar_player.ui.filedialog.asksaveasfilename',return_value=path):self.app.save_score()
            self.app.input_speed.set(SAFE.label)
            with patch('guitar_player.ui.filedialog.askopenfilename',return_value=path):self.app.open_score()
            self.assertEqual(self.app.input_timing.key,'turbo');self.assertEqual(self.app.tap.get(),'20')


if __name__ == "__main__":
    unittest.main()

from array import array
from fractions import Fraction as F
from pathlib import Path
import tempfile
import unittest
import wave

from guitar_player.tablature import TabDocument,TabCell
from guitar_player.tab import parse_tab
from guitar_player.midi_import import score_to_tab
from guitar_player.game_profile import ROMAN,GameProfile
from guitar_player.music import fret_pitch
from guitar_player.guitar import apply_capo,make_plan
from guitar_player.arrangement import adapt_score
from guitar_player.timing import ADAPTIVE
from guitar_player.audio import render_wav,RATE


def pitches(score):
    return [fret_pitch(e.notes[0],0 if e.chord=='Zero' else ROMAN.index(e.chord)+1) for e in score.events if e.notes]


class CapoTests(unittest.TestCase):
    def document(self):return TabDocument([TabCell(F(i),F(1),1,fret) for i,fret in enumerate((0,3,5))],bpm=120,bars=1)

    def test_existing_no_capo_score_keeps_written_frets_and_transposes_automatically(self):
        doc=self.document();before=doc.score();cells=tuple(doc.cells);doc.set_capo(2);score=doc.score()
        self.assertEqual(tuple(doc.cells),cells);self.assertEqual(score.capo,2)
        self.assertEqual(pitches(score),[pitch+2 for pitch in pitches(before)])
        self.assertEqual([e.chord for e in score.events if e.notes],['II','V','VII'])
        self.assertEqual((score.beats,score.seconds),(before.beats,before.seconds))

    def test_tab_roundtrip_and_apply_are_idempotent_and_display_relative_numbers(self):
        doc=self.document();doc.set_capo(2);source=doc.score();text=score_to_tab(source)
        parsed=parse_tab(text,source.bpm,capo=2)
        self.assertEqual(pitches(parsed),pitches(source))
        self.assertEqual(apply_capo(parsed,2),parsed)
        self.assertEqual([cell.fret for cell in TabDocument.from_score(parsed).cells],[0,3,5])

    def test_reset_and_undo_restore_original_pitch_and_relative_frets(self):
        doc=self.document();state=doc.snapshot();original=pitches(doc.score())
        doc.set_capo(4);doc.set_capo(0);self.assertEqual(pitches(doc.score()),original)
        doc.set_capo(2);doc.restore(state);self.assertEqual(doc.snapshot(),state)

    def test_fingering_adaptation_stays_above_capo_and_keeps_transposed_pitch(self):
        doc=self.document();doc.set_capo(5);source=doc.score();adapted,_,_=adapt_score(source,0,ADAPTIVE,.04)
        self.assertEqual(pitches(adapted),pitches(source));self.assertEqual(adapted.capo,5)
        self.assertTrue(all(e.chord!='Zero' and ROMAN.index(e.chord)+1>=5 for e in adapted.events if e.notes))
        self.assertTrue(all(cell.fret>=0 for cell in TabDocument.from_score(adapted).cells))

    def test_high_fret_overflow_automatically_uses_an_equal_pitch_string(self):
        doc=TabDocument([TabCell(F(0),F(1),6,24)],bars=1);before=pitches(doc.score())[0]
        doc.set_capo(2)
        self.assertEqual(pitches(doc.score()),[before+2])
        self.assertNotEqual(doc.cells[0].string,6);self.assertLessEqual(doc.cells[0].fret+2,24)
        impossible=TabDocument([TabCell(F(0),F(1),1,24)],bars=1);state=impossible.snapshot()
        with self.assertRaises(ValueError):impossible.set_capo(1)
        self.assertEqual(impossible.snapshot(),state)

    def test_game_plan_selects_physical_fret_for_written_open_string(self):
        doc=TabDocument([TabCell(F(0),F(1),1,0)],bars=1);doc.set_capo(2)
        plan=make_plan(doc.score(),GameProfile.frets(),timing=ADAPTIVE,tap=.04)
        self.assertEqual([step.data for step in plan if step.kind=='chord_move'],['II'])

    def test_reference_audio_uses_transposed_pitch_exactly_once(self):
        doc=TabDocument([TabCell(F(0),F(1),1,0)],bpm=120,meter=(1,4),bars=1);doc.set_capo(2)
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as folder:
            path=render_wav(doc.score(),Path(folder)/'capo.wav')
            with wave.open(str(path),'rb') as stream:samples=array('h',stream.readframes(stream.getnframes()))
            crossings=[i for i in range(int(.02*RATE),int(.4*RATE)) if samples[i-1]<=0<samples[i]]
            measured=(len(crossings)-1)*RATE/(crossings[-1]-crossings[0])
            self.assertAlmostEqual(measured,369.994,delta=2)


if __name__=='__main__':unittest.main()

from fractions import Fraction as F
from dataclasses import replace
import unittest

from guitar_player.chord_score import ChordDocument,ChordCell,score_to_commands,parse_chord_changes
from guitar_player.game_profile import GameProfile,CHORD_PAGES,CHORD_NAMES,CHORD_PAGE_INDEX
from guitar_player.guitar import parse_guitar,make_plan,UP,DOWN
from guitar_player.measures import crop_from_measure


class ChordScoreTests(unittest.TestCase):
    def test_all_four_pages_match_screenshot_slots_and_share_calibration(self):
        profile=GameProfile()
        self.assertEqual(len(profile.chords),24)
        for page,names in enumerate(CHORD_PAGES):
            for slot,name in enumerate(names):
                self.assertEqual(profile.pages[name],page)
                self.assertEqual(profile.chords[name],profile.chords[CHORD_PAGES[0][slot]])
        self.assertEqual(profile.bindings[1].key,'6')
        self.assertEqual(profile.bindings[6].key,'1')
        self.assertEqual((profile.bindings[UP].button,profile.bindings[DOWN].button),('left','right'))

    def test_old_six_chord_layout_expands_without_losing_calibration(self):
        raw=GameProfile().to_dict();raw['chords']={name:(.1+i*.1,.3) for i,name in enumerate(CHORD_PAGES[0])}
        raw['pages']={name:0 for name in raw['chords']};raw['calibrated']=True
        profile=GameProfile.from_dict(raw)
        self.assertEqual(len(profile.chords),24)
        self.assertEqual(profile.chords['Cmaj7'],(.1,.3));self.assertTrue(profile.calibrated)

    def test_chord_changes_inherit_inside_bar_and_across_silent_bars(self):
        doc=ChordDocument(bars=3);doc.set_chord(0,'Cmaj7');doc.set_chord(2,'Am7/G')
        doc.write_action(0,(6,),F(1,2));doc.write_action(3,(UP,),F(1,2));doc.write_action(8,(2,3),1)
        notes=[e for e in doc.score().events if e.notes]
        self.assertEqual([e.chord for e in notes],['Cmaj7','Am7/G','Am7/G'])
        self.assertEqual(doc.chord_at(6),'Am7/G')

    def test_multi_string_and_strum_survive_text_and_document_roundtrip(self):
        doc=ChordDocument(bars=1);doc.set_chord(0,'D/F#')
        doc.write_action(0,(6,3,2),F(1,2));doc.write_action(F(1,2),(DOWN,),1)
        doc.set_chord(2,'Cadd9');doc.write_action(3,(UP,),1)
        score=doc.score();text=score_to_commands(score);parsed=parse_guitar(text,score.bpm)
        self.assertEqual([(e.start,e.beats,e.notes,e.chord) for e in parsed.events],
                         [(e.start,e.beats,e.notes,e.chord) for e in score.events])
        rebuilt=ChordDocument.from_score(score)
        self.assertEqual(rebuilt.snapshot(),doc.snapshot())

    def test_resize_moves_later_chord_mark_without_changing_selected_chord(self):
        doc=ChordDocument();doc.set_chord(0,'G');doc.set_chord(1,'Em')
        doc.write_action(0,(6,),1);doc.write_action(1,(3,),1);doc.resize(0,F(1,2))
        self.assertEqual(doc.chord_changes,{F(0):'G',F(1,2):'Em'})
        self.assertEqual(doc.at(F(1,2)).notes,(3,))

    def test_insert_copy_and_delete_keep_chord_mark_positions(self):
        doc=ChordDocument(bars=2);doc.set_chord(0,'G');doc.set_chord(2,'Em');doc.set_chord(4,'C')
        doc.write_action(0,(6,),1);doc.copy_bar(0)
        self.assertEqual((doc.bars,doc.chord_at(4),doc.chord_at(6),doc.chord_at(8)),(3,'G','Em','C'))
        doc.insert_bar(1)
        self.assertEqual((doc.chord_at(8),doc.chord_at(10),doc.chord_at(12)),('G','Em','C'))
        doc.remove_empty_bar(1)
        self.assertEqual((doc.bars,doc.chord_at(8)),(3,'C'))

    def test_copy_last_bar_does_not_add_an_extra_empty_bar(self):
        doc=ChordDocument(bars=1);doc.set_chord(0,'A');doc.copy_bar(0)
        self.assertEqual(doc.bars,2)

    def test_meter_change_retimes_chords_and_current_measure_preview(self):
        doc=ChordDocument(bars=3);doc.set_chord(0,'G');doc.set_chord(8,'Dm')
        doc.write_action(8,(4,),1);doc.set_bar_change(1,90,(3,4),'distorted')
        self.assertEqual(doc.chord_at(7),'Dm')
        cropped,offset=crop_from_measure(doc.score(),2)
        self.assertEqual((offset,cropped.chord_changes[0],cropped.default_timbre),(7,(F(0),'Dm'),'distorted'))

    def test_pattern_scales_to_current_meter_and_preserves_chord_marks(self):
        doc=ChordDocument(meter=(3,4),bars=1);doc.set_chord(0,'C')
        doc.fill_pattern(0,'分解：低音–3–2–3–1–3–2–3',5)
        self.assertEqual(len(doc.cells),8);self.assertEqual(doc.cells[-1].end,3)
        self.assertEqual(doc.cells[0].notes,(5,));self.assertEqual(doc.chord_at(1),'C')
        doc.fill_pattern(0,'扫弦：↓ ↓ ↑ ↑ ↓ ↑')
        self.assertEqual(sum(c.beats for c in doc.cells),3)
        self.assertEqual([c.notes for c in doc.cells],[(DOWN,),(DOWN,),(UP,),(UP,),(DOWN,),(UP,)])

    def test_invalid_chord_capo_and_mixed_sweep_are_rejected(self):
        doc=ChordDocument()
        for operation in (lambda:doc.set_chord(0,'F#m'),lambda:doc.set_capo(2),lambda:doc.write_action(0,(UP,1),1)):
            with self.assertRaises(ValueError):operation()
        with self.assertRaises(ValueError):parse_chord_changes([['0','G'],['0','C']])

    def test_all_chords_schedule_and_four_page_wrap_uses_shortest_path(self):
        profile=GameProfile();profile.initial_page=0
        score=parse_guitar(' '.join('{'+name+'} 6' for name in CHORD_NAMES),60)
        plan=make_plan(score,profile)
        self.assertEqual(len([s for s in plan if s.kind=='note']),24)
        plan=make_plan(parse_guitar('{Dm} ↓',60),profile)
        self.assertEqual([s.data for s in plan if s.kind=='page'],[('R',3)])

    def test_z_is_scheduled_once_before_page_and_selection(self):
        profile=GameProfile();profile.initial_mode='fret'
        score=parse_guitar('{Cmaj9} ↓ {D/F#} ↑',60)
        plan=make_plan(score,profile)
        self.assertEqual([s.kind for s in plan[:2]],['mode_down','mode_up'])
        self.assertGreaterEqual(plan[2].at-plan[1].at,.1299)
        self.assertEqual(sum(s.kind=='mode_down' for s in plan),1)
        profile.initial_mode='chord'
        self.assertFalse(any(s.kind.startswith('mode_') for s in make_plan(score,profile)))


if __name__=='__main__':unittest.main()

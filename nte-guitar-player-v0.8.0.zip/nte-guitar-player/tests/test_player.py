import ctypes
from fractions import Fraction
import threading
import time
import unittest

from guitar_player.game_profile import GameProfile
from guitar_player.guitar import DOWN, UP, DEFAULT_TEXT, GuitarError, make_plan, parse_guitar
from guitar_player.music import fret_pitch, positions_for_pitch
from guitar_player.native import INPUT, WindowsBackend
from guitar_player.player import GuitarPlayer, PreviewBackend
from guitar_player.profile import parse_keys
from guitar_player.score import parse_score


class NotationTests(unittest.TestCase):
    def test_chords_strings_and_fractions(self):
        score = parse_guitar("{G} 6:1/2 [3 2 1]:3/2 | ↓ ↑ 0 - // comment", 120)
        self.assertEqual(score.beats, 6)
        self.assertEqual(score.events[1].notes, (1, 2, 3))
        self.assertEqual(score.events[1].start, Fraction(1, 2))
        self.assertEqual(score.events[2].notes, (DOWN,))
        self.assertEqual(score.events[3].notes, (UP,))
        self.assertEqual(score.events[-1].beats, 2)

    def test_fret_and_open_string(self):
        score = parse_guitar("{II} 6 | {VIII} 1 | {Zero} [6 5]")
        self.assertEqual([event.chord for event in score.events], ["II", "VIII", "Zero"])

    def test_invalid_notation(self):
        for text in ("{G} 7", "6 5", "{G} 1:0", "{G} 1:1/0", "{G} []", "{G}", "{G}{C} 1", "{G} [1 2]junk", "{G} 1:NaN"):
            with self.subTest(text=text), self.assertRaises(GuitarError):
                parse_guitar(text)

    def test_unknown_chord_fails_before_input(self):
        with self.assertRaisesRegex(GuitarError, "尚未配置"):
            make_plan(parse_guitar("{F} 6"), GameProfile())

    def test_default_score(self):
        score = parse_guitar(DEFAULT_TEXT)
        steps = make_plan(score, GameProfile())
        self.assertEqual(steps[0].kind, "chord_move")
        self.assertEqual(steps[-1].at, score.seconds)

    def test_taps_do_not_hold_for_two_beats(self):
        steps = make_plan(parse_guitar("{G} 6:2"), GameProfile())
        release = next(step for step in steps if step.kind == "release")
        self.assertAlmostEqual(release.at, .045)
        self.assertEqual(steps[-1].at, 1.2)

    def test_fret_pages_and_open_page(self):
        steps = make_plan(parse_guitar("{I} 6 | {VIII} 1:2 | {Zero} 6:2 | {II} 1"), GameProfile.frets())
        pages = [step.data for step in steps if step.kind == "page"]
        self.assertEqual(pages, [("T", 1), ("R", 0), ("R", 4), ("T", 0)])
        self.assertEqual([step.at for step in steps], sorted(step.at for step in steps))

    def test_page_latency_rejected_for_fast_transition(self):
        with self.assertRaisesRegex(GuitarError, "翻页需要"):
            make_plan(parse_guitar("{I} 1:1/2 {Zero} 1", 360), GameProfile.frets())

    def test_initial_page_wraps_from_zero_to_first(self):
        profile = GameProfile.frets()
        profile.initial_page = 4
        steps = make_plan(parse_guitar("{Zero} 6:2 {I} 6:2"), profile)
        self.assertEqual([step.data[0] for step in steps if step.kind == "page"], ["T"])

    def test_profiles_roundtrip(self):
        for original in (GameProfile(), GameProfile.frets()):
            restored = GameProfile.from_dict(original.to_dict())
            self.assertEqual(restored, original)
            self.assertEqual([restored.bindings[s].key for s in range(1, 7)], ["6", "5", "4", "3", "2", "1"])
            self.assertEqual(restored.bindings[UP].button, "left")
            self.assertEqual(restored.bindings[DOWN].button, "right")

    def test_invalid_profile_rejected(self):
        for point in ((float("nan"), .5), (1.2, .5), ("a", .5)):
            data = GameProfile().to_dict()
            data["strum_point"] = point
            with self.assertRaises(ValueError):
                GameProfile.from_dict(data)

    def test_pitch_reference(self):
        self.assertEqual([fret_pitch(s, 0) for s in range(6, 0, -1)], [40, 45, 50, 55, 59, 64])
        self.assertEqual(fret_pitch(6, 12), 52)
        self.assertEqual(fret_pitch(2, 1), 60)
        self.assertIn((2, 1), positions_for_pitch(60))

    def test_numbered_pitch_parser_kept_separate(self):
        score = parse_score("1 #4 [1 3 5]:2 1' 1,", 100)
        self.assertEqual(score.events[0].notes, (60,))
        self.assertEqual(score.events[1].notes, (66,))
        self.assertEqual(score.events[-2].notes, (72,))
        self.assertEqual(score.events[-1].notes, (48,))

    def test_reserved_stop_keys(self):
        for key in ("F8", "F9", "A+A", "SHIFT", "A+B"):
            with self.assertRaises(ValueError):
                parse_keys(key)


class RecordingBackend(PreviewBackend):
    def __init__(self):
        self.calls, self.held = [], False
        self.pressed = threading.Event()
        self.lose_focus = False

    def check_target(self):
        if self.lose_focus:
            raise RuntimeError("失焦")

    def chord_down(self, chord):
        self.calls.append(("chord", chord))
        self.held = True

    def chord_up(self):
        self.release_all()

    def press(self, actions):
        self.calls.append(("press", [action.key or action.button for action in actions]))
        self.held = bool(actions)
        if actions:
            self.pressed.set()

    def release_all(self):
        self.calls.append(("release", None))
        self.held = False


class SchedulerTests(unittest.TestCase):
    def setUp(self):
        self.messages = []
        self.player = GuitarPlayer(lambda kind, data: self.messages.append((kind, data)))
        self.backend = RecordingBackend()

    def tearDown(self):
        self.player.stop()
        if self.player.thread:
            self.player.thread.join(2)
        self.assertFalse(self.player.running)

    def test_string_reversal_and_finish_release(self):
        self.player.start(parse_guitar("{G} 6:1/4 1:1/4", 360), GameProfile(), self.backend)
        self.player.thread.join(2)
        self.assertEqual([call[1] for call in self.backend.calls if call[0] == "press"], [["1"], ["6"]])
        self.assertFalse(self.backend.held)
        self.assertEqual(self.messages[-1][0], "done")

    def test_countdown_stop_sends_nothing(self):
        self.player.start(parse_guitar("{G} 6"), GameProfile(), self.backend, countdown=1)
        self.player.stop()
        self.player.thread.join(2)
        self.assertFalse(any(call[0] in ("chord", "press") for call in self.backend.calls))

    def test_focus_loss_releases_inputs(self):
        self.player.start(parse_guitar("{G} 6:4"), GameProfile(), self.backend, tap=.2)
        self.assertTrue(self.backend.pressed.wait(1))
        self.backend.lose_focus = True
        self.player.thread.join(2)
        self.assertFalse(self.backend.held)
        self.assertEqual(self.messages[-1], ("error", "失焦"))

    def test_pause_and_stop_release_inputs(self):
        self.player.start(parse_guitar("{G} 6:4"), GameProfile(), self.backend, tap=.2)
        self.assertTrue(self.backend.pressed.wait(1))
        self.player.toggle_pause()
        time.sleep(.04)
        self.assertFalse(self.backend.held)
        self.player.stop()
        self.player.thread.join(2)
        self.assertFalse(self.backend.held)

    def test_pause_resumes_without_advancing_score_clock(self):
        self.player.start(parse_guitar("{G} 6:1/4 1:1/4", 360), GameProfile(), self.backend)
        self.assertTrue(self.backend.pressed.wait(1))
        self.player.toggle_pause()
        time.sleep(.12)
        self.assertTrue(self.player.running)
        self.player.toggle_pause()
        self.player.thread.join(2)
        self.assertEqual(self.messages[-1][0], "done")
        self.assertFalse(self.backend.held)

    def test_partial_send_preserves_release_tracking(self):
        backend = WindowsBackend.__new__(WindowsBackend)
        backend.held_keys, backend.held_buttons = ["1"], {"left"}
        backend._key = lambda key, up: (key, up)
        backend._button = lambda key, up: (key, up)
        backend._send = lambda entries: (_ for _ in ()).throw(RuntimeError("partial send"))
        with self.assertRaises(RuntimeError):
            backend.release_all()
        self.assertEqual(backend.held_keys, ["1"])
        self.assertEqual(backend.held_buttons, {"left"})

    def test_windows_input_abi(self):
        self.assertEqual(ctypes.sizeof(INPUT), 40 if ctypes.sizeof(ctypes.c_void_p) == 8 else 28)


if __name__ == "__main__":
    unittest.main()

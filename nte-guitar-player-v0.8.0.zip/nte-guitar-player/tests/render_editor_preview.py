"""Export this application's own Canvas drawing. No desktop capture or input."""
from fractions import Fraction as F
from pathlib import Path
import sys
import tkinter.font as tkfont

from PIL import Image,ImageDraw,ImageFont

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from guitar_player.ui import App,atomic_json
from guitar_player.visual_editor import VisualTabEditor
from guitar_player.tablature import TabDocument,TabCell
from guitar_player.measures import MeasureChange


def render(canvas,width,height,app):
    scale=2
    result=Image.new('RGB',(width*scale,height*scale),'white');draw=ImageDraw.Draw(result)
    for item in canvas.find_all():
        kind=canvas.type(item);xy=[float(x)*scale for x in canvas.coords(item)]
        fill=canvas.itemcget(item,'fill') if kind!='arc' else ''
        if kind in ('line','rectangle','oval','arc'):
            weight=max(1,round(float(canvas.itemcget(item,'width'))*scale))
            points=list(zip(xy[::2],xy[1::2]))
            if kind=='line':
                draw.line(points,fill=fill,width=weight,joint='curve')
                if canvas.itemcget(item,'arrow')=='last' and len(points)>=2:
                    import math
                    (x1,y1),(x2,y2)=points[-2:];angle=math.atan2(y2-y1,x2-x1)
                    length=12*scale;wing=5*scale
                    base=(x2-length*math.cos(angle),y2-length*math.sin(angle))
                    draw.polygon([(x2,y2),(base[0]+wing*math.sin(angle),base[1]-wing*math.cos(angle)),
                                  (base[0]-wing*math.sin(angle),base[1]+wing*math.cos(angle))],fill=fill)
            elif kind=='rectangle':draw.rectangle(xy,fill=fill or None,outline=canvas.itemcget(item,'outline') or None,width=weight)
            elif kind=='oval':draw.ellipse(xy,fill=fill or None,outline=canvas.itemcget(item,'outline') or None,width=weight)
            else:
                start=float(canvas.itemcget(item,'start'));extent=float(canvas.itemcget(item,'extent'))
                draw.arc(xy,-start-extent,-start,fill=canvas.itemcget(item,'outline'),width=weight)
        elif kind=='text':
            font=tkfont.Font(root=app,font=canvas.itemcget(item,'font'))
            family=font.actual('family').lower();bold=font.actual('weight')=='bold'
            filename=('consolab.ttf' if bold else 'consola.ttf') if 'consolas' in family else 'msyhbd.ttc' if bold else 'msyh.ttc'
            size=round(abs(font.actual('size'))*app.winfo_fpixels('1i')/72*scale)
            face=ImageFont.truetype(str(Path('C:/Windows/Fonts')/filename),size)
            anchor=canvas.itemcget(item,'anchor');anchor={'w':'lm','e':'rm','center':'mm','nw':'la'}.get(anchor,'mm')
            draw.text(tuple(xy),canvas.itemcget(item,'text'),font=face,fill=fill,anchor=anchor)
    return result


def main():
    cells=[TabCell(F(0),F(1,2),2,1),TabCell(F(1,2),F(1,2),2,3),TabCell(F(1),F(1),1,3),TabCell(F(2),F(2),1,5),
           TabCell(F(4),F(1,3),1,3),TabCell(F(13,3),F(1,3),1,5),TabCell(F(14,3),F(1,3),1,7),
           TabCell(F(5),F(3,2),2,5),TabCell(F(13,2),F(1,2),2,3),TabCell(F(7),F(1),2,1),
           TabCell(F(8),F(6),3,12),TabCell(F(14),F(1),2,3),TabCell(F(15),F(1),1,3)]
    doc=TabDocument(cells,bpm=108,bars=4)
    changes='--changes' in sys.argv
    if changes:
        cells=cells[:10]+[TabCell(F(7),F(4),3,12),TabCell(F(11),F(1),2,3),TabCell(F(12),F(1),1,3)]
        # Continue the note at beat 7 across the following meter change.
        cells=[c for c in cells if c.start!=F(7) or c.string==3]
        doc=TabDocument(cells,bpm=108,bars=4,bar_changes=(MeasureChange(1,120,(3,4),'distorted'),MeasureChange(3,96,(4,4),'clean')))
        doc.set_capo(2)
    app=App(enable_native=False);app.withdraw();app.update()
    editor=VisualTabEditor(app,doc.score(),lambda score:None);editor.withdraw()
    editor.select_cursor(F(7),3 if changes else 2);editor.draw(1120)
    staff=render(editor.canvas,1120,588,app)
    image=Image.new('RGB',(2240,1396),'#edf2f6');draw=ImageDraw.Draw(image)
    heading=ImageFont.truetype('C:/Windows/Fonts/msyhbd.ttc',36)
    draw.text((40,18),'六线谱   变速 / 变拍 / 音色标记 · Capo 2' if changes else '六线谱   4 小节 · 4/4 · BPM 108',font=heading,fill='#213c57')
    for index,button in enumerate(editor.music_buttons.values()):
        image.paste(render(button,53,58,app),(40+index*120,76))
    image.paste(staff,(0,210))
    image.save(ROOT/('examples/变拍变速_音色与Capo示例.png' if changes else 'examples/六线谱符号示例.png'))
    app.accept_visual_score(doc.score())
    path=ROOT/('examples/变拍变速_音色与Capo示例.gscore' if changes else 'examples/多小节_节奏符号示例.gscore')
    app.save_score(path)
    editor.destroy();app.dirty=False;app.close()
    print('Exported the editor Canvas and its measured score.')


if __name__=='__main__':main()

@echo off
call "%~dp0start.cmd" --self-test
pause
